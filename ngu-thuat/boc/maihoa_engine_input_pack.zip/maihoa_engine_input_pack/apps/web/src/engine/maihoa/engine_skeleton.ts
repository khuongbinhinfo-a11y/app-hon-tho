// Mai Hoa engine skeleton, TypeScript-oriented pseudo-code.
// Copy into apps/web/src/engine/maihoa/ and split files when implementing.

export function mod1(value: number, divisor: number): number {
  const remainder = value % divisor
  return remainder === 0 ? divisor : remainder
}

export function makeTimeReading(input) {
  const totalYMD = input.yearBranch.value + input.month + input.day
  const totalYMDH = totalYMD + input.hourBranch.value

  const upperId = mod1(totalYMD, 8)
  const lowerId = mod1(totalYMDH, 8)
  const movingLine = mod1(totalYMDH, 6)

  const primary = findHexagramByUpperLower(upperId, lowerId)
  const mutual = makeMutualHexagram(primary)
  const changed = makeChangedHexagram(primary, movingLine)

  return {
    methodType: "time",
    rulesetId: "mhds_time_v1",
    rawInput: input,
    normalizedInput: input,
    derivationSteps: [
      `Thượng quái = mod1(${totalYMD}, 8) = ${upperId}`,
      `Hạ quái = mod1(${totalYMDH}, 8) = ${lowerId}`,
      `Hào động = mod1(${totalYMDH}, 6) = ${movingLine}`
    ],
    upperTrigramId: upperId,
    lowerTrigramId: lowerId,
    movingLine,
    primaryHexagram: primary,
    mutualHexagram: mutual,
    changedHexagram: changed,
    warnings: []
  }
}

// lines_bottom_to_top uses six characters such as "000111".
// index 0 = sơ hào, index 5 = thượng hào.
export function makeChangedHexagram(primary, movingLine) {
  const lines = primary.lines_bottom_to_top.split("")
  const idx = movingLine - 1
  lines[idx] = lines[idx] === "1" ? "0" : "1"
  return findHexagramByLines(lines.join(""))
}

export function makeMutualHexagram(primary) {
  const lines = primary.lines_bottom_to_top.split("")
  const lower = [lines[1], lines[2], lines[3]].join("")
  const upper = [lines[2], lines[3], lines[4]].join("")
  return findHexagramByUpperLowerBits(upper, lower)
}
