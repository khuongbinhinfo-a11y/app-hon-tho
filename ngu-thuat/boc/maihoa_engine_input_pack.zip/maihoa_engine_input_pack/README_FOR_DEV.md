# Mai Hoa Engine Input Pack

Generated: 2026-05-18

## Mục tiêu

Đây là gói đã xử lý từ file nghiên cứu Mai Hoa Dịch Số thành đầu vào cho engine/app.

Không bê markdown nghiên cứu thẳng vào UI. Gói này tách thành:

- `trigrams.json`: 8 quái theo số Mai Hoa.
- `hexagrams.json`: seed 64 quẻ theo thứ tự Văn Vương, có upper/lower, unicode, bits và diễn giải an toàn ngắn.
- `rulesets.json`: luật khởi quẻ phase 1.
- `test_vectors.json`: test bắt buộc từ file nghiên cứu.
- `glossary.json`: thuật ngữ cốt lõi.
- `safety_copy.json`: câu cảnh báo và ngôn ngữ nên/không nên dùng.
- `engine_skeleton.ts`: pseudo-code để dev triển khai engine.

## Route đề xuất

`/nguthuat/boc/maihoa`

## Phase 1 chỉ làm

1. Khởi quẻ theo thời gian.
2. Khởi quẻ bằng 3 số.
3. Hiển thị quẻ chủ, quẻ hỗ, quẻ biến, hào động.
4. Hiển thị vết tính toán.
5. Diễn giải mềm, không phán chắc.
6. Build pass.

## Test vector bắt buộc

Input:

- Năm Tý = 1
- Tháng = 5
- Ngày = 27
- Giờ Ngọ = 7

Expected:

- Thượng quái Càn
- Hạ quái Khôn
- Hào động 4
- Quẻ chủ Thiên Địa Bĩ
- Quẻ hỗ Phong Sơn Tiệm
- Quẻ biến Phong Địa Quán

## Lưu ý kỹ thuật quan trọng

- `mh_num` không phải là `bits`.
- `bits_bottom_to_top` của quái đọc từ dưới lên trên.
- `lines_bottom_to_top` của quẻ sáu hào cũng đọc từ dưới lên trên.
- `bits_upper_lower` chỉ để hiển thị/đối chiếu theo thượng + hạ, không dùng để đổi hào.
- 64 quẻ trong gói này là seed thực hành, nên giữ `app_status: seed_needs_review` cho đến khi được người am hiểu Dịch học kiểm duyệt.
