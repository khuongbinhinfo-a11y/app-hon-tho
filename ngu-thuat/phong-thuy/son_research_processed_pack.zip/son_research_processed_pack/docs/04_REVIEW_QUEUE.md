# Review queue cho chủ dự án / data reviewer

## Cần chốt trước khi khóa engine

1. Có dùng Lập xuân làm mốc chính thức cho Bát trạch và Phi tinh không?
2. Bảng Bát trạch lookup seed sẽ đối chiếu theo nguồn in nào?
3. Với căn hộ, lấy hướng theo cửa chính, ban công, mặt thoáng hay cho người dùng chọn nhiều mốc?
4. “Đại tu” như thế nào thì reset vận nhà?
5. Phase 1 có cho full natal chart Phi tinh không, hay chỉ annual chart?
6. Có cần lưu song ngữ Việt – Hán – Anh trong app không?
7. Có tạo expert review queue ngay từ phase đầu không?

## Cần mua/kiểm tra license

- Eight Mansions Bright Mirror
- The Original Eight Mansions Formula
- An Introduction to Feng Shui
- 沈氏玄空學
- Xuan Kong Purple White Script
