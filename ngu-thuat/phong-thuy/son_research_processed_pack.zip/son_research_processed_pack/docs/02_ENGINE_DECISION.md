# Quyết định engine từ file nghiên cứu

## Chốt hướng phase 1

1. Dùng kiến trúc 3 lớp: `core`, `reference`, `caution`.
2. Không khóa production cho bảng Bát trạch lookup seed cho tới khi đối chiếu thêm bản in/license rõ.
3. Phi tinh phase 1 dùng:
   - Tam nguyên Cửu vận
   - Period 9 = 2024–2043
   - Lập xuân làm mốc đổi năm
   - Annual center star + lưới Lạc thư
   - 9 cung + công năng từng ô
4. Chưa tự động hóa:
   - apartment facing chỉ theo cửa
   - reset chart sau mọi lần sửa
   - long-hổ/minh đường từ floor plan 2D
   - luận bệnh/tai họa/tài chính/hôn nhân chắc chắn

## Engine phải trả về

- kết quả tính được
- confidence
- review_flags
- source_refs
- allowed_wording / forbidden_wording
- suggestions nhẹ: dọn sạch, tăng sáng, thông thoáng, giảm động, đổi công năng nhỏ
