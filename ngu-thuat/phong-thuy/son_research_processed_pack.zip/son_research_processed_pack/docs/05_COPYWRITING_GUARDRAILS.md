# Copywriting guardrails cho Sơn

## Được dùng

- cần lưu ý
- nên ưu tiên
- phù hợp hơn
- có thể cân nhắc
- nên giữ yên
- nên giảm động
- nên tăng sáng
- nên thông thoáng
- nên giữ sạch
- chỉ là kết quả tham khảo theo một hệ quy chiếu cổ học
- nếu việc quan trọng nên khảo sát thực tế hoặc hỏi chuyên gia

## Không được dùng

- đại hung
- ở là gặp họa
- phá tài
- tuyệt mệnh chắc chắn xấu
- hướng này không được ở
- phải đổi nhà
- năm này chắc chắn xấu
- nhà này có hạn
- bệnh tật / sống chết / tan nhà / mất tiền chắc chắn

## Mẫu disclaimer ngắn

Kết quả này chỉ là tham khảo theo một hệ quy chiếu cổ học về không gian và phương vị. App không thay thế khảo sát thực địa, chuyên gia kiến trúc, xây dựng, sức khỏe hoặc tài chính.
