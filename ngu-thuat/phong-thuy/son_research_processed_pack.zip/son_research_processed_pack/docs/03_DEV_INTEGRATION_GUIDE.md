# Hướng dẫn tích hợp vào mini-app Sơn

## Copy dữ liệu vào repo

Copy thư mục:

```text
src-ready/features/son/
```

vào repo chính:

```text
src/features/son/
```

## File nên dùng ngay cho UI

```text
src/features/son/data/sonGlossarySeed.ts
src/features/son/data/batTrachResearchSeed.ts
src/features/son/data/phiTinhResearchSeed.ts
src/features/son/data/sonGovernanceSeed.ts
src/features/son/engine/sonEngineGuards.ts
```

## Nguyên tắc tích hợp

- UI có thể dùng glossary, star meanings, palace mapping để hiển thị.
- Engine thật chưa được coi bảng `directionLookupSeedNeedsReview` là approved_core.
- Mọi rule có `needs_review`, `caution`, hoặc `requires_human_review=true` phải hiện cờ trong UI.
- Không hardcode câu chữ hù dọa.
- Không dùng dữ liệu này để public kết quả phong thủy thật trước khi review.

## Build check

Sau khi copy, chạy:

```bash
npm run build
```

Nếu TypeScript báo quá nặng vì `as const` dữ liệu lớn, đổi export sang JSON import hoặc tách nhỏ theo module.
