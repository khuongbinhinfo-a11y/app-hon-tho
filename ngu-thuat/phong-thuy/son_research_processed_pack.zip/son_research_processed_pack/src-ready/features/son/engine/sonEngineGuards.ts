// Sơn engine type helpers.
// These are intentionally conservative. Real calculation should only use approved_core rules.

export type SonConfidence = "core" | "candidate-core" | "reference" | "caution" | "needs_review";
export type SonSeverity = "info" | "notice" | "caution" | "strong_caution";

export type SonReviewFlag = {
  code: string;
  message: string;
  severity: SonSeverity;
  requiresHumanReview?: boolean;
};

export function normalizeReviewMessage(message: string) {
  const forbidden = ["đại hung", "chắc chắn xấu", "ở là gặp họa", "phải đổi nhà", "phá tài", "tuyệt mệnh chắc chắn"];
  const hit = forbidden.find((item) => message.toLowerCase().includes(item));
  if (hit) {
    return {
      ok: false,
      reason: `Forbidden wording detected: ${hit}`,
      safeMessage: "Khu vực này cần đối chiếu thêm. Nếu việc quan trọng, nên khảo sát thực tế hoặc hỏi chuyên gia.",
    };
  }

  return { ok: true, reason: "", safeMessage: message };
}

export function createMissingDataFlag(fieldName: string): SonReviewFlag {
  return {
    code: `missing_${fieldName}`,
    message: `Thiếu dữ liệu ${fieldName}. Kết quả chỉ nên hiển thị ở mức tham khảo.`,
    severity: "notice",
    requiresHumanReview: false,
  };
}

export function createHumanReviewFlag(code: string, message: string): SonReviewFlag {
  return {
    code,
    message,
    severity: "strong_caution",
    requiresHumanReview: true,
  };
}
