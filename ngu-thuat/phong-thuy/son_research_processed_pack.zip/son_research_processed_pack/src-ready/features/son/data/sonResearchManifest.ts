// Auto-generated from deep-research-report(1).md
// Status: research candidate. Review before production.

export const sonResearchManifest = {
  "pack_name": "son_research_processed_pack",
  "created_at": "2026-05-18",
  "source_file": "deep-research-report(1).md",
  "project": "Goc_Binh_Yen / Mini app Sơn – Phong thủy an cư",
  "purpose": "Tách báo cáo nghiên cứu dài thành bộ dữ liệu có thể dùng cho UI, engine seed, data review và dev handoff.",
  "status": "research_processed_candidate",
  "important_notes": [
    "Không coi dữ liệu này là approved production engine.",
    "Bảng Bát trạch lookup seed cần kiểm duyệt bằng nguồn in/license rõ ràng trước khi khóa core.",
    "Phi tinh phase 1 nên ưu tiên vận hiện tại + annual chart + 9 cung, chưa nhảy vào full natal chart.",
    "Mọi rule có conflict hoặc thiếu dữ liệu phải trả về review flag, không phán tuyệt đối."
  ],
  "counts": {
    "concept_terms": 20,
    "glossary_seed": 20,
    "sources": 22,
    "candidate_rules": 10,
    "do_not_automate_rules": 8,
    "risk_items": 8,
    "roadmap_phases": 3
  }
} as const;
