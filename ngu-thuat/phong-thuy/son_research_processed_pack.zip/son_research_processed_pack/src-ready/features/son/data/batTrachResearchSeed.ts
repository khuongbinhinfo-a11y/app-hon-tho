// Auto-generated from deep-research-report(1).md
// Status: research candidate. Review before production.

export const batTrachResearchSeed = {
  "lifeGuaFormula": [
    {
      "Trường hợp": "Nam sinh đến hết năm 1999",
      "Công thức tính quái số hạt giống": "Cộng 2 số cuối năm sinh, rút gọn còn 1 chữ số; lấy 10 – số đó",
      "Ghi chú triển khai": "Nếu sinh trước Lập xuân thì tính theo năm trước"
    },
    {
      "Trường hợp": "Nữ sinh đến hết năm 1999",
      "Công thức tính quái số hạt giống": "Cộng 2 số cuối năm sinh, rút gọn còn 1 chữ số; lấy số đó + 5",
      "Ghi chú triển khai": "Nếu > 9 thì rút gọn tiếp"
    },
    {
      "Trường hợp": "Nam sinh từ năm 2000 trở đi",
      "Công thức tính quái số hạt giống": "Cộng 2 số cuối năm sinh, rút gọn; lấy 9 – số đó",
      "Ghi chú triển khai": "Nếu kết quả 0 thì quy ước về quẻ tương ứng trong lookup table"
    },
    {
      "Trường hợp": "Nữ sinh từ năm 2000 trở đi",
      "Công thức tính quái số hạt giống": "Cộng 2 số cuối năm sinh, rút gọn; lấy số đó + 6",
      "Ghi chú triển khai": "Nếu > 9 thì rút gọn tiếp"
    },
    {
      "Trường hợp": "Sinh từ 1/1 đến trước Lập xuân",
      "Công thức tính quái số hạt giống": "Dùng năm dương lịch trước đó làm base year",
      "Ghi chú triển khai": "Cutoff nên lấy theo Lập xuân của năm chứ không lấy Tết âm"
    }
  ],
  "eastWestGroups": [
    {
      "Quái số": "1",
      "Quẻ": "Khảm",
      "Nhóm": "Đông tứ mệnh",
      "Ghi chú engine": "core lookup"
    },
    {
      "Quái số": "2",
      "Quẻ": "Khôn",
      "Nhóm": "Tây tứ mệnh",
      "Ghi chú engine": "core lookup"
    },
    {
      "Quái số": "3",
      "Quẻ": "Chấn",
      "Nhóm": "Đông tứ mệnh",
      "Ghi chú engine": "core lookup"
    },
    {
      "Quái số": "4",
      "Quẻ": "Tốn",
      "Nhóm": "Đông tứ mệnh",
      "Ghi chú engine": "core lookup"
    },
    {
      "Quái số": "5 nam",
      "Quẻ": "quy về Khôn",
      "Nhóm": "Tây tứ mệnh",
      "Ghi chú engine": "nên chuẩn hóa ngay khi compute"
    },
    {
      "Quái số": "5 nữ",
      "Quẻ": "quy về Cấn",
      "Nhóm": "Tây tứ mệnh",
      "Ghi chú engine": "nên chuẩn hóa ngay khi compute"
    },
    {
      "Quái số": "6",
      "Quẻ": "Càn",
      "Nhóm": "Tây tứ mệnh",
      "Ghi chú engine": "core lookup"
    },
    {
      "Quái số": "7",
      "Quẻ": "Đoài",
      "Nhóm": "Tây tứ mệnh",
      "Ghi chú engine": "core lookup"
    },
    {
      "Quái số": "8",
      "Quẻ": "Cấn",
      "Nhóm": "Tây tứ mệnh",
      "Ghi chú engine": "core lookup"
    },
    {
      "Quái số": "9",
      "Quẻ": "Ly",
      "Nhóm": "Đông tứ mệnh",
      "Ghi chú engine": "core lookup"
    }
  ],
  "eightStarMeanings": [
    {
      "Nhãn truyền thống": "Sinh khí",
      "Hán tự": "生氣",
      "Dịch nghĩa gần đúng": "khí sinh trưởng",
      "Ý nghĩa đời sống nên dùng trong app": "ưu tiên cho tăng trưởng, việc học, công việc, phát triển",
      "Thuộc tính truyền thống": "cát"
    },
    {
      "Nhãn truyền thống": "Thiên y",
      "Hán tự": "天醫",
      "Dịch nghĩa gần đúng": "\"thầy thuốc trời\"",
      "Ý nghĩa đời sống nên dùng trong app": "ưu tiên cho sức khỏe, hồi phục, chăm sóc",
      "Thuộc tính truyền thống": "cát"
    },
    {
      "Nhãn truyền thống": "Diên niên",
      "Hán tự": "延年",
      "Dịch nghĩa gần đúng": "kéo dài bền vững",
      "Ý nghĩa đời sống nên dùng trong app": "ưu tiên cho quan hệ, ổn định, kết nối lâu dài",
      "Thuộc tính truyền thống": "cát"
    },
    {
      "Nhãn truyền thống": "Phục vị",
      "Hán tự": "伏位",
      "Dịch nghĩa gần đúng": "vị trí yên ổn",
      "Ý nghĩa đời sống nên dùng trong app": "hợp cho tĩnh tâm, học tập, ổn định, neo cảm giác an tâm",
      "Thuộc tính truyền thống": "cát"
    },
    {
      "Nhãn truyền thống": "Tuyệt mệnh",
      "Hán tự": "絕命",
      "Dịch nghĩa gần đúng": "năng lượng đối kháng mạnh",
      "Ý nghĩa đời sống nên dùng trong app": "cần thận trọng, không nên gán kết luận định mệnh",
      "Thuộc tính truyền thống": "bất lợi hơn"
    },
    {
      "Nhãn truyền thống": "Ngũ quỷ",
      "Hán tự": "五鬼",
      "Dịch nghĩa gần đúng": "nhãn truyền thống cổ",
      "Ý nghĩa đời sống nên dùng trong app": "nên diễn giải thành rối nhiễu, bất ổn, khó tập trung",
      "Thuộc tính truyền thống": "bất lợi hơn"
    },
    {
      "Nhãn truyền thống": "Lục sát",
      "Hán tự": "六煞",
      "Dịch nghĩa gần đúng": "nhãn truyền thống cổ",
      "Ý nghĩa đời sống nên dùng trong app": "nên diễn giải thành áp lực quan hệ/xung đột vặt/khó hòa hợp",
      "Thuộc tính truyền thống": "bất lợi hơn"
    },
    {
      "Nhãn truyền thống": "Họa hại",
      "Hán tự": "禍害",
      "Dịch nghĩa gần đúng": "nhãn truyền thống cổ",
      "Ý nghĩa đời sống nên dùng trong app": "nên diễn giải thành bất tiện, hao năng lượng, vụn vặt kéo dài",
      "Thuộc tính truyền thống": "bất lợi hơn"
    }
  ],
  "directionLookupSeedNeedsReview": [
    {
      "Cung mệnh": "Khảm 1",
      "Sinh khí": "Đông Nam",
      "Thiên y": "Đông",
      "Diên niên": "Nam",
      "Phục vị": "Bắc",
      "Tuyệt mệnh": "Tây Nam",
      "Ngũ quỷ": "Đông Bắc",
      "Lục sát": "Tây Bắc",
      "Họa hại": "Tây"
    },
    {
      "Cung mệnh": "Khôn 2",
      "Sinh khí": "Đông Bắc",
      "Thiên y": "Tây",
      "Diên niên": "Tây Bắc",
      "Phục vị": "Tây Nam",
      "Tuyệt mệnh": "Đông",
      "Ngũ quỷ": "Nam",
      "Lục sát": "Bắc",
      "Họa hại": "Đông Nam"
    },
    {
      "Cung mệnh": "Chấn 3",
      "Sinh khí": "Nam",
      "Thiên y": "Bắc",
      "Diên niên": "Đông Nam",
      "Phục vị": "Đông",
      "Tuyệt mệnh": "Tây",
      "Ngũ quỷ": "Tây Bắc",
      "Lục sát": "Tây Nam",
      "Họa hại": "Đông Bắc"
    },
    {
      "Cung mệnh": "Tốn 4",
      "Sinh khí": "Bắc",
      "Thiên y": "Nam",
      "Diên niên": "Đông",
      "Phục vị": "Đông Nam",
      "Tuyệt mệnh": "Tây Bắc",
      "Ngũ quỷ": "Tây",
      "Lục sát": "Đông Bắc",
      "Họa hại": "Tây Nam"
    },
    {
      "Cung mệnh": "Càn 6",
      "Sinh khí": "Tây",
      "Thiên y": "Đông Bắc",
      "Diên niên": "Tây Nam",
      "Phục vị": "Tây Bắc",
      "Tuyệt mệnh": "Nam",
      "Ngũ quỷ": "Đông",
      "Lục sát": "Đông Nam",
      "Họa hại": "Bắc"
    },
    {
      "Cung mệnh": "Đoài 7",
      "Sinh khí": "Tây Bắc",
      "Thiên y": "Tây Nam",
      "Diên niên": "Đông Bắc",
      "Phục vị": "Tây",
      "Tuyệt mệnh": "Bắc",
      "Ngũ quỷ": "Đông Nam",
      "Lục sát": "Đông",
      "Họa hại": "Nam"
    },
    {
      "Cung mệnh": "Cấn 8",
      "Sinh khí": "Tây Nam",
      "Thiên y": "Tây Bắc",
      "Diên niên": "Tây",
      "Phục vị": "Đông Bắc",
      "Tuyệt mệnh": "Đông Nam",
      "Ngũ quỷ": "Bắc",
      "Lục sát": "Nam",
      "Họa hại": "Đông"
    },
    {
      "Cung mệnh": "Ly 9",
      "Sinh khí": "Đông",
      "Thiên y": "Đông Nam",
      "Diên niên": "Bắc",
      "Phục vị": "Nam",
      "Tuyệt mệnh": "Tây",
      "Ngũ quỷ": "Đông Bắc",
      "Lục sát": "Tây Nam",
      "Họa hại": "Tây Bắc"
    }
  ],
  "spaceApplicationRules": [
    {
      "Không gian": "Cửa chính",
      "Nên ưu tiên bằng Bát trạch ở mức nào": "Rất cao",
      "Cách nói phù hợp cho app": "\"nên ưu tiên kiểm tra trước vì đây là lớp tiếp nhận khí và là trọng tâm cổ điển của Eight Mansions\"",
      "Confidence": "core/reference"
    },
    {
      "Không gian": "Phòng ngủ chính",
      "Nên ưu tiên bằng Bát trạch ở mức nào": "Cao",
      "Cách nói phù hợp cho app": "\"nên ưu tiên đặt ở khu thuận lợi hơn nếu mặt bằng cho phép\"",
      "Confidence": "core/reference"
    },
    {
      "Không gian": "Hướng giường",
      "Nên ưu tiên bằng Bát trạch ở mức nào": "Trung bình",
      "Cách nói phù hợp cho app": "\"có thể dùng để fine-tune sau khi đã xét vị trí phòng\"",
      "Confidence": "reference"
    },
    {
      "Không gian": "Bàn làm việc / bàn học",
      "Nên ưu tiên bằng Bát trạch ở mức nào": "Trung bình",
      "Cách nói phù hợp cho app": "\"có thể cân nhắc xoay theo life gua nếu không xung đột công năng thực tế\"",
      "Confidence": "reference"
    },
    {
      "Không gian": "Bếp",
      "Nên ưu tiên bằng Bát trạch ở mức nào": "Cao",
      "Cách nói phù hợp cho app": "\"nên xem như không gian kỹ thuật cần đối chiếu kỹ với house kua và công năng\"",
      "Confidence": "reference"
    },
    {
      "Không gian": "Phòng thờ / khu tĩnh",
      "Nên ưu tiên bằng Bát trạch ở mức nào": "Trung bình–cao",
      "Cách nói phù hợp cho app": "\"phù hợp hơn với vùng tĩnh, ổn định\"",
      "Confidence": "reference"
    },
    {
      "Không gian": "Cửa hàng nhỏ / quầy bán",
      "Nên ưu tiên bằng Bát trạch ở mức nào": "Trung bình",
      "Cách nói phù hợp cho app": "\"có thể ưu tiên cửa vào và quầy chính theo zone thuận lợi hơn\"",
      "Confidence": "caution"
    },
    {
      "Không gian": "WC / kho / phòng phụ",
      "Nên ưu tiên bằng Bát trạch ở mức nào": "Trung bình",
      "Cách nói phù hợp cho app": "\"thường được dùng như không gian ít ưu tiên hơn trong nhiều tài liệu ứng dụng\"",
      "Confidence": "reference"
    }
  ],
  "nonAbsoluteLimits": [
    {
      "Điều cần tránh": "\"Hướng này chắc chắn xấu\"",
      "Vì sao": "Bát trạch là một trường phái, không phải một phép đo tuyệt đối cho mọi căn nhà"
    },
    {
      "Điều cần tránh": "\"Không hợp là phải đổi nhà\"",
      "Vì sao": "House kua còn phải đối chiếu với công năng, hình thế, Phi tinh, và dữ liệu thực địa"
    },
    {
      "Điều cần tránh": "\"Chỉ cần xoay giường là giải quyết hết\"",
      "Vì sao": "Vị trí không gian thường quan trọng hơn fine-tuning hướng đồ nội thất"
    },
    {
      "Điều cần tránh": "\"Chỉ coi life gua là đủ\"",
      "Vì sao": "Nhiều nguồn nhấn mạnh house kua phải xét trước rồi mới đến life kua"
    },
    {
      "Điều cần tránh": "\"Cửa chính luôn chính là hướng nhà trong mọi trường hợp căn hộ\"",
      "Vì sao": "Nguồn practitioner thừa nhận đây là điểm còn tranh luận, nhất là với apartment"
    },
    {
      "Điều cần tránh": "\"4 tốt / 4 xấu áp thẳng lên tài vận–sức khỏe–hôn nhân\"",
      "Vì sao": "Ngôn ngữ sản phẩm nên giữ ở mức ưu tiên sử dụng không gian, không phán định mệnh"
    }
  ]
} as const;
