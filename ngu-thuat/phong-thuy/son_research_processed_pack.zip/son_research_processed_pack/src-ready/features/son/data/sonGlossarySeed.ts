// Auto-generated from deep-research-report(1).md
// Status: research candidate. Review before production.

export const sonGlossarySeed = [
  {
    "term_vi": "Khí",
    "term_han": "氣",
    "term_en": "qi",
    "short_definition": "năng lực/khí lực nền của hệ tư tưởng Trung Hoa",
    "confidence": "high",
    "source_candidates": ""
  },
  {
    "term_vi": "Âm dương",
    "term_han": "陰陽",
    "term_en": "yinyang",
    "short_definition": "hai lực đối đãi, bổ sung và chuyển hóa lẫn nhau",
    "confidence": "high",
    "source_candidates": ""
  },
  {
    "term_vi": "Ngũ hành",
    "term_han": "五行",
    "term_en": "five phases / wuxing",
    "short_definition": "hệ 5 phase mộc-hỏa-thổ-kim-thủy",
    "confidence": "high",
    "source_candidates": ""
  },
  {
    "term_vi": "Bát quái",
    "term_han": "八卦",
    "term_en": "bagua / eight trigrams",
    "short_definition": "8 quẻ làm nền cho phương vị và gua",
    "confidence": "high",
    "source_candidates": ""
  },
  {
    "term_vi": "Cửu cung",
    "term_han": "九宮",
    "term_en": "nine palaces",
    "short_definition": "lưới 9 cung cho Lạc thư/Phi tinh",
    "confidence": "high",
    "source_candidates": ""
  },
  {
    "term_vi": "Lạc thư",
    "term_han": "洛書",
    "term_en": "Luo Shu",
    "short_definition": "ma phương 3×3 làm nền cho cửu cung",
    "confidence": "high",
    "source_candidates": ""
  },
  {
    "term_vi": "Tọa hướng",
    "term_han": "坐向",
    "term_en": "sitting-facing",
    "short_definition": "cặp hướng lưng–hướng nhìn của công trình",
    "confidence": "high",
    "source_candidates": ""
  },
  {
    "term_vi": "Cung mệnh",
    "term_han": "命卦",
    "term_en": "life gua / kua",
    "short_definition": "quẻ cá nhân tính theo năm sinh và giới tính",
    "confidence": "high",
    "source_candidates": ""
  },
  {
    "term_vi": "Cung nhà",
    "term_han": "宅卦",
    "term_en": "house kua",
    "short_definition": "quẻ của nhà theo tọa/hướng",
    "confidence": "medium",
    "source_candidates": ""
  },
  {
    "term_vi": "Bát trạch",
    "term_han": "八宅",
    "term_en": "eight mansions / ba zhai",
    "short_definition": "hệ phân 8 nhà/8 cung trong phong thủy",
    "confidence": "high",
    "source_candidates": ""
  },
  {
    "term_vi": "Phi tinh",
    "term_han": "飛星",
    "term_en": "flying star",
    "short_definition": "hệ phong thủy dùng sao bay theo thời gian",
    "confidence": "high",
    "source_candidates": ""
  },
  {
    "term_vi": "Tam nguyên cửu vận",
    "term_han": "三元九運",
    "term_en": "three cycles nine periods",
    "short_definition": "chu kỳ 180 năm gồm 9 vận, mỗi vận 20 năm",
    "confidence": "high",
    "source_candidates": ""
  },
  {
    "term_vi": "Niên tinh",
    "term_han": "年星",
    "term_en": "annual star",
    "short_definition": "lớp sao theo năm đặt lên cửu cung",
    "confidence": "medium",
    "source_candidates": ""
  },
  {
    "term_vi": "Minh đường",
    "term_han": "明堂",
    "term_en": "bright hall / ming tang",
    "short_definition": "khoảng trống trước nhà để tụ khí",
    "confidence": "medium",
    "source_candidates": ""
  },
  {
    "term_vi": "Loan đầu",
    "term_han": "巒頭",
    "term_en": "form school / landform",
    "short_definition": "nhánh đọc hình thế thực địa",
    "confidence": "medium",
    "source_candidates": ""
  },
  {
    "term_vi": "Lý khí",
    "term_han": "理氣",
    "term_en": "formula/compass school",
    "short_definition": "nhánh đọc theo phương vị–thời gian–mô hình số",
    "confidence": "high",
    "source_candidates": ""
  },
  {
    "term_vi": "Sinh khí",
    "term_han": "生氣",
    "term_en": "sheng qi",
    "short_definition": "nhãn cát trong Bát trạch, nên diễn giải mềm là tăng trưởng",
    "confidence": "medium",
    "source_candidates": ""
  },
  {
    "term_vi": "Thiên y",
    "term_han": "天醫",
    "term_en": "tian yi",
    "short_definition": "nhãn cát gắn với chăm sóc/sức khỏe",
    "confidence": "medium",
    "source_candidates": ""
  },
  {
    "term_vi": "Diên niên",
    "term_han": "延年",
    "term_en": "yan nian",
    "short_definition": "nhãn cát gắn với bền vững/quan hệ",
    "confidence": "medium",
    "source_candidates": ""
  },
  {
    "term_vi": "Phục vị",
    "term_han": "伏位",
    "term_en": "fu wei",
    "short_definition": "nhãn cát gắn với ổn định/tĩnh",
    "confidence": "medium",
    "source_candidates": ""
  }
] as const;
