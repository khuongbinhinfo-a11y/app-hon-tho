// Auto-generated from deep-research-report(1).md
// Status: research candidate. Review before production.

export const sonGovernanceSeed = {
  "conflictMatrix": [
    {
      "Trục so sánh": "Bát trạch vs Phi tinh",
      "Điểm khác chính": "Bát trạch thiên về house/life gua và vùng thuận lợi–cần lưu ý ổn định hơn; Phi tinh thiên về thời gian, period, annual transit",
      "Hàm ý cho engine": "Cho phép chạy song song, nhưng phải tách output và confidence"
    },
    {
      "Trục so sánh": "Loan đầu vs Lý khí",
      "Điểm khác chính": "Loan đầu đọc hình thế thực tế; Lý khí đọc phương vị–tính toán",
      "Hàm ý cho engine": "Nếu thiếu survey thì chỉ nên kết luận phần lý khí"
    },
    {
      "Trục so sánh": "Hình thế vs phương vị",
      "Điểm khác chính": "Một mặt bằng đúng hướng nhưng hình thế bí/khuyết/xung cũng vẫn là vấn đề",
      "Hàm ý cho engine": "Hiển thị rõ \"chưa có khảo sát thực địa\""
    },
    {
      "Trục so sánh": "Hướng nhà theo cửa chính vs tọa/hướng",
      "Điểm khác chính": "Một số nguồn nhấn mạnh cửa/gate; một số nguồn practitioner cho rằng facing của apartment khác front door",
      "Hàm ý cho engine": "Input model phải có cả main_door_direction và facing_direction"
    },
    {
      "Trục so sánh": "Năm xây vs năm nhập trạch vs năm đại tu",
      "Điểm khác chính": "Có đồng thuận thực hành nhưng chưa tuyệt đối đồng nhất",
      "Hàm ý cho engine": "Thu đủ dữ liệu, flag review nếu lệch"
    },
    {
      "Trục so sánh": "\"Hướng tốt/xấu\" trong đời sống hiện đại",
      "Điểm khác chính": "Nguồn hiện đại thường dùng như ưu tiên công năng, không phải phán luận chắc chắn",
      "Hàm ý cho engine": "Wording engine phải nhẹ, dùng \"nên ưu tiên/có thể cân nhắc\""
    },
    {
      "Trục so sánh": "Bát trạch mâu thuẫn với Phi tinh",
      "Điểm khác chính": "Một số nguồn cho rằng hai trường phái khác domain nên không phủ định nhau; nhiều practitioner ưu tiên Phi tinh khi có xung đột",
      "Hàm ý cho engine": "Khi lệch nhau, engine nên trả nhiều góc nhìn + cần đối chiếu thêm"
    }
  ],
  "rulePriority": [
    {
      "Nhóm rule": "Core",
      "Nên đưa vào đâu": "Lập xuân cutoff; công thức life gua; East/West group; cửu cung–Lạc thư; bảng 9 period; annual center star formula; structure của palace grid"
    },
    {
      "Nhóm rule": "Reference",
      "Nên đưa vào đâu": "8 sao Bát trạch; meaning mềm của 9 sao; ứng dụng cho phòng ngủ/bếp/bàn làm việc; gợi ý giảm động/tăng sáng/thông thoáng"
    },
    {
      "Nhóm rule": "Caution",
      "Nên đưa vào đâu": "apartment facing, renovation reset, fine-tuning furniture, star combinations, mountain/facing star interpretation"
    },
    {
      "Nhóm rule": "Không tự động hóa nếu chưa khảo sát thực địa",
      "Nên đưa vào đâu": "minh đường, hậu chẩm, long–hổ, đường đâm, phản cung, các kết luận liên hệ sức khỏe/tài chính/hôn nhân ở mức mạnh"
    }
  ],
  "candidateEngineRules": [
    {
      "id": "BT-001",
      "module": "bat_trach",
      "condition": "birth_date < lichun_of_year",
      "result": "use_previous_solar_year = true",
      "explanation_plain": "Nếu sinh trước Lập xuân, nên tính cung mệnh theo năm trước",
      "severity": "notice",
      "confidence": "core",
      "requires_human_review": "false",
      "source_refs": ""
    },
    {
      "id": "BT-002",
      "module": "bat_trach",
      "condition": "life_gua in [1,3,4,9]",
      "result": "life_group = east",
      "explanation_plain": "Thuộc nhóm Đông tứ mệnh",
      "severity": "info",
      "confidence": "core",
      "requires_human_review": "false",
      "source_refs": ""
    },
    {
      "id": "BT-003",
      "module": "bat_trach",
      "condition": "room_type = main_door",
      "result": "priority_weight = highest",
      "explanation_plain": "Cửa chính là điểm nên ưu tiên xem trước trong Bát trạch",
      "severity": "notice",
      "confidence": "core/reference",
      "requires_human_review": "false",
      "source_refs": ""
    },
    {
      "id": "BT-004",
      "module": "bat_trach",
      "condition": "room_type in [bedroom,study,desk] and sector in auspicious_house_kua_set",
      "result": "recommend = prioritize_use",
      "explanation_plain": "Khu này phù hợp hơn cho sinh hoạt dài giờ",
      "severity": "notice",
      "confidence": "reference",
      "requires_human_review": "false",
      "source_refs": ""
    },
    {
      "id": "BT-005",
      "module": "bat_trach",
      "condition": "room_type in [toilet,storage] and sector in inauspicious_house_kua_set",
      "result": "recommend = acceptable_secondary_use",
      "explanation_plain": "Có thể chấp nhận hơn như khu phụ ít ưu tiên",
      "severity": "info",
      "confidence": "reference",
      "requires_human_review": "false",
      "source_refs": ""
    },
    {
      "id": "PT-001",
      "module": "phi_tinh",
      "condition": "analysis_year changes at lichun",
      "result": "annual_chart_refresh = true",
      "explanation_plain": "Niên tinh nên đổi tại Lập xuân",
      "severity": "notice",
      "confidence": "core",
      "requires_human_review": "false",
      "source_refs": ""
    },
    {
      "id": "PT-002",
      "module": "phi_tinh",
      "condition": "analysis_year = Y",
      "result": "center_star = annual_center_formula(Y)",
      "explanation_plain": "Tính sao trung cung của năm theo công thức annual center star",
      "severity": "info",
      "confidence": "core/reference",
      "requires_human_review": "false",
      "source_refs": ""
    },
    {
      "id": "PT-003",
      "module": "phi_tinh",
      "condition": "house_period unknown and renovation_year exists",
      "result": "add_review_flag",
      "explanation_plain": "Có dữ liệu cải tạo nên cần kiểm tra period anchor",
      "severity": "caution",
      "confidence": "caution",
      "requires_human_review": "true",
      "source_refs": ""
    },
    {
      "id": "PT-004",
      "module": "phi_tinh",
      "condition": "room_type in [main_door,bedroom,office] and annual_star in sensitive_set",
      "result": "suggest = reduce_activity_keep_clean",
      "explanation_plain": "Nên ưu tiên giảm động, gọn, sáng, thông thoáng",
      "severity": "caution",
      "confidence": "reference",
      "requires_human_review": "false",
      "source_refs": ""
    },
    {
      "id": "PT-005",
      "module": "phi_tinh",
      "condition": "room_type = renovation_zone and annual_star in sensitive_set",
      "result": "hard_flag = expert_review",
      "explanation_plain": "Khu sửa chữa rơi vào vùng nhạy cảm nên tham khảo chuyên gia",
      "severity": "strong_caution",
      "confidence": "caution",
      "requires_human_review": "true",
      "source_refs": ""
    }
  ],
  "doNotAutomateRules": [
    {
      "id": "NA-001",
      "Chủ đề": "Kết luận bệnh nặng/tử vong/thảm họa",
      "Vì sao chưa nên tự động hóa": "Vượt quá căn cứ nguồn và trái nguyên tắc sản phẩm",
      "Trạng thái": "rejected"
    },
    {
      "id": "NA-002",
      "Chủ đề": "\"Nhà này xấu tuyệt đối\"",
      "Vì sao chưa nên tự động hóa": "Mâu thuẫn bản chất đối chiếu nhiều trường phái",
      "Trạng thái": "rejected"
    },
    {
      "id": "NA-003",
      "Chủ đề": "Quy định apartment facing chỉ theo cửa ra vào",
      "Vì sao chưa nên tự động hóa": "Nguồn practitioner cho thấy đây là điểm tranh luận",
      "Trạng thái": "needs_review"
    },
    {
      "id": "NA-004",
      "Chủ đề": "Reset period sau mọi lần sửa nhà",
      "Vì sao chưa nên tự động hóa": "Tiêu chuẩn \"major renovation\" chưa ổn định",
      "Trạng thái": "needs_review"
    },
    {
      "id": "NA-005",
      "Chủ đề": "Tự gán cure objects/vật phẩm như bắt buộc",
      "Vì sao chưa nên tự động hóa": "Dễ trượt sang thương mại hóa và mê tín hóa",
      "Trạng thái": "rejected"
    },
    {
      "id": "NA-006",
      "Chủ đề": "Tự đọc long–hổ–minh đường chỉ từ floor plan 2D",
      "Vì sao chưa nên tự động hóa": "Cần khảo sát hình thế thực tế",
      "Trạng thái": "needs_review"
    },
    {
      "id": "NA-007",
      "Chủ đề": "Dùng annual chart thay cho natal/facing/mountain star",
      "Vì sao chưa nên tự động hóa": "Annual chỉ là lớp phủ, không phải toàn bộ chart",
      "Trạng thái": "rejected"
    },
    {
      "id": "NA-008",
      "Chủ đề": "Dùng Bát trạch để phán hôn nhân/công danh chắc chắn",
      "Vì sao chưa nên tự động hóa": "Vượt quá phạm vi \"spatial decision support\"",
      "Trạng thái": "rejected"
    }
  ],
  "sourceRegistry": [
    {
      "Nguồn": "*Feng Shui*",
      "Tác giả / đơn vị": "Encyclopaedia Britannica",
      "Ngôn ngữ": "EN",
      "Loại nguồn": "encyclopedia",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, theo dạng paraphrase ngắn",
      "Dùng cho phần nào": "reference",
      "Mức tin cậy": "5",
      "Ghi chú rủi ro": "tốt cho định nghĩa nền, không phải nguồn bảng lookup"
    },
    {
      "Nguồn": "*Qi*",
      "Tác giả / đơn vị": "Encyclopaedia Britannica",
      "Ngôn ngữ": "EN",
      "Loại nguồn": "encyclopedia",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, paraphrase ngắn",
      "Dùng cho phần nào": "glossary/reference",
      "Mức tin cậy": "5",
      "Ghi chú rủi ro": "chốt thuật ngữ \"khí\" tốt hơn blog"
    },
    {
      "Nguồn": "*Yinyang*",
      "Tác giả / đơn vị": "Encyclopaedia Britannica",
      "Ngôn ngữ": "EN",
      "Loại nguồn": "encyclopedia",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, paraphrase ngắn",
      "Dùng cho phần nào": "glossary/core nền",
      "Mức tin cậy": "5",
      "Ghi chú rủi ro": "dùng tốt cho định nghĩa triết học nền"
    },
    {
      "Nguồn": "*Wuxing*",
      "Tác giả / đơn vị": "Encyclopaedia Britannica",
      "Ngôn ngữ": "EN",
      "Loại nguồn": "encyclopedia",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, paraphrase ngắn",
      "Dùng cho phần nào": "glossary/core nền",
      "Mức tin cậy": "5",
      "Ghi chú rủi ro": "tốt cho ngũ hành như \"phases\""
    },
    {
      "Nguồn": "*Date and Time of the 24 Solar Terms*",
      "Tác giả / đơn vị": "Hong Kong Observatory",
      "Ngôn ngữ": "EN",
      "Loại nguồn": "government reference",
      "License / copyright status": "public government web / copyrighted web presentation",
      "Có dùng trong app không": "Có",
      "Dùng cho phần nào": "core thời gian",
      "Mức tin cậy": "5",
      "Ghi chú rủi ro": "tốt để chốt cutoff Lập xuân"
    },
    {
      "Nguồn": "*葬書 / The Book of Burial*",
      "Tác giả / đơn vị": "Quy về Quách Phác / Guo Pu; bản mở tại Wikisource/ctext",
      "Ngôn ngữ": "ZH",
      "Loại nguồn": "classical text / scan / transcription",
      "License / copyright status": "public domain or open transcription; needs edition check",
      "Có dùng trong app không": "Có",
      "Dùng cho phần nào": "reference / quote ngắn",
      "Mức tin cậy": "4",
      "Ghi chú rủi ro": "phải kiểm tra dị bản và nguồn bản khắc khi trích sâu"
    },
    {
      "Nguồn": "*地理辨正*",
      "Tác giả / đơn vị": "ctext transcription",
      "Ngôn ngữ": "ZH",
      "Loại nguồn": "classical text",
      "License / copyright status": "open transcription / needs edition check",
      "Có dùng trong app không": "Có",
      "Dùng cho phần nào": "reference",
      "Mức tin cậy": "4",
      "Ghi chú rủi ro": "tốt cho truy vết \"玄空\", không nên copy dài"
    },
    {
      "Nguồn": "*陽宅指南*",
      "Tác giả / đơn vị": "ctext transcription",
      "Ngôn ngữ": "ZH",
      "Loại nguồn": "classical text",
      "License / copyright status": "open transcription / needs edition check",
      "Có dùng trong app không": "Có",
      "Dùng cho phần nào": "reference",
      "Mức tin cậy": "3",
      "Ghi chú rủi ro": "hữu ích cho dwelling rules, cần đối chiếu bản in nếu dùng sâu"
    },
    {
      "Nguồn": "*Unraveling feng-shui*",
      "Tác giả / đơn vị": "S.-C. Chiou, R. Krishnamurti",
      "Ngôn ngữ": "EN",
      "Loại nguồn": "academic article PDF",
      "License / copyright status": "copyrighted journal article",
      "Có dùng trong app không": "Có, dưới dạng trích dẫn học thuật ngắn",
      "Dùng cho phần nào": "reference / concept core",
      "Mức tin cậy": "5",
      "Ghi chú rủi ro": "nguồn rất mạnh cho Form vs Cosmology, Lo Shu, Later Heaven"
    },
    {
      "Nguồn": "*Identifying Feng Shui’s Form School Influence…*",
      "Tác giả / đơn vị": "Teh Boon Soon, Azizi Bahauddin",
      "Ngôn ngữ": "EN",
      "Loại nguồn": "academic article PDF",
      "License / copyright status": "copyrighted academic article",
      "Có dùng trong app không": "Có, trích dẫn ngắn",
      "Dùng cho phần nào": "reference",
      "Mức tin cậy": "4",
      "Ghi chú rủi ro": "dùng tốt cho form-school design criteria"
    },
    {
      "Nguồn": "*An Introduction to Feng Shui*",
      "Tác giả / đơn vị": "Ole Bruun, Cambridge UP",
      "Ngôn ngữ": "EN",
      "Loại nguồn": "academic book",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, metadata + internal reference",
      "Dùng cho phần nào": "reference",
      "Mức tin cậy": "5",
      "Ghi chú rủi ro": "không copy dài; rất mạnh cho reading list chính"
    },
    {
      "Nguồn": "*以八宅明鏡設計坎宅之研究*",
      "Tác giả / đơn vị": "侯威銘",
      "Ngôn ngữ": "ZH",
      "Loại nguồn": "academic article",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, abstract/metadata",
      "Dùng cho phần nào": "reference",
      "Mức tin cậy": "3",
      "Ghi chú rủi ro": "tốt cho use-case mapping, không đủ để làm chân lý core"
    },
    {
      "Nguồn": "*宮廟建築風水應用之探索…*",
      "Tác giả / đơn vị": "方冠丁",
      "Ngôn ngữ": "ZH",
      "Loại nguồn": "thesis abstract",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, abstract/metadata",
      "Dùng cho phần nào": "reference / caution",
      "Mức tin cậy": "3",
      "Ghi chú rủi ro": "hữu ích cho period–renovation discussion, nhưng chưa nên coi là chuẩn duy nhất"
    },
    {
      "Nguồn": "*陽宅三要*",
      "Tác giả / đơn vị": "趙九峰",
      "Ngôn ngữ": "ZH",
      "Loại nguồn": "book metadata",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, metadata only",
      "Dùng cho phần nào": "reference",
      "Mức tin cậy": "4",
      "Ghi chú rủi ro": "chỉ lưu metadata và source mapping"
    },
    {
      "Nguồn": "*Eight Mansions Bright Mirror*",
      "Tác giả / đơn vị": "Terence Chan",
      "Ngôn ngữ": "EN",
      "Loại nguồn": "modern annotated translation",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, metadata + internal reference",
      "Dùng cho phần nào": "reference",
      "Mức tin cậy": "4",
      "Ghi chú rủi ro": "rất phù hợp để đối chiếu bảng Ba Zhai sau khi mua/license hợp lệ"
    },
    {
      "Nguồn": "*The Original Eight Mansions Formula*",
      "Tác giả / đơn vị": "Stephen Skinner / Chang Ping Lin",
      "Ngôn ngữ": "EN",
      "Loại nguồn": "translation / modern edition",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, internal reference",
      "Dùng cho phần nào": "reference",
      "Mức tin cậy": "4",
      "Ghi chú rủi ro": "đặc biệt mạnh cho phạm vi door-opening và 24 mountains"
    },
    {
      "Nguồn": "*沈氏玄空學*",
      "Tác giả / đơn vị": "沈竹礽",
      "Ngôn ngữ": "ZH",
      "Loại nguồn": "book metadata",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, metadata + internal reference",
      "Dùng cho phần nào": "reference",
      "Mức tin cậy": "4",
      "Ghi chú rủi ro": "nguồn trụ cột cho Phi tinh hệ Thẩm thị, cần license khi khai thác sâu"
    },
    {
      "Nguồn": "*Xuan Kong Purple White Script*",
      "Tác giả / đơn vị": "Hung Hin Cheong",
      "Ngôn ngữ": "EN",
      "Loại nguồn": "modern study of classic",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, internal reference",
      "Dùng cho phần nào": "reference",
      "Mức tin cậy": "3",
      "Ghi chú rủi ro": "tốt cho advanced phase, không cần cho phase 1 core"
    },
    {
      "Nguồn": "HKU SPACE Period 9 event page",
      "Tác giả / đơn vị": "HKU SPACE",
      "Ngôn ngữ": "ZH/EN",
      "Loại nguồn": "educational event page",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, metadata/reference",
      "Dùng cho phần nào": "reference",
      "Mức tin cậy": "3",
      "Ghi chú rủi ro": "dùng được để neo mốc 2024–2043, không dùng cho rule chi tiết"
    },
    {
      "Nguồn": "Master Sean Chan period reference",
      "Tác giả / đơn vị": "Master Sean Chan",
      "Ngôn ngữ": "EN",
      "Loại nguồn": "practitioner reference",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, nhưng chỉ candidate reference",
      "Dùng cho phần nào": "candidate-core/reference",
      "Mức tin cậy": "3",
      "Ghi chú rủi ro": "hữu ích cho period table và annual formula, cần đối chiếu nguồn in khi khóa engine"
    },
    {
      "Nguồn": "Feng Shui Expert kua formula",
      "Tác giả / đơn vị": "Aude à la Déco",
      "Ngôn ngữ": "EN",
      "Loại nguồn": "practitioner reference",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, candidate reference",
      "Dùng cho phần nào": "candidate-core",
      "Mức tin cậy": "3",
      "Ghi chú rủi ro": "ổn cho công thức life gua; cần thêm print-source để khóa core"
    },
    {
      "Nguồn": "FengShuiNexus Eight Types of Qi",
      "Tác giả / đơn vị": "Victor Cheung",
      "Ngôn ngữ": "EN",
      "Loại nguồn": "practitioner article",
      "License / copyright status": "copyrighted",
      "Có dùng trong app không": "Có, candidate reference",
      "Dùng cho phần nào": "reference",
      "Mức tin cậy": "2",
      "Ghi chú rủi ro": "chỉ dùng cho meaning mềm và room-priority, không dùng làm core độc lập"
    }
  ],
  "dataFilterRules": [
    {
      "Lớp dữ liệu": "Core",
      "Tiêu chí giữ": "Tính được, kiểm được, ngôn ngữ ổn định, ít tranh cãi",
      "Ví dụ": "period table, Lập xuân cutoff, life gua formula, palace mapping"
    },
    {
      "Lớp dữ liệu": "Reference",
      "Tiêu chí giữ": "Có giá trị đối chiếu, nhưng còn phụ thuộc trường phái/biên soạn",
      "Ví dụ": "8 qi meanings, room-use mappings, period interpretations"
    },
    {
      "Lớp dữ liệu": "Quote",
      "Tiêu chí giữ": "Chỉ trích ngắn, có nguồn rõ, có mục đích minh họa",
      "Ví dụ": "một câu từ *葬書* hoặc chú thích học thuật"
    },
    {
      "Lớp dữ liệu": "Rejected",
      "Tiêu chí giữ": "Thiếu provenance, thương mại hóa, ngôn ngữ hù dọa, kết luận cực đoan",
      "Ví dụ": "blog cure-selling, \"ở hướng này chắc chắn phá…\""
    }
  ],
  "databaseSuggestions": [
    {
      "Bảng": "sources",
      "Mục đích": "registry nguồn, license, trust, usage note"
    },
    {
      "Bảng": "books",
      "Mục đích": "metadata sách, ISBN, edition, copyright status"
    },
    {
      "Bảng": "chapters",
      "Mục đích": "mapping chương/đoạn quan trọng, không lưu full copyrighted text nếu chưa đủ quyền"
    },
    {
      "Bảng": "rules_core",
      "Mục đích": "rule đã duyệt cho engine"
    },
    {
      "Bảng": "rules_reference",
      "Mục đích": "rule tham khảo, chờ kiểm duyệt"
    },
    {
      "Bảng": "glossary_terms",
      "Mục đích": "Hán-Việt–Anh, định nghĩa ngắn, source refs"
    },
    {
      "Bảng": "star_meanings",
      "Mục đích": "meaning mềm của 9 sao theo từng confidence tier"
    },
    {
      "Bảng": "direction_meanings",
      "Mục đích": "meaning seed của 8 hướng / 8 qi"
    },
    {
      "Bảng": "palace_meanings",
      "Mục đích": "meaning của 9 cung cho Phi tinh"
    },
    {
      "Bảng": "recommendations",
      "Mục đích": "action gợi ý nhẹ theo room type"
    },
    {
      "Bảng": "caution_rules",
      "Mục đích": "vùng cần cảnh báo/ngôn ngữ cần hạn chế"
    },
    {
      "Bảng": "source_refs",
      "Mục đích": "join table nối rule ↔ source"
    },
    {
      "Bảng": "review_logs",
      "Mục đích": "ai duyệt, duyệt ngày nào, rationale gì"
    }
  ],
  "riskRegister": [
    {
      "Rủi ro": "Sai cutoff năm",
      "Khả năng": "Trung bình",
      "Tác động": "Cao",
      "Mô tả": "Lấy Tết âm thay vì Lập xuân sẽ làm lệch life gua/annual chart",
      "Giảm thiểu": "khóa engine theo HKO solar terms"
    },
    {
      "Rủi ro": "Sai hướng căn hộ",
      "Khả năng": "Cao",
      "Tác động": "Cao",
      "Mô tả": "Apartment facing vs front door là điểm tranh luận",
      "Giảm thiểu": "lưu cả facing_direction và main_door_direction; bắt review khi mơ hồ"
    },
    {
      "Rủi ro": "Sai period của nhà",
      "Khả năng": "Trung bình",
      "Tác động": "Cao",
      "Mô tả": "khác nhau giữa năm xây, nhập trạch, đại tu",
      "Giảm thiểu": "thu đủ ba mốc và flag review"
    },
    {
      "Rủi ro": "Quá phụ thuộc nguồn practitioner",
      "Khả năng": "Cao",
      "Tác động": "Trung bình",
      "Mô tả": "dễ đưa rule thiếu provenance thành core",
      "Giảm thiểu": "tách candidate-core khỏi approved_core"
    },
    {
      "Rủi ro": "Rò rỉ bản quyền",
      "Khả năng": "Trung bình",
      "Tác động": "Cao",
      "Mô tả": "vô tình copy dài từ sách/scan có bản quyền",
      "Giảm thiểu": "chỉ lưu metadata + note + short quotes có kiểm soát"
    },
    {
      "Rủi ro": "Ngôn ngữ quá mạnh",
      "Khả năng": "Cao",
      "Tác động": "Cao",
      "Mô tả": "dễ biến app thành công cụ hù dọa",
      "Giảm thiểu": "whitelist wording mềm + blacklist wording cấm"
    },
    {
      "Rủi ro": "Bỏ qua hình thế thực địa",
      "Khả năng": "Cao",
      "Tác động": "Trung bình",
      "Mô tả": "floor plan tốt chưa chắc site tốt",
      "Giảm thiểu": "mọi kết quả chỉ theo \"desk review\", không thay site audit"
    },
    {
      "Rủi ro": "Trộn Bát trạch và Phi tinh thiếu governance",
      "Khả năng": "Trung bình",
      "Tác động": "Trung bình",
      "Mô tả": "người dùng nhận output chồng chéo, khó hiểu",
      "Giảm thiểu": "rule hierarchy: core/reference/caution + conflict policy"
    }
  ],
  "roadmap": [
    {
      "Giai đoạn": "Phase đầu",
      "Mục tiêu": "Dựng engine nhẹ, an toàn, có thể kiểm duyệt",
      "Thành phần nên làm": "life gua, East/West group, house kua seed, period table, annual chart, room-priority recommendations, license registry"
    },
    {
      "Giai đoạn": "Phase kế tiếp",
      "Mục tiêu": "Nâng độ chính xác và độ sâu",
      "Thành phần nên làm": "full natal flying-star chart, reviewed lookup tables từ bản in licensed, apartment-facing policy, renovation policy"
    },
    {
      "Giai đoạn": "Phase mở rộng",
      "Mục tiêu": "Hợp nhất lý khí với khảo sát thực địa",
      "Thành phần nên làm": "form survey inputs, landform checklist, expert override workflow, review logs, explainability layer"
    }
  ]
} as const;
