// Auto-generated from deep-research-report(1).md
// Status: research candidate. Review before production.

export const sonConceptTerms = [
  {
    "Khái niệm": "Sơn trong Ngũ thuật",
    "Định nghĩa ngắn": "Trong phạm vi dự án này, \"Sơn\" được quy ước vận hành là phong thủy ứng dụng, không phải nhánh tu luyện/thân tâm theo mọi cách hiểu lịch sử.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Với app này, \"Sơn\" được hiểu là phần đọc không gian sống và công năng sử dụng.",
    "Vai trò trong app": "Định nghĩa phạm vi module.",
    "Dùng trong engine": "Có, ở mức meta-config",
    "Mức tin cậy": "caution",
    "Nguồn chính": "Quy ước dự án"
  },
  {
    "Khái niệm": "Phong thủy",
    "Định nghĩa ngắn": "Truyền thống sắp đặt/chọn vị trí không gian theo tương quan giữa người, môi trường và các mô hình tương ứng của khí, ngũ hành, bát quái.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Không chỉ là \"chọn hướng\", mà là cách đọc môi trường và cách tổ chức không gian.",
    "Vai trò trong app": "Khung lý thuyết toàn module.",
    "Dùng trong engine": "Có",
    "Mức tin cậy": "reference",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Khí",
    "Định nghĩa ngắn": "Trong triết học Trung Hoa, qi/khí là dạng \"năng lực–khí lực\" thấm trong vũ trụ và sự sống.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Có thể hiểu gần đúng là \"trạng thái năng lượng/độ thuận\" của không gian.",
    "Vai trò trong app": "Thuật ngữ giải thích của app; không nên materialize quá mức.",
    "Dùng trong engine": "Không trực tiếp; chỉ qua proxy rules",
    "Mức tin cậy": "reference",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Hình thế",
    "Định nghĩa ngắn": "Cách địa hình, khối nhà, khoảng trống, đường nước, điểm cao thấp tạo nên thế đất/thế nhà.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Là \"hình của chỗ ở\": phía trước thoáng hay bí, phía sau có tựa hay không.",
    "Vai trò trong app": "Lớp khảo sát thực địa.",
    "Dùng trong engine": "Chỉ gián tiếp nếu có survey input",
    "Mức tin cậy": "core",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Lý khí",
    "Định nghĩa ngắn": "Nhánh tính toán/phương vị dùng bát quái, Lạc thư, ngũ hành, la bàn, thời gian.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Là phần \"tính\" trong phong thủy.",
    "Vai trò trong app": "Nền cho Bát trạch và Phi tinh.",
    "Dùng trong engine": "Có",
    "Mức tin cậy": "core",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Âm dương",
    "Định nghĩa ngắn": "Hai lực/complementary phases đối đãi và phụ thuộc lẫn nhau.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Không phải tốt–xấu, mà là tĩnh–động, tối–sáng, nhận–phát.",
    "Vai trò trong app": "Rule wording và phân loại không gian.",
    "Dùng trong engine": "Có, ở mức meta attributes",
    "Mức tin cậy": "core",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Ngũ hành",
    "Định nghĩa ngắn": "Năm phase: mộc, hỏa, thổ, kim, thủy; mô tả chuyển hóa và tương quan.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Dùng như hệ quy chiếu để đọc tính chất sao, phương vị, vật thể.",
    "Vai trò trong app": "Thuộc tính nền cho Bát trạch/Phi tinh.",
    "Dùng trong engine": "Có",
    "Mức tin cậy": "core",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Bát quái",
    "Định nghĩa ngắn": "Tám quẻ từ tổ hợp âm–dương, dùng rộng trong Dịch học và phong thủy.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Có thể hình dung là 8 \"mã phương vị–tính chất\" cơ bản.",
    "Vai trò trong app": "Gán hướng, gua/kua, palace.",
    "Dùng trong engine": "Có",
    "Mức tin cậy": "core",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Cửu cung",
    "Định nghĩa ngắn": "Lưới 9 ô gắn với Lạc thư và các lớp phi tinh.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Chia mặt bằng thành 9 vùng để gán sao/phương vị.",
    "Vai trò trong app": "Cấu trúc grid của Phi tinh.",
    "Dùng trong engine": "Có",
    "Mức tin cậy": "core",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Hướng",
    "Định nghĩa ngắn": "Phương mà mặt nhà/cửa/khu vực quay tới.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Là hướng đo bằng la bàn.",
    "Vai trò trong app": "Input chính cho cả Bát trạch và Phi tinh.",
    "Dùng trong engine": "Có",
    "Mức tin cậy": "core",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Tọa hướng",
    "Định nghĩa ngắn": "Cặp \"tọa\" và \"hướng\" của công trình.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Ví dụ ngồi lưng về phía A, nhìn ra phía B.",
    "Vai trò trong app": "Input bắt buộc cho house kua và natal chart.",
    "Dùng trong engine": "Có",
    "Mức tin cậy": "core",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Minh đường",
    "Định nghĩa ngắn": "Khoảng thoáng trước nhà/điểm nhận khí phía trước.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Dễ hiểu là vùng đệm sáng, sạch, thoáng, dễ tụ khí trước khi khí vào nhà.",
    "Vai trò trong app": "Rule nhẹ cho mặt tiền/lối vào.",
    "Dùng trong engine": "Có nếu có survey input",
    "Mức tin cậy": "reference",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Hậu chẩm",
    "Định nghĩa ngắn": "Lớp tựa phía sau, thường hiểu là điểm tựa/hậu sơn.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Phía sau có cảm giác được \"đỡ lưng\", vững hơn.",
    "Vai trò trong app": "Rule nhẹ cho form survey.",
    "Dùng trong engine": "Có nếu có survey input",
    "Mức tin cậy": "reference",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Tả Thanh Long / Hữu Bạch Hổ",
    "Định nghĩa ngắn": "Hai bên trái–phải của thế đất theo mô hình long–hổ.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Hai bên nhà/sân nên có thế cân, không quá chênh.",
    "Vai trò trong app": "Survey hints; không nên tự động hóa mạnh.",
    "Dùng trong engine": "Chỉ survey-assisted",
    "Mức tin cậy": "caution",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Chu Tước / Huyền Vũ",
    "Định nghĩa ngắn": "Trước–sau của mô hình bốn tượng: trước mở, sau tựa.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Trước nên thoáng hơn, sau nên ổn hơn.",
    "Vai trò trong app": "Survey hints.",
    "Dùng trong engine": "Chỉ survey-assisted",
    "Mức tin cậy": "caution",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Tụ khí / tán khí",
    "Định nghĩa ngắn": "Giữ được khí hay để khí tản nhanh.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Nhà quá bí hoặc quá \"xuyên gió/xuyên dòng\" đều không lý tưởng.",
    "Vai trò trong app": "Rule mềm cho minh đường, hành lang, cửa đối cửa.",
    "Dùng trong engine": "Có ở mức heuristic",
    "Mức tin cậy": "reference",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Động / tĩnh",
    "Định nghĩa ngắn": "Phân vùng hoạt động nhiều hay ít.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Phòng khách/cửa chính là động; phòng ngủ/phòng thờ là tĩnh hơn.",
    "Vai trò trong app": "Nền để xếp \"không gian hợp sao nào\".",
    "Dùng trong engine": "Có",
    "Mức tin cậy": "core",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Sơn / thủy",
    "Định nghĩa ngắn": "Cặp \"núi/chỗ tựa\" và \"nước/dòng dẫn\".",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Có thể hiểu gần đúng là phần tựa–phần mở/dẫn khí.",
    "Vai trò trong app": "Rất quan trọng cho Phi tinh nâng cao; phase 1 chỉ giữ ở reference.",
    "Dùng trong engine": "Chưa nên tự động hóa mạnh",
    "Mức tin cậy": "caution",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Loan đầu / hình thế",
    "Định nghĩa ngắn": "Nhánh đọc hình thế thực tế của môi trường.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Là \"nhìn đất, nhìn nhà, nhìn xung quanh\".",
    "Vai trò trong app": "Lớp khảo sát bổ sung.",
    "Dùng trong engine": "Chỉ survey-assisted",
    "Mức tin cậy": "reference",
    "Nguồn chính": ""
  },
  {
    "Khái niệm": "Lý khí / phương vị",
    "Định nghĩa ngắn": "Nhánh đọc theo phương vị–thời gian–mô hình số.",
    "Giải thích dễ hiểu cho người dùng phổ thông": "Là \"đo, tính, đối chiếu theo hướng\".",
    "Vai trò trong app": "Lớp engine chính của phase đầu.",
    "Dùng trong engine": "Có",
    "Mức tin cậy": "core",
    "Nguồn chính": ""
  }
] as const;
