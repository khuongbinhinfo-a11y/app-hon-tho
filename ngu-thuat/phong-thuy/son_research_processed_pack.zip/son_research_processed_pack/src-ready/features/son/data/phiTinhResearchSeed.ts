// Auto-generated from deep-research-report(1).md
// Status: research candidate. Review before production.

export const phiTinhResearchSeed = {
  "periods": [
    {
      "Vận": "Vận 1",
      "Khoảng năm": "1864–1883",
      "Sao cầm lệnh": "1",
      "Ngũ hành": "Thủy",
      "Ghi chú dùng cho engine": "reference lịch sử"
    },
    {
      "Vận": "Vận 2",
      "Khoảng năm": "1884–1903",
      "Sao cầm lệnh": "2",
      "Ngũ hành": "Thổ",
      "Ghi chú dùng cho engine": "reference lịch sử"
    },
    {
      "Vận": "Vận 3",
      "Khoảng năm": "1904–1923",
      "Sao cầm lệnh": "3",
      "Ngũ hành": "Mộc",
      "Ghi chú dùng cho engine": "reference lịch sử"
    },
    {
      "Vận": "Vận 4",
      "Khoảng năm": "1924–1943",
      "Sao cầm lệnh": "4",
      "Ngũ hành": "Mộc",
      "Ghi chú dùng cho engine": "reference lịch sử"
    },
    {
      "Vận": "Vận 5",
      "Khoảng năm": "1944–1963",
      "Sao cầm lệnh": "5",
      "Ngũ hành": "Thổ",
      "Ghi chú dùng cho engine": "reference lịch sử"
    },
    {
      "Vận": "Vận 6",
      "Khoảng năm": "1964–1983",
      "Sao cầm lệnh": "6",
      "Ngũ hành": "Kim",
      "Ghi chú dùng cho engine": "reference lịch sử"
    },
    {
      "Vận": "Vận 7",
      "Khoảng năm": "1984–2003",
      "Sao cầm lệnh": "7",
      "Ngũ hành": "Kim",
      "Ghi chú dùng cho engine": "reference lịch sử"
    },
    {
      "Vận": "Vận 8",
      "Khoảng năm": "2004–2023",
      "Sao cầm lệnh": "8",
      "Ngũ hành": "Thổ",
      "Ghi chú dùng cho engine": "historical, vẫn cần dùng khi xác định chart nhà cũ"
    },
    {
      "Vận": "Vận 9",
      "Khoảng năm": "2024–2043",
      "Sao cầm lệnh": "9",
      "Ngũ hành": "Hỏa",
      "Ghi chú dùng cho engine": "vận hiện tại cho thời điểm báo cáo"
    }
  ],
  "nineStarMeanings": [
    {
      "Sao": "1",
      "Tên quen dùng": "Nhất Bạch",
      "Ngũ hành": "Thủy",
      "Tính chất cơ bản nên dùng cho app": "hỗ trợ lưu chuyển, học hỏi, nghề nghiệp, kết nối",
      "Ghi chú tin cậy": "reference"
    },
    {
      "Sao": "2",
      "Tên quen dùng": "Nhị Hắc",
      "Ngũ hành": "Thổ",
      "Tính chất cơ bản nên dùng cho app": "cần lưu ý khi rơi vào khu vực nhạy cảm như cửa/giường/ngồi lâu",
      "Ghi chú tin cậy": "reference"
    },
    {
      "Sao": "3",
      "Tên quen dùng": "Tam Bích",
      "Ngũ hành": "Mộc",
      "Tính chất cơ bản nên dùng cho app": "dễ liên hệ tới căng thẳng, tranh chấp, xung đột giọng điệu",
      "Ghi chú tin cậy": "reference"
    },
    {
      "Sao": "4",
      "Tên quen dùng": "Tứ Lục",
      "Ngũ hành": "Mộc",
      "Tính chất cơ bản nên dùng cho app": "học hành, sáng tạo, giao tiếp, nhân duyên mềm",
      "Ghi chú tin cậy": "reference"
    },
    {
      "Sao": "5",
      "Tên quen dùng": "Ngũ Hoàng",
      "Ngũ hành": "Thổ",
      "Tính chất cơ bản nên dùng cho app": "vùng nên ưu tiên giữ yên hơn, tránh kết luận cực đoan",
      "Ghi chú tin cậy": "reference"
    },
    {
      "Sao": "6",
      "Tên quen dùng": "Lục Bạch",
      "Ngũ hành": "Kim",
      "Tính chất cơ bản nên dùng cho app": "tổ chức, vai trò, hỗ trợ từ cấp trên/quy chuẩn",
      "Ghi chú tin cậy": "reference"
    },
    {
      "Sao": "7",
      "Tên quen dùng": "Thất Xích",
      "Ngũ hành": "Kim",
      "Tính chất cơ bản nên dùng cho app": "dễ đi cùng hao tán, lời nói, cạnh tranh, đứt gãy",
      "Ghi chú tin cậy": "reference"
    },
    {
      "Sao": "8",
      "Tên quen dùng": "Bát Bạch",
      "Ngũ hành": "Thổ",
      "Tính chất cơ bản nên dùng cho app": "ổn định vật chất, tích lũy, bất động sản trong period trước",
      "Ghi chú tin cậy": "reference"
    },
    {
      "Sao": "9",
      "Tên quen dùng": "Cửu Tử",
      "Ngũ hành": "Hỏa",
      "Tính chất cơ bản nên dùng cho app": "độ sáng, hiện diện, danh tiếng, xu thế current period",
      "Ghi chú tin cậy": "reference/caution"
    }
  ],
  "palaceMapping": [
    {
      "Cung": "Trung cung",
      "Phương vị": "Center",
      "Số Lạc thư": "5",
      "Quẻ/hệ quy chiếu": "Trung tâm"
    },
    {
      "Cung": "Khảm",
      "Phương vị": "Bắc",
      "Số Lạc thư": "1",
      "Quẻ/hệ quy chiếu": "Water / North"
    },
    {
      "Cung": "Cấn",
      "Phương vị": "Đông Bắc",
      "Số Lạc thư": "8",
      "Quẻ/hệ quy chiếu": "Mountain / NE"
    },
    {
      "Cung": "Chấn",
      "Phương vị": "Đông",
      "Số Lạc thư": "3",
      "Quẻ/hệ quy chiếu": "Thunder / East"
    },
    {
      "Cung": "Tốn",
      "Phương vị": "Đông Nam",
      "Số Lạc thư": "4",
      "Quẻ/hệ quy chiếu": "Wind / SE"
    },
    {
      "Cung": "Ly",
      "Phương vị": "Nam",
      "Số Lạc thư": "9",
      "Quẻ/hệ quy chiếu": "Fire / South"
    },
    {
      "Cung": "Khôn",
      "Phương vị": "Tây Nam",
      "Số Lạc thư": "2",
      "Quẻ/hệ quy chiếu": "Earth / SW"
    },
    {
      "Cung": "Đoài",
      "Phương vị": "Tây",
      "Số Lạc thư": "7",
      "Quẻ/hệ quy chiếu": "Lake / West"
    },
    {
      "Cung": "Càn",
      "Phương vị": "Tây Bắc",
      "Số Lạc thư": "6",
      "Quẻ/hệ quy chiếu": "Heaven / NW"
    }
  ],
  "corePhase1Rules": [
    {
      "Rule seed": "Annual year cutoff",
      "Mô tả": "Dùng Lập xuân làm mốc đổi niên tinh",
      "Confidence": "core"
    },
    {
      "Rule seed": "Current period",
      "Mô tả": "Dùng Vận 9 (2024–2043) làm current period reference",
      "Confidence": "core"
    },
    {
      "Rule seed": "Annual center star",
      "Mô tả": "Tính tâm tinh năm bằng công thức rút gọn chữ số năm rồi đối chiếu quy tắc annual center star",
      "Confidence": "core/reference"
    },
    {
      "Rule seed": "Lo Shu propagation",
      "Mô tả": "Từ trung cung, phát tán các sao ra 8 cung theo trật tự Lạc thư",
      "Confidence": "core/reference"
    },
    {
      "Rule seed": "Sensitive spaces first",
      "Mô tả": "Ưu tiên kiểm tra cửa chính, phòng ngủ chính, chỗ ngồi làm việc/học, khu vực sửa chữa",
      "Confidence": "reference"
    },
    {
      "Rule seed": "Quiet-hold rule",
      "Mô tả": "Với annual sectors mang tính \"cần giữ yên\", engine chỉ nên gợi ý giảm động, gọn, sáng, sạch",
      "Confidence": "reference"
    },
    {
      "Rule seed": "Overlay, not absolute",
      "Mô tả": "Annual chart chỉ là lớp phủ theo năm, không thay thế natal chart và form survey",
      "Confidence": "core governance"
    },
    {
      "Rule seed": "Renovation flag",
      "Mô tả": "Nếu có đại tu kết cấu, gắn cờ review thay vì tự quyết chart reset",
      "Confidence": "caution"
    }
  ],
  "annualStarRules": [
    {
      "Bước": "Bước 1",
      "Mô tả": "Lấy năm solar của phong thủy, đổi tại Lập xuân, không lấy Tết âm"
    },
    {
      "Bước": "Bước 2",
      "Mô tả": "Cộng các chữ số của năm rồi rút gọn còn 1 chữ số"
    },
    {
      "Bước": "Bước 3",
      "Mô tả": "Lấy 11 – số đó để tìm trung cung của annual chart; nếu kết quả hai chữ số thì rút gọn về 1 chữ số để dùng làm annual center star"
    },
    {
      "Bước": "Bước 4",
      "Mô tả": "Từ trung cung, phi các sao theo mẫu Lạc thư ra 8 cung còn lại"
    },
    {
      "Bước": "Bước 5",
      "Mô tả": "Overlay annual chart lên palace_grid của mặt bằng, rồi mới xét công năng từng khu"
    }
  ],
  "spaceRecommendationRules": [
    {
      "Không gian": "Cửa chính",
      "Rule gợi ý cho phase đầu": "Ưu tiên hiển thị annual star tại khu vực cửa trước vì đây là điểm dùng thường xuyên",
      "Mức tự động hóa": "reference"
    },
    {
      "Không gian": "Phòng ngủ",
      "Rule gợi ý cho phase đầu": "Nếu annual sector ở vùng cần giữ yên, ưu tiên gợi ý giảm động, bớt sửa chữa, duy trì sạch–thoáng",
      "Mức tự động hóa": "reference"
    },
    {
      "Không gian": "Bếp",
      "Rule gợi ý cho phase đầu": "Không nên xuất cure mạnh; chỉ nên gợi ý theo dõi tương tác công năng nhiệt–động với annual sector",
      "Mức tự động hóa": "caution"
    },
    {
      "Không gian": "Bàn làm việc",
      "Rule gợi ý cho phase đầu": "Khi sector annual thuận hơn, gợi ý \"có thể cân nhắc dùng nhiều hơn\"",
      "Mức tự động hóa": "reference"
    },
    {
      "Không gian": "Phòng khách",
      "Rule gợi ý cho phase đầu": "Có thể gợi ý tăng sáng, thông thoáng, giảm bừa bộn ở sector đang dùng nhiều",
      "Mức tự động hóa": "reference"
    },
    {
      "Không gian": "WC",
      "Rule gợi ý cho phase đầu": "Không dùng như nơi \"xấu mặc định\"; chỉ hạ mức ưu tiên so với cửa/phòng ngủ/chỗ ngồi lâu",
      "Mức tự động hóa": "core governance"
    },
    {
      "Không gian": "Kho",
      "Rule gợi ý cho phase đầu": "Có thể chấp nhận là khu ít ưu tiên hơn trong annual overlay",
      "Mức tự động hóa": "reference"
    },
    {
      "Không gian": "Lối đi / cửa nối",
      "Rule gợi ý cho phase đầu": "Nên được xem là \"động tuyến\", cần tránh wording hù dọa",
      "Mức tự động hóa": "reference"
    },
    {
      "Không gian": "Khu sửa chữa / động thổ",
      "Rule gợi ý cho phase đầu": "Nếu rơi vào annual sector nhạy cảm, bắt buộc gắn review flag",
      "Mức tự động hóa": "core/caution"
    }
  ],
  "dangerousRulesNotAuto": [
    {
      "Rule cấm tự kết luận": "Gán sao = bệnh nặng, tử vong, phá sản, kiện tụng như kết cục chắc chắn",
      "Lý do": "Vượt quá mức chứng lý và sai nguyên tắc sản phẩm"
    },
    {
      "Rule cấm tự kết luận": "Gán một sector là \"xấu tuyệt đối cho mọi nhà\"",
      "Lý do": "Phi tinh phụ thuộc period, annual overlay, natal chart, form survey"
    },
    {
      "Rule cấm tự kết luận": "Gợi ý cure vật phẩm như bắt buộc",
      "Lý do": "Dễ trượt sang thương mại hóa và mê tín hóa"
    },
    {
      "Rule cấm tự kết luận": "Tự kết luận do \"đại tu\" đã reset chart",
      "Lý do": "Tiêu chuẩn đại tu giữa các phái chưa đồng nhất"
    },
    {
      "Rule cấm tự kết luận": "Dùng annual chart thay cho natal chart/full audit",
      "Lý do": "Annual chỉ là một lớp thời gian"
    },
    {
      "Rule cấm tự kết luận": "Kết luận chỉ từ phương vị mà bỏ qua hình thế",
      "Lý do": "Form School vẫn là lớp kiểm chứng quan trọng"
    }
  ]
} as const;
