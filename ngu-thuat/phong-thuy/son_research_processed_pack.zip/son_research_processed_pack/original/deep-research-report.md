# Nghiên cứu chuyên sâu mini app Sơn cho engine Bát trạch và Huyền không Phi tinh

## Executive summary

Bản nghiên cứu này lập bản đồ **22 nguồn ứng viên** cho phase nghiên cứu đầu tiên của mini app **Sơn**, sau đó tuyển chọn thành một **active set 16 nguồn** phù hợp hơn để làm nền cho engine lọc tri thức. Trong active set đó, báo cáo này tạm phân loại **8 nguồn có thể đi vào lớp core hoặc candidate-core cho engine**, **11 nguồn phù hợp làm reference đối chiếu**, **9 nguồn cần kiểm tra thêm về copyright/license trước khi trích dẫn hoặc nội suy**, và **3 nguồn nên loại khỏi pipeline core** vì quá thiên thương mại, thiếu provenance ổn định hoặc đẩy diễn giải theo hướng quá mạnh. Các con số này là kết quả phân loại biên tập của chính báo cáo, không phải phân loại gốc từ nhà xuất bản.  

Về học thuật, các nguồn mạnh nhất cùng chỉ ra một trục tương đối nhất quán: phong thủy truyền thống không chỉ là “hướng”, mà là sự kết hợp giữa **hình thế môi trường** và **hệ tính toán/phương vị**; trong nhánh hiện đại thường gọi tương ứng là **Form School** và **Compass/Cosmology School**. Nền tảng khái niệm quan trọng nhất nằm ở **qi/khí**, **yinyang/âm dương**, **wuxing/ngũ hành**, **bagua/bát quái**, và **Luoshu/cửu cung–Lạc thư**. Các nghiên cứu kiến trúc và học thuật cũng nhấn mạnh rằng Form School là lớp cũ hơn và tập trung vào quan sát địa hình, còn lớp tính toán dựa nhiều vào bát quái, Lạc thư, ngũ hành và phép phân kỳ thời gian. citeturn8search1turn9search0turn8search2turn11view0turn23view0

Đối với **Bát trạch**, phần có thể engine hóa tốt nhất là: xác định **cung mệnh/life gua**, nhóm **Đông tứ mệnh – Tây tứ mệnh**, **cung nhà/house kua** theo tọa-hướng, và một lớp **lookup rules** để ưu tiên loại không gian nào nên đặt ở khu thuận lợi hơn. Tuy vậy, một điểm rất đáng lưu ý là các nguồn hiện đại thường mở rộng Bát trạch sang toàn bộ phòng chức năng và bố trí nội thất, trong khi một số nguồn/classical-review hiện đại cho rằng phạm vi nguyên thủy của Eight Mansions tập trung nhiều hơn vào **doorways, pathways, gates**, rồi mới tới các mở rộng về sau. Điều này làm cho Bát trạch phù hợp với **rule engine nhẹ, có nhãn confidence**, chứ chưa phù hợp để coi là bộ kết luận tuyệt đối. citeturn18view3turn32view0turn18view2

Đối với **Huyền không Phi tinh**, lớp core phù hợp hơn nằm ở mô hình thời gian: **Tam nguyên cửu vận**, xác định **vận nhà**, **tọa hướng**, **cửu cung**, và phase đầu chỉ nên ưu tiên **niên tinh/annual chart** thay vì đi thẳng vào full natal chart với đầy đủ mountain star–facing star–period star. Các nguồn truy vết tốt cho thấy giới thực hành hiện nay đang đọc theo **Period 9 = 2024–2043**, annual overlay đổi theo **Lập xuân**, còn chart nền của căn nhà phụ thuộc vào **period anchor** của công trình; riêng tiêu chí “đại tu có reset chart hay không” có đồng thuận thực hành tương đối cao nhưng tiêu chuẩn định nghĩa “đại tu” vẫn khác nhau giữa các trường phái, nên phần này phải gắn cờ **needs_review**. citeturn18view1turn16search6turn18view0turn28search0turn27view0

Kết luận vận hành cho phase đầu là: **không nên xây app như một máy phán tốt/xấu**, mà nên xây như một **engine phân lớp dữ liệu** với ba tầng: **core** cho những gì tính được và đối chiếu được, **reference** cho tri thức sách/phái/phụ chú, và **caution** cho các chỗ có dị bản, khác phái, phụ thuộc khảo sát thực địa, hoặc chứa ngôn ngữ kết luận quá mạnh. Khi Bát trạch và Phi tinh lệch nhau, UI/engine nên ưu tiên thông báo kiểu **“cần đối chiếu thêm”** thay vì “bên nào đúng tuyệt đối”. Cách làm này phù hợp hơn với chính những khác biệt đã được nêu ra trong nguồn về cửa chính, hướng nhà, hướng căn hộ và cách phối dùng Eight Mansions với Flying Star. citeturn18view3turn32view0turn23view0

## Scope nghiên cứu

Phạm vi của báo cáo này chỉ gồm **nghiên cứu nguồn, chuẩn hóa khái niệm, đối chiếu trường phái, đề xuất rule seed và schema dữ liệu** cho hai hệ **Bát trạch** và **Huyền không Phi tinh**. Báo cáo **không** coi bất kỳ nguồn đơn lẻ nào là chân lý tuyệt đối, **không** đưa luận đoán mê tín, **không** đề xuất cure/object commercialization, **không** khuyến nghị đổi nhà, và **không** coi kết quả từ một trường phái là đủ để kết luận thay cho khảo sát thực địa. Đây là một báo cáo **knowledge-engineering** hơn là một bài “xem phong thủy”.  

Về cách chọn nguồn, báo cáo ưu tiên: nguồn bách khoa/academic để chốt **từ vựng nền**, nguồn cổ thư/open transcription để truy nguyên **mạch khái niệm**, nguồn metadata sách để dựng **thư mục tham khảo và license map**, và nguồn practitioner chỉ dùng ở mức **candidate reference** cho các bảng lookup hiện hành như **Kua/Life Gua**, **Eight Mansions qi labels**, hay **annual central star formula** cho Phi tinh. Những nguồn thiên bán vật phẩm, cure kits, hoặc dùng ngôn ngữ hù dọa bị hạ điểm tin cậy và không được khuyến nghị làm core. citeturn24search10turn24search27turn15search13turn23view0turn18view1

### Tầng khái niệm nền cho module Sơn

| Khái niệm | Định nghĩa ngắn | Giải thích dễ hiểu cho người dùng phổ thông | Vai trò trong app | Dùng trong engine | Mức tin cậy | Nguồn chính |
|---|---|---|---|---|---|---|
| Sơn trong Ngũ thuật | Trong phạm vi dự án này, “Sơn” được **quy ước vận hành** là phong thủy ứng dụng, không phải nhánh tu luyện/thân tâm theo mọi cách hiểu lịch sử. | Với app này, “Sơn” được hiểu là phần đọc không gian sống và công năng sử dụng. | Định nghĩa phạm vi module. | Có, ở mức meta-config | caution | Quy ước dự án |
| Phong thủy | Truyền thống sắp đặt/chọn vị trí không gian theo tương quan giữa người, môi trường và các mô hình tương ứng của khí, ngũ hành, bát quái. | Không chỉ là “chọn hướng”, mà là cách đọc môi trường và cách tổ chức không gian. | Khung lý thuyết toàn module. | Có | reference | citeturn3search0turn23view0 |
| Khí | Trong triết học Trung Hoa, qi/khí là dạng “năng lực–khí lực” thấm trong vũ trụ và sự sống. | Có thể hiểu gần đúng là “trạng thái năng lượng/độ thuận” của không gian. | Thuật ngữ giải thích của app; không nên materialize quá mức. | Không trực tiếp; chỉ qua proxy rules | reference | citeturn8search1turn12view0 |
| Hình thế | Cách địa hình, khối nhà, khoảng trống, đường nước, điểm cao thấp tạo nên thế đất/thế nhà. | Là “hình của chỗ ở”: phía trước thoáng hay bí, phía sau có tựa hay không. | Lớp khảo sát thực địa. | Chỉ gián tiếp nếu có survey input | core | citeturn12view0turn23view0 |
| Lý khí | Nhánh tính toán/phương vị dùng bát quái, Lạc thư, ngũ hành, la bàn, thời gian. | Là phần “tính” trong phong thủy. | Nền cho Bát trạch và Phi tinh. | Có | core | citeturn12view0turn23view0 |
| Âm dương | Hai lực/complementary phases đối đãi và phụ thuộc lẫn nhau. | Không phải tốt–xấu, mà là tĩnh–động, tối–sáng, nhận–phát. | Rule wording và phân loại không gian. | Có, ở mức meta attributes | core | citeturn9search0turn9search3 |
| Ngũ hành | Năm phase: mộc, hỏa, thổ, kim, thủy; mô tả chuyển hóa và tương quan. | Dùng như hệ quy chiếu để đọc tính chất sao, phương vị, vật thể. | Thuộc tính nền cho Bát trạch/Phi tinh. | Có | core | citeturn8search2turn11view0 |
| Bát quái | Tám quẻ từ tổ hợp âm–dương, dùng rộng trong Dịch học và phong thủy. | Có thể hình dung là 8 “mã phương vị–tính chất” cơ bản. | Gán hướng, gua/kua, palace. | Có | core | citeturn11view0turn9search21 |
| Cửu cung | Lưới 9 ô gắn với Lạc thư và các lớp phi tinh. | Chia mặt bằng thành 9 vùng để gán sao/phương vị. | Cấu trúc grid của Phi tinh. | Có | core | citeturn11view0turn10search13 |
| Hướng | Phương mà mặt nhà/cửa/khu vực quay tới. | Là hướng đo bằng la bàn. | Input chính cho cả Bát trạch và Phi tinh. | Có | core | citeturn32view0turn23view0 |
| Tọa hướng | Cặp “tọa” và “hướng” của công trình. | Ví dụ ngồi lưng về phía A, nhìn ra phía B. | Input bắt buộc cho house kua và natal chart. | Có | core | citeturn32view0turn18view1 |
| Minh đường | Khoảng thoáng trước nhà/điểm nhận khí phía trước. | Dễ hiểu là vùng đệm sáng, sạch, thoáng, dễ tụ khí trước khi khí vào nhà. | Rule nhẹ cho mặt tiền/lối vào. | Có nếu có survey input | reference | citeturn22search16turn12view0 |
| Hậu chẩm | Lớp tựa phía sau, thường hiểu là điểm tựa/hậu sơn. | Phía sau có cảm giác được “đỡ lưng”, vững hơn. | Rule nhẹ cho form survey. | Có nếu có survey input | reference | citeturn12view0turn23view0 |
| Tả Thanh Long / Hữu Bạch Hổ | Hai bên trái–phải của thế đất theo mô hình long–hổ. | Hai bên nhà/sân nên có thế cân, không quá chênh. | Survey hints; không nên tự động hóa mạnh. | Chỉ survey-assisted | caution | citeturn12view0 |
| Chu Tước / Huyền Vũ | Trước–sau của mô hình bốn tượng: trước mở, sau tựa. | Trước nên thoáng hơn, sau nên ổn hơn. | Survey hints. | Chỉ survey-assisted | caution | citeturn12view0 |
| Tụ khí / tán khí | Giữ được khí hay để khí tản nhanh. | Nhà quá bí hoặc quá “xuyên gió/xuyên dòng” đều không lý tưởng. | Rule mềm cho minh đường, hành lang, cửa đối cửa. | Có ở mức heuristic | reference | citeturn12view0turn22search16 |
| Động / tĩnh | Phân vùng hoạt động nhiều hay ít. | Phòng khách/cửa chính là động; phòng ngủ/phòng thờ là tĩnh hơn. | Nền để xếp “không gian hợp sao nào”. | Có | core | citeturn25search2turn32view0 |
| Sơn / thủy | Cặp “núi/chỗ tựa” và “nước/dòng dẫn”. | Có thể hiểu gần đúng là phần tựa–phần mở/dẫn khí. | Rất quan trọng cho Phi tinh nâng cao; phase 1 chỉ giữ ở reference. | Chưa nên tự động hóa mạnh | caution | citeturn25search4turn12view0 |
| Loan đầu / hình thế | Nhánh đọc hình thế thực tế của môi trường. | Là “nhìn đất, nhìn nhà, nhìn xung quanh”. | Lớp khảo sát bổ sung. | Chỉ survey-assisted | reference | citeturn23view0turn12view0 |
| Lý khí / phương vị | Nhánh đọc theo phương vị–thời gian–mô hình số. | Là “đo, tính, đối chiếu theo hướng”. | Lớp engine chính của phase đầu. | Có | core | citeturn23view0turn18view1 |

Bảng trên tổng hợp phần khái niệm nền từ Britannica về **qi, yinyang, wuxing**, từ nghiên cứu học thuật về **Form School/Compass School**, từ bài nghiên cứu CMU về Lạc thư–bát quái–hình thế, và từ một số nguồn practitioner ở mức giải thích phụ trợ cho các thuật ngữ form-school. Mức **core/reference/caution** là đánh giá biên tập của báo cáo này để phục vụ engine, không phải xếp hạng gốc của nguồn. citeturn8search1turn9search0turn8search2turn11view0turn23view0turn12view0

## Bát trạch research

Về nguồn gốc tài liệu, hệ **Bát trạch / Eight Mansions / Ba Zhai** hiện truy vết tốt nhất qua ba lớp: **cổ thư và thuật ngữ nhà ở** như *Dương Trạch Tam Yếu*; **truyền thống Ba Zhai Ming Jing / Bát Trạch Minh Kính**; và **các bản dịch–chú giải hiện đại** như *Eight Mansions Bright Mirror* của Terence Chan hoặc *The Original Eight Mansions Formula* do Stephen Skinner giới thiệu/dịch. Một đọc rất đáng chú ý từ Skinner-review là: Eight Mansions nguyên thủy được trình bày như **door opening method**, nhấn mạnh **main door positions**, **doorways**, **pathways** và **gates**, trong khi phần mở rộng sang mọi phòng–mọi đồ nội thất là khuynh hướng phổ biến hơn ở tài liệu hiện đại. Điều này rất quan trọng cho engine, vì nó gợi ý nên tách **core Bát trạch** khỏi **mở rộng diễn giải**. citeturn31search0turn31search13turn19search25turn18view3

Nguồn secondary hiện đại và bài nghiên cứu ứng dụng đều nhất quán ở điểm: Bát trạch dùng **mệnh quái/cung mệnh** của người và **宅卦/house kua** của nhà để chia ra **4 vùng thuận lợi hơn** và **4 vùng cần lưu ý hơn**, sau đó gán ưu tiên cho các loại không gian như cửa chính, phòng ngủ, bếp, thư phòng. Tuy nhiên việc **lấy house kua ưu tiên trước life kua**, việc coi **facing direction có hay không trùng với front door**, và mức độ áp dụng vào căn hộ hiện đại vẫn là các điểm có tranh luận thực hành; vì vậy app nên dùng Bát trạch như lớp **priority ranking**, không dùng như máy kết luận số phận. citeturn32view0turn18view3turn18view4

### Bảng công thức tính cung mệnh

| Trường hợp | Công thức tính quái số hạt giống | Ghi chú triển khai |
|---|---|---|
| Nam sinh đến hết năm 1999 | Cộng 2 số cuối năm sinh, rút gọn còn 1 chữ số; lấy **10 – số đó** | Nếu sinh trước Lập xuân thì tính theo **năm trước** |
| Nữ sinh đến hết năm 1999 | Cộng 2 số cuối năm sinh, rút gọn còn 1 chữ số; lấy **số đó + 5** | Nếu > 9 thì rút gọn tiếp |
| Nam sinh từ năm 2000 trở đi | Cộng 2 số cuối năm sinh, rút gọn; lấy **9 – số đó** | Nếu kết quả 0 thì quy ước về quẻ tương ứng trong lookup table |
| Nữ sinh từ năm 2000 trở đi | Cộng 2 số cuối năm sinh, rút gọn; lấy **số đó + 6** | Nếu > 9 thì rút gọn tiếp |
| Sinh từ 1/1 đến trước Lập xuân | Dùng **năm dương lịch trước đó** làm base year | Cutoff nên lấy theo **Lập xuân** của năm chứ không lấy Tết âm |

Các công thức trên đều xuất hiện rất ổn định trong tài liệu/theory pages về **Kua/Life Gua**, và điểm giao năm theo **solar year – Lập xuân** có cơ sở tốt hơn việc lấy Tết âm nếu mục tiêu là dựng engine phong thủy phương vị. Do nguồn web hiện có là practitioner-oriented, bảng này nên được gắn trạng thái **candidate-core** cho đến khi đối chiếu thêm với một bản in có license rõ ràng trong thư mục Bát trạch. citeturn18view2turn28search0turn28search4turn30search9

### Bảng Đông tứ mệnh và Tây tứ mệnh

| Quái số | Quẻ | Nhóm | Ghi chú engine |
|---|---|---|---|
| 1 | Khảm | Đông tứ mệnh | core lookup |
| 2 | Khôn | Tây tứ mệnh | core lookup |
| 3 | Chấn | Đông tứ mệnh | core lookup |
| 4 | Tốn | Đông tứ mệnh | core lookup |
| 5 nam | quy về Khôn | Tây tứ mệnh | nên chuẩn hóa ngay khi compute |
| 5 nữ | quy về Cấn | Tây tứ mệnh | nên chuẩn hóa ngay khi compute |
| 6 | Càn | Tây tứ mệnh | core lookup |
| 7 | Đoài | Tây tứ mệnh | core lookup |
| 8 | Cấn | Tây tứ mệnh | core lookup |
| 9 | Ly | Đông tứ mệnh | core lookup |

Quy ước phân nhóm **1, 3, 4, 9 = East Group** và **2, 6, 7, 8 = West Group** xuất hiện rất ổn định trong tài liệu practitioner; điểm “số 5” quy về **Khôn/Cấn** cũng là quy ước thường gặp trong bảng tra cứu nhanh Bát trạch. Vì active set hiện chưa có một bản in học thuật/mở để trích toàn bộ bảng, engine nên lưu bảng này dưới dạng **reviewed lookup table**, có source_refs rõ ràng. citeturn13search16turn33search21

### Bảng ý nghĩa truyền thống của 8 sao trong Bát trạch

| Nhãn truyền thống | Hán tự | Dịch nghĩa gần đúng | Ý nghĩa đời sống nên dùng trong app | Thuộc tính truyền thống |
|---|---|---|---|---|
| Sinh khí | 生氣 | khí sinh trưởng | ưu tiên cho tăng trưởng, việc học, công việc, phát triển | cát |
| Thiên y | 天醫 | “thầy thuốc trời” | ưu tiên cho sức khỏe, hồi phục, chăm sóc | cát |
| Diên niên | 延年 | kéo dài bền vững | ưu tiên cho quan hệ, ổn định, kết nối lâu dài | cát |
| Phục vị | 伏位 | vị trí yên ổn | hợp cho tĩnh tâm, học tập, ổn định, neo cảm giác an tâm | cát |
| Tuyệt mệnh | 絕命 | năng lượng đối kháng mạnh | cần thận trọng, không nên gán kết luận định mệnh | bất lợi hơn |
| Ngũ quỷ | 五鬼 | nhãn truyền thống cổ | nên diễn giải thành rối nhiễu, bất ổn, khó tập trung | bất lợi hơn |
| Lục sát | 六煞 | nhãn truyền thống cổ | nên diễn giải thành áp lực quan hệ/xung đột vặt/khó hòa hợp | bất lợi hơn |
| Họa hại | 禍害 | nhãn truyền thống cổ | nên diễn giải thành bất tiện, hao năng lượng, vụn vặt kéo dài | bất lợi hơn |

Ở lớp nghĩa dùng cho app, nên **giữ tên truyền thống để làm glossary**, nhưng **dịch mềm** sang tiếng Việt đời sống, tránh mọi câu chữ kiểu “ở là gặp họa” hay “đại hung”. Các mô tả trên lấy từ mô tả Eight Types of Qi trong nguồn practitioner, rồi được làm mềm về mặt ngôn ngữ cho phù hợp nguyên tắc sản phẩm. citeturn32view0turn33search23

### Bảng 8 hướng tốt và cần lưu ý theo từng cung

Bảng dưới đây là **lookup seed** cho engine Bát trạch. Đây là phần **đã có thể cấu trúc hóa**, nhưng do active set hiện chưa mở được một bảng in hoàn chỉnh có license thật sạch cho từng ô, toàn bộ bảng này nên gắn **confidence = reference** và **status = needs_review** cho tới khi chốt một bản kiểm duyệt nội bộ từ *Ba Zhai Ming Jing* / *The Original Eight Mansions Formula* / các bản chú giải có license rõ ràng.  

| Cung mệnh | Sinh khí | Thiên y | Diên niên | Phục vị | Tuyệt mệnh | Ngũ quỷ | Lục sát | Họa hại |
|---|---|---|---|---|---|---|---|---|
| Khảm 1 | Đông Nam | Đông | Nam | Bắc | Tây Nam | Đông Bắc | Tây Bắc | Tây |
| Khôn 2 | Đông Bắc | Tây | Tây Bắc | Tây Nam | Đông | Nam | Bắc | Đông Nam |
| Chấn 3 | Nam | Bắc | Đông Nam | Đông | Tây | Tây Bắc | Tây Nam | Đông Bắc |
| Tốn 4 | Bắc | Nam | Đông | Đông Nam | Tây Bắc | Tây | Đông Bắc | Tây Nam |
| Càn 6 | Tây | Đông Bắc | Tây Nam | Tây Bắc | Nam | Đông | Đông Nam | Bắc |
| Đoài 7 | Tây Bắc | Tây Nam | Đông Bắc | Tây | Bắc | Đông Nam | Đông | Nam |
| Cấn 8 | Tây Nam | Tây Bắc | Tây | Đông Bắc | Đông Nam | Bắc | Nam | Đông |
| Ly 9 | Đông | Đông Nam | Bắc | Nam | Tây | Đông Bắc | Tây Nam | Tây Bắc |

Lookup seed này phù hợp với cách app triển khai theo hướng **ưu tiên/không ưu tiên**, nhưng **chưa nên khóa production** nếu chưa đối chiếu bằng ít nhất một nguồn in bản quyền rõ ràng trong active library. Các nguồn hiện tại đủ mạnh để chốt rằng Bát trạch có **4 hướng thuận lợi hơn và 4 hướng cần lưu ý hơn**, house kua và life kua là hai lớp khác nhau, còn bảng per-gua chi tiết cần một vòng biên tập/kiểm duyệt tài liệu nữa trước khi nâng lên **approved_core**. citeturn32view0turn18view3turn31search13

### Quy tắc ứng dụng theo từng loại không gian

| Không gian | Nên ưu tiên bằng Bát trạch ở mức nào | Cách nói phù hợp cho app | Confidence |
|---|---|---|---|
| Cửa chính | Rất cao | “nên ưu tiên kiểm tra trước vì đây là lớp tiếp nhận khí và là trọng tâm cổ điển của Eight Mansions” | core/reference |
| Phòng ngủ chính | Cao | “nên ưu tiên đặt ở khu thuận lợi hơn nếu mặt bằng cho phép” | core/reference |
| Hướng giường | Trung bình | “có thể dùng để fine-tune sau khi đã xét vị trí phòng” | reference |
| Bàn làm việc / bàn học | Trung bình | “có thể cân nhắc xoay theo life gua nếu không xung đột công năng thực tế” | reference |
| Bếp | Cao | “nên xem như không gian kỹ thuật cần đối chiếu kỹ với house kua và công năng” | reference |
| Phòng thờ / khu tĩnh | Trung bình–cao | “phù hợp hơn với vùng tĩnh, ổn định” | reference |
| Cửa hàng nhỏ / quầy bán | Trung bình | “có thể ưu tiên cửa vào và quầy chính theo zone thuận lợi hơn” | caution |
| WC / kho / phòng phụ | Trung bình | “thường được dùng như không gian ít ưu tiên hơn trong nhiều tài liệu ứng dụng” | reference |

Nguồn classical-review cho thấy trọng tâm gốc của Eight Mansions nằm rất mạnh ở **main entrance / gates / pathways**; các nguồn thực hành và nghiên cứu ứng dụng lại thường áp dụng thêm lên **bedroom, kitchen, study, storage, restroom**. Vì vậy rule engine phase đầu nên dùng cấu trúc **ưu tiên theo tầng**, không nên xử tất cả không gian với trọng số ngang nhau. citeturn18view3turn32view0turn18view4

### Các điều không nên kết luận tuyệt đối bằng Bát trạch

| Điều cần tránh | Vì sao |
|---|---|
| “Hướng này chắc chắn xấu” | Bát trạch là một trường phái, không phải một phép đo tuyệt đối cho mọi căn nhà |
| “Không hợp là phải đổi nhà” | House kua còn phải đối chiếu với công năng, hình thế, Phi tinh, và dữ liệu thực địa |
| “Chỉ cần xoay giường là giải quyết hết” | Vị trí không gian thường quan trọng hơn fine-tuning hướng đồ nội thất |
| “Chỉ coi life gua là đủ” | Nhiều nguồn nhấn mạnh **house kua** phải xét trước rồi mới đến **life kua** |
| “Cửa chính luôn chính là hướng nhà trong mọi trường hợp căn hộ” | Nguồn practitioner thừa nhận đây là điểm còn tranh luận, nhất là với apartment |
| “4 tốt / 4 xấu áp thẳng lên tài vận–sức khỏe–hôn nhân” | Ngôn ngữ sản phẩm nên giữ ở mức ưu tiên sử dụng không gian, không phán định mệnh |

Các giới hạn này không chỉ là nguyên tắc an toàn sản phẩm, mà còn phản ánh đúng tình trạng nguồn: Eight Mansions vừa có lớp cổ điển “door opening”, vừa có lớp ứng dụng mở rộng rất phổ biến trong tài liệu hiện đại. citeturn18view3turn32view0

### Đề xuất schema JSON cho engine Bát trạch

```json
{
  "module": "bat_trach",
  "rule_version": "v0.1-research",
  "input": {
    "birth_year_gregorian": 0,
    "birth_date_optional": "YYYY-MM-DD",
    "gender": "male|female|other|unspecified",
    "solar_year_cutoff": "lichun",
    "house_type": "landed|apartment|shop_house|office_small",
    "facing_direction_deg": 0.0,
    "sitting_direction_deg": 0.0,
    "main_door_direction_deg_optional": 0.0,
    "rooms": [
      {
        "room_id": "master_bedroom",
        "room_type": "bedroom|kitchen|altar|desk|living|toilet|storage|shop_counter",
        "sector": "N|NE|E|SE|S|SW|W|NW|CENTER"
      }
    ]
  },
  "computed_profile": {
    "life_gua_number": 0,
    "life_gua_name": "",
    "life_group": "east|west",
    "house_gua_name": "",
    "house_gua_group": "east|west",
    "review_flags": []
  },
  "direction_map": {
    "sheng_qi": [],
    "tian_yi": [],
    "yan_nian": [],
    "fu_wei": [],
    "jue_ming": [],
    "wu_gui": [],
    "liu_sha": [],
    "huo_hai": []
  },
  "sector_meanings": [
    {
      "sector": "SE",
      "label": "sheng_qi",
      "confidence": "reference",
      "source_refs": []
    }
  ],
  "recommendations": [
    {
      "space_type": "main_door",
      "priority": "high",
      "message": "nên ưu tiên kiểm tra khu vực này trước",
      "severity": "notice"
    }
  ],
  "cautions": [
    {
      "code": "apartment_facing_ambiguous",
      "message": "cần đối chiếu thêm cách xác định hướng căn hộ"
    }
  ],
  "source_refs": [],
  "review_status": "candidate"
}
```

Schema này cố ý tách **input**, **computed_profile**, **direction_map** và **recommendations/cautions** để engine không phải “phán” trực tiếp; engine chỉ **trả về cấu trúc và mức tin cậy**, còn lớp hiển thị mới chọn câu chữ mềm.  

## Phi tinh research

**Huyền không Phi tinh** là lớp phong thủy lý khí có trục thời gian rõ hơn Bát trạch. Trong các nguồn hiện có, lớp này được mô tả qua **Lạc thư/Cửu cung**, **9 sao**, và phép chia **9 period × 20 năm = 180 năm**. Nguồn tổng hợp period-reference nhấn mạnh rằng mỗi period được một sao “cầm lệnh”, chart của công trình được neo vào period của nó, rồi khi đọc thực tế phải đặt chart nền đó vào tương quan với **current period**, **annual transit**, và trong hệ nâng cao còn thêm personal charts. citeturn18view1turn7search19

Ở góc độ engine, điểm mạnh nhất của Phi tinh là tính **deterministic** tương đối cao cho phần nền: **period table**, **annual center star formula**, **9-palace layout**, và việc overlay theo năm. Điểm yếu là khi đi sâu vào **mountain star–facing star–period star**, **combination analysis**, **renovation reset**, hay **apartment facing**, mức tranh luận tăng mạnh. Vì vậy phase đầu nên ưu tiên: **vận hiện tại + annual chart + khu vực công năng nhạy cảm**, còn full natal chart nên để phase sau. citeturn18view1turn18view0turn27view0

### Bảng Tam nguyên cửu vận

| Vận | Khoảng năm | Sao cầm lệnh | Ngũ hành | Ghi chú dùng cho engine |
|---|---|---|---|---|
| Vận 1 | 1864–1883 | 1 | Thủy | reference lịch sử |
| Vận 2 | 1884–1903 | 2 | Thổ | reference lịch sử |
| Vận 3 | 1904–1923 | 3 | Mộc | reference lịch sử |
| Vận 4 | 1924–1943 | 4 | Mộc | reference lịch sử |
| Vận 5 | 1944–1963 | 5 | Thổ | reference lịch sử |
| Vận 6 | 1964–1983 | 6 | Kim | reference lịch sử |
| Vận 7 | 1984–2003 | 7 | Kim | reference lịch sử |
| Vận 8 | 2004–2023 | 8 | Thổ | historical, vẫn cần dùng khi xác định chart nhà cũ |
| Vận 9 | 2024–2043 | 9 | Hỏa | **vận hiện tại** cho thời điểm báo cáo |

Các nguồn practitioner và đào tạo hiện dùng khá thống nhất quy ước **Period 9 = 2024–2043**. Đối với engine, nên coi bảng period là **core reference table**, còn phần diễn giải “thời đại của sao nào” chỉ nên để ở mức reference/caution. citeturn18view1turn16search6

### Cách xác định vận nhà

Nội bộ active set đang cho thấy ba rule candidate thường gặp nhất: **năm xây/xây xong**, **năm đưa vào sử dụng/nhập trạch đầu tiên**, và **năm đại tu có tính reset chart**. Nguồn practitioner period-reference cho rằng period của building “anchors” chart của ngôi nhà; một số nguồn calculator/reference page lại dùng ngôn ngữ “constructed or moved in, depending on property type”; còn luận văn ứng dụng phong thủy công trình cho thấy thực hành thực sự có dùng mốc **sửa chữa/cải tạo trong vận mới** khi đánh giá lại công trình. Vì ba cách hiểu này không trùng tuyệt đối, app nên **thu cả ba mốc thời gian** và hiển thị **review flags** khi dữ liệu mâu thuẫn hoặc khi có dấu hiệu đại tu kết cấu. citeturn18view1turn26search3turn27view0

### Bảng 9 sao, ngũ hành và tính chất cơ bản

| Sao | Tên quen dùng | Ngũ hành | Tính chất cơ bản nên dùng cho app | Ghi chú tin cậy |
|---|---|---|---|---|
| 1 | Nhất Bạch | Thủy | hỗ trợ lưu chuyển, học hỏi, nghề nghiệp, kết nối | reference |
| 2 | Nhị Hắc | Thổ | cần lưu ý khi rơi vào khu vực nhạy cảm như cửa/giường/ngồi lâu | reference |
| 3 | Tam Bích | Mộc | dễ liên hệ tới căng thẳng, tranh chấp, xung đột giọng điệu | reference |
| 4 | Tứ Lục | Mộc | học hành, sáng tạo, giao tiếp, nhân duyên mềm | reference |
| 5 | Ngũ Hoàng | Thổ | vùng nên ưu tiên giữ yên hơn, tránh kết luận cực đoan | reference |
| 6 | Lục Bạch | Kim | tổ chức, vai trò, hỗ trợ từ cấp trên/quy chuẩn | reference |
| 7 | Thất Xích | Kim | dễ đi cùng hao tán, lời nói, cạnh tranh, đứt gãy | reference |
| 8 | Bát Bạch | Thổ | ổn định vật chất, tích lũy, bất động sản trong period trước | reference |
| 9 | Cửu Tử | Hỏa | độ sáng, hiện diện, danh tiếng, xu thế current period | reference/caution |

Nguồn period-reference và các guide về Flying Star cho thấy **không có sao nào “tốt tuyệt đối” hoặc “xấu tuyệt đối” ngoài ngữ cảnh vận**; cùng một sao có thể đổi sắc thái khi sang period khác hoặc khi chồng với annual overlay khác. Vì vậy bảng trên chỉ nên dùng như **star_meanings base layer**, không phải câu phán cuối. citeturn18view1turn7search19turn7search23

### Bảng phương vị 9 cung

| Cung | Phương vị | Số Lạc thư | Quẻ/hệ quy chiếu |
|---|---|---|---|
| Trung cung | Center | 5 | Trung tâm |
| Khảm | Bắc | 1 | Water / North |
| Cấn | Đông Bắc | 8 | Mountain / NE |
| Chấn | Đông | 3 | Thunder / East |
| Tốn | Đông Nam | 4 | Wind / SE |
| Ly | Nam | 9 | Fire / South |
| Khôn | Tây Nam | 2 | Earth / SW |
| Đoài | Tây | 7 | Lake / West |
| Càn | Tây Bắc | 6 | Heaven / NW |

Bảng cửu cung trên dựa vào mô tả **Luoshu** và **later-heaven bagua** trong nghiên cứu học thuật về phong thủy và Lạc thư. Đây là bảng **core** cho phase đầu, vì nó không phụ thuộc cách diễn giải tốt/xấu mà chỉ là hạ tầng phương vị–số–quẻ. citeturn11view0turn12view1

### Quy tắc Phi tinh cơ bản có thể dùng cho phase đầu

| Rule seed | Mô tả | Confidence |
|---|---|---|
| Annual year cutoff | Dùng **Lập xuân** làm mốc đổi niên tinh | core |
| Current period | Dùng **Vận 9 (2024–2043)** làm current period reference | core |
| Annual center star | Tính tâm tinh năm bằng công thức rút gọn chữ số năm rồi đối chiếu quy tắc annual center star | core/reference |
| Lo Shu propagation | Từ trung cung, phát tán các sao ra 8 cung theo trật tự Lạc thư | core/reference |
| Sensitive spaces first | Ưu tiên kiểm tra cửa chính, phòng ngủ chính, chỗ ngồi làm việc/học, khu vực sửa chữa | reference |
| Quiet-hold rule | Với annual sectors mang tính “cần giữ yên”, engine chỉ nên gợi ý giảm động, gọn, sáng, sạch | reference |
| Overlay, not absolute | Annual chart chỉ là lớp phủ theo năm, không thay thế natal chart và form survey | core governance |
| Renovation flag | Nếu có đại tu kết cấu, gắn cờ review thay vì tự quyết chart reset | caution |

Các rule này bám chặt phần có đồng thuận cao hơn trong active set, đồng thời tránh nhảy sang vùng diễn giải mạnh như “combination 81 stars” hay cure objects. citeturn18view1turn18view0turn28search0turn27view0

### Quy tắc niên tinh theo năm

| Bước | Mô tả |
|---|---|
| Bước 1 | Lấy **năm solar** của phong thủy, đổi tại **Lập xuân**, không lấy Tết âm |
| Bước 2 | Cộng các chữ số của năm rồi rút gọn còn 1 chữ số |
| Bước 3 | Lấy **11 – số đó** để tìm trung cung của annual chart; nếu kết quả hai chữ số thì rút gọn về 1 chữ số để dùng làm annual center star |
| Bước 4 | Từ trung cung, phi các sao theo **mẫu Lạc thư** ra 8 cung còn lại |
| Bước 5 | Overlay annual chart lên palace_grid của mặt bằng, rồi mới xét công năng từng khu |

Từ công thức annual center star đã được nêu trong nguồn reference, có thể **suy ra** năm 2026 cho trung cung là **1** sau khi rút gọn, và annual chart còn lại nên được tạo **bằng thuật toán**, không nên hardcode từng năm nếu sản phẩm muốn bền vững. Đây là một **inference có kiểm soát** từ nguồn công thức và cấu trúc Lạc thư. citeturn18view0turn11view0turn28search0

### Rule gợi ý theo từng loại không gian

| Không gian | Rule gợi ý cho phase đầu | Mức tự động hóa |
|---|---|---|
| Cửa chính | Ưu tiên hiển thị annual star tại khu vực cửa trước vì đây là điểm dùng thường xuyên | reference |
| Phòng ngủ | Nếu annual sector ở vùng cần giữ yên, ưu tiên gợi ý giảm động, bớt sửa chữa, duy trì sạch–thoáng | reference |
| Bếp | Không nên xuất cure mạnh; chỉ nên gợi ý theo dõi tương tác công năng nhiệt–động với annual sector | caution |
| Bàn làm việc | Khi sector annual thuận hơn, gợi ý “có thể cân nhắc dùng nhiều hơn” | reference |
| Phòng khách | Có thể gợi ý tăng sáng, thông thoáng, giảm bừa bộn ở sector đang dùng nhiều | reference |
| WC | Không dùng như nơi “xấu mặc định”; chỉ hạ mức ưu tiên so với cửa/phòng ngủ/chỗ ngồi lâu | core governance |
| Kho | Có thể chấp nhận là khu ít ưu tiên hơn trong annual overlay | reference |
| Lối đi / cửa nối | Nên được xem là “động tuyến”, cần tránh wording hù dọa | reference |
| Khu sửa chữa / động thổ | Nếu rơi vào annual sector nhạy cảm, **bắt buộc gắn review flag** | core/caution |

Gợi ý trên không mô tả “cure object”, mà chỉ mô tả **mức sử dụng không gian** và **độ động/tĩnh**. Cách tiếp cận này gần với một app hướng **spatial hygiene** hơn là app “hóa giải”, và phù hợp với việc annual chart được dùng như lớp overlay hàng năm. citeturn7search7turn17search30turn27view0

### Danh sách rule nguy hiểm không được engine kết luận mạnh

| Rule cấm tự kết luận | Lý do |
|---|---|
| Gán sao = bệnh nặng, tử vong, phá sản, kiện tụng như kết cục chắc chắn | Vượt quá mức chứng lý và sai nguyên tắc sản phẩm |
| Gán một sector là “xấu tuyệt đối cho mọi nhà” | Phi tinh phụ thuộc period, annual overlay, natal chart, form survey |
| Gợi ý cure vật phẩm như bắt buộc | Dễ trượt sang thương mại hóa và mê tín hóa |
| Tự kết luận do “đại tu” đã reset chart | Tiêu chuẩn đại tu giữa các phái chưa đồng nhất |
| Dùng annual chart thay cho natal chart/full audit | Annual chỉ là một lớp thời gian |
| Kết luận chỉ từ phương vị mà bỏ qua hình thế | Form School vẫn là lớp kiểm chứng quan trọng |

### Đề xuất schema JSON cho engine Phi tinh

```json
{
  "module": "phi_tinh",
  "rule_version": "v0.1-research",
  "input": {
    "house_type": "landed|apartment|shop_house|office_small",
    "build_year": 0,
    "first_occupancy_year_optional": 0,
    "major_renovation_years_optional": [],
    "facing_direction_deg": 0.0,
    "sitting_direction_deg": 0.0,
    "analysis_year": 0,
    "year_cutoff": "lichun",
    "rooms": [
      {
        "room_id": "",
        "room_type": "main_door|bedroom|kitchen|office|living|toilet|storage|circulation|renovation_zone",
        "sector": "N|NE|E|SE|S|SW|W|NW|CENTER"
      }
    ]
  },
  "house_period": {
    "period_number": 9,
    "period_range": "2024-2043",
    "period_basis": "build_year|occupancy_year|manual_review",
    "review_flags": []
  },
  "facing_direction": {
    "facing_deg": 0.0,
    "sitting_deg": 0.0,
    "facing_label": "",
    "direction_confidence": "high|medium|low"
  },
  "base_chart": {
    "chart_type": "phase1-annual_only|phase2-natal",
    "palaces": []
  },
  "annual_chart": {
    "analysis_year": 2026,
    "center_star": 1,
    "palaces": []
  },
  "palace_grid": [
    {
      "sector": "SE",
      "star": 0,
      "room_refs": [],
      "usage_intensity": "high|medium|low"
    }
  ],
  "star_meanings": [],
  "sector_recommendations": [],
  "cautions": [],
  "source_refs": [],
  "review_status": "candidate"
}
```

Schema này cho phép phase đầu chạy bằng **annual chart** trước, nhưng vẫn chừa sẵn chỗ cho **base_chart/natal chart** ở phase sau.  

## So sánh trường phái, bảng thuật ngữ và rule governance

### Bảng so sánh trường phái và các mâu thuẫn cần quản trị

| Trục so sánh | Điểm khác chính | Hàm ý cho engine |
|---|---|---|
| Bát trạch vs Phi tinh | Bát trạch thiên về **house/life gua** và vùng thuận lợi–cần lưu ý ổn định hơn; Phi tinh thiên về **thời gian**, **period**, **annual transit** | Cho phép chạy song song, nhưng phải tách output và confidence |
| Loan đầu vs Lý khí | Loan đầu đọc **hình thế thực tế**; Lý khí đọc **phương vị–tính toán** | Nếu thiếu survey thì chỉ nên kết luận phần lý khí |
| Hình thế vs phương vị | Một mặt bằng đúng hướng nhưng hình thế bí/khuyết/xung cũng vẫn là vấn đề | Hiển thị rõ “chưa có khảo sát thực địa” |
| Hướng nhà theo cửa chính vs tọa/hướng | Một số nguồn nhấn mạnh cửa/gate; một số nguồn practitioner cho rằng facing của apartment khác front door | Input model phải có cả `main_door_direction` và `facing_direction` |
| Năm xây vs năm nhập trạch vs năm đại tu | Có đồng thuận thực hành nhưng chưa tuyệt đối đồng nhất | Thu đủ dữ liệu, flag review nếu lệch |
| “Hướng tốt/xấu” trong đời sống hiện đại | Nguồn hiện đại thường dùng như ưu tiên công năng, không phải phán luận chắc chắn | Wording engine phải nhẹ, dùng “nên ưu tiên/có thể cân nhắc” |
| Bát trạch mâu thuẫn với Phi tinh | Một số nguồn cho rằng hai trường phái khác domain nên không phủ định nhau; nhiều practitioner ưu tiên Phi tinh khi có xung đột | Khi lệch nhau, engine nên trả **nhiều góc nhìn** + **cần đối chiếu thêm** |

So sánh này phản ánh khá đúng trạng thái nguồn: học thuật phân biệt rõ **Form vs Compass**, trong khi classical-review hiện đại cho rằng Eight Mansions nguyên thủy có domain hẹp hơn nhiều tài liệu phổ thông; đồng thời nguồn practitioner cũng thừa nhận chuyện căn hộ, front door và facing direction là một điểm dễ gây nhầm. citeturn23view0turn18view3turn32view0turn18view1

### Cơ chế ưu tiên rule cho engine

| Nhóm rule | Nên đưa vào đâu |
|---|---|
| Core | Lập xuân cutoff; công thức life gua; East/West group; cửu cung–Lạc thư; bảng 9 period; annual center star formula; structure của palace grid |
| Reference | 8 sao Bát trạch; meaning mềm của 9 sao; ứng dụng cho phòng ngủ/bếp/bàn làm việc; gợi ý giảm động/tăng sáng/thông thoáng |
| Caution | apartment facing, renovation reset, fine-tuning furniture, star combinations, mountain/facing star interpretation |
| Không tự động hóa nếu chưa khảo sát thực địa | minh đường, hậu chẩm, long–hổ, đường đâm, phản cung, các kết luận liên hệ sức khỏe/tài chính/hôn nhân ở mức mạnh |

### Bảng thuật ngữ dùng cho glossary seed

| term_vi | term_han | term_en | short_definition | confidence | source_candidates |
|---|---|---|---|---|---|
| Khí | 氣 | qi | năng lực/khí lực nền của hệ tư tưởng Trung Hoa | high | citeturn8search1 |
| Âm dương | 陰陽 | yinyang | hai lực đối đãi, bổ sung và chuyển hóa lẫn nhau | high | citeturn9search0 |
| Ngũ hành | 五行 | five phases / wuxing | hệ 5 phase mộc-hỏa-thổ-kim-thủy | high | citeturn8search2 |
| Bát quái | 八卦 | bagua / eight trigrams | 8 quẻ làm nền cho phương vị và gua | high | citeturn11view0 |
| Cửu cung | 九宮 | nine palaces | lưới 9 cung cho Lạc thư/Phi tinh | high | citeturn11view0 |
| Lạc thư | 洛書 | Luo Shu | ma phương 3×3 làm nền cho cửu cung | high | citeturn11view0 |
| Tọa hướng | 坐向 | sitting-facing | cặp hướng lưng–hướng nhìn của công trình | high | citeturn18view1turn32view0 |
| Cung mệnh | 命卦 | life gua / kua | quẻ cá nhân tính theo năm sinh và giới tính | high | citeturn18view2 |
| Cung nhà | 宅卦 | house kua | quẻ của nhà theo tọa/hướng | medium | citeturn32view0 |
| Bát trạch | 八宅 | eight mansions / ba zhai | hệ phân 8 nhà/8 cung trong phong thủy | high | citeturn31search13turn18view4 |
| Phi tinh | 飛星 | flying star | hệ phong thủy dùng sao bay theo thời gian | high | citeturn18view1 |
| Tam nguyên cửu vận | 三元九運 | three cycles nine periods | chu kỳ 180 năm gồm 9 vận, mỗi vận 20 năm | high | citeturn18view1 |
| Niên tinh | 年星 | annual star | lớp sao theo năm đặt lên cửu cung | medium | citeturn18view0 |
| Minh đường | 明堂 | bright hall / ming tang | khoảng trống trước nhà để tụ khí | medium | citeturn22search16turn12view0 |
| Loan đầu | 巒頭 | form school / landform | nhánh đọc hình thế thực địa | medium | citeturn23view0 |
| Lý khí | 理氣 | formula/compass school | nhánh đọc theo phương vị–thời gian–mô hình số | high | citeturn23view0 |
| Sinh khí | 生氣 | sheng qi | nhãn cát trong Bát trạch, nên diễn giải mềm là tăng trưởng | medium | citeturn32view0 |
| Thiên y | 天醫 | tian yi | nhãn cát gắn với chăm sóc/sức khỏe | medium | citeturn32view0 |
| Diên niên | 延年 | yan nian | nhãn cát gắn với bền vững/quan hệ | medium | citeturn32view0 |
| Phục vị | 伏位 | fu wei | nhãn cát gắn với ổn định/tĩnh | medium | citeturn32view0 |

### Bảng rule có thể đưa vào engine

| id | module | condition | result | explanation_plain | severity | confidence | requires_human_review | source_refs |
|---|---|---|---|---|---|---|---|---|
| BT-001 | bat_trach | birth_date < lichun_of_year | use_previous_solar_year = true | Nếu sinh trước Lập xuân, nên tính cung mệnh theo năm trước | notice | core | false | citeturn18view2turn28search0 |
| BT-002 | bat_trach | life_gua in [1,3,4,9] | life_group = east | Thuộc nhóm Đông tứ mệnh | info | core | false | citeturn13search16turn33search21 |
| BT-003 | bat_trach | room_type = main_door | priority_weight = highest | Cửa chính là điểm nên ưu tiên xem trước trong Bát trạch | notice | core/reference | false | citeturn18view3turn32view0 |
| BT-004 | bat_trach | room_type in [bedroom,study,desk] and sector in auspicious_house_kua_set | recommend = prioritize_use | Khu này phù hợp hơn cho sinh hoạt dài giờ | notice | reference | false | citeturn32view0 |
| BT-005 | bat_trach | room_type in [toilet,storage] and sector in inauspicious_house_kua_set | recommend = acceptable_secondary_use | Có thể chấp nhận hơn như khu phụ ít ưu tiên | info | reference | false | citeturn32view0turn18view4 |
| PT-001 | phi_tinh | analysis_year changes at lichun | annual_chart_refresh = true | Niên tinh nên đổi tại Lập xuân | notice | core | false | citeturn28search0turn18view0 |
| PT-002 | phi_tinh | analysis_year = Y | center_star = annual_center_formula(Y) | Tính sao trung cung của năm theo công thức annual center star | info | core/reference | false | citeturn18view0 |
| PT-003 | phi_tinh | house_period unknown and renovation_year exists | add_review_flag | Có dữ liệu cải tạo nên cần kiểm tra period anchor | caution | caution | true | citeturn18view1turn27view0 |
| PT-004 | phi_tinh | room_type in [main_door,bedroom,office] and annual_star in sensitive_set | suggest = reduce_activity_keep_clean | Nên ưu tiên giảm động, gọn, sáng, thông thoáng | caution | reference | false | citeturn7search7turn17search30 |
| PT-005 | phi_tinh | room_type = renovation_zone and annual_star in sensitive_set | hard_flag = expert_review | Khu sửa chữa rơi vào vùng nhạy cảm nên tham khảo chuyên gia | strong_caution | caution | true | citeturn27view0 |

### Bảng rule không nên tự động hóa

| id | Chủ đề | Vì sao chưa nên tự động hóa | Trạng thái |
|---|---|---|---|
| NA-001 | Kết luận bệnh nặng/tử vong/thảm họa | Vượt quá căn cứ nguồn và trái nguyên tắc sản phẩm | rejected |
| NA-002 | “Nhà này xấu tuyệt đối” | Mâu thuẫn bản chất đối chiếu nhiều trường phái | rejected |
| NA-003 | Quy định apartment facing chỉ theo cửa ra vào | Nguồn practitioner cho thấy đây là điểm tranh luận | needs_review |
| NA-004 | Reset period sau mọi lần sửa nhà | Tiêu chuẩn “major renovation” chưa ổn định | needs_review |
| NA-005 | Tự gán cure objects/vật phẩm như bắt buộc | Dễ trượt sang thương mại hóa và mê tín hóa | rejected |
| NA-006 | Tự đọc long–hổ–minh đường chỉ từ floor plan 2D | Cần khảo sát hình thế thực tế | needs_review |
| NA-007 | Dùng annual chart thay cho natal/facing/mountain star | Annual chỉ là lớp phủ, không phải toàn bộ chart | rejected |
| NA-008 | Dùng Bát trạch để phán hôn nhân/công danh chắc chắn | Vượt quá phạm vi “spatial decision support” | rejected |

## Bảng nguồn và license

Bảng dưới đây là **curated active set** dành cho team dữ liệu. Cột “có được dùng trong app không” được hiểu theo nghĩa **có thể dùng làm nguồn cho metadata/rule/reference**, không có nghĩa là có thể sao chép dài nguyên văn.  

| Nguồn | Tác giả / đơn vị | Ngôn ngữ | Loại nguồn | License / copyright status | Có dùng trong app không | Dùng cho phần nào | Mức tin cậy | Ghi chú rủi ro |
|---|---|---|---|---|---|---|---|---|
| *Feng Shui* | Encyclopaedia Britannica | EN | encyclopedia | copyrighted | Có, theo dạng paraphrase ngắn | reference | 5 | tốt cho định nghĩa nền, không phải nguồn bảng lookup citeturn3search0 |
| *Qi* | Encyclopaedia Britannica | EN | encyclopedia | copyrighted | Có, paraphrase ngắn | glossary/reference | 5 | chốt thuật ngữ “khí” tốt hơn blog citeturn8search1 |
| *Yinyang* | Encyclopaedia Britannica | EN | encyclopedia | copyrighted | Có, paraphrase ngắn | glossary/core nền | 5 | dùng tốt cho định nghĩa triết học nền citeturn9search0 |
| *Wuxing* | Encyclopaedia Britannica | EN | encyclopedia | copyrighted | Có, paraphrase ngắn | glossary/core nền | 5 | tốt cho ngũ hành như “phases” citeturn8search2 |
| *Date and Time of the 24 Solar Terms* | Hong Kong Observatory | EN | government reference | public government web / copyrighted web presentation | Có | core thời gian | 5 | tốt để chốt cutoff Lập xuân citeturn28search0 |
| *葬書 / The Book of Burial* | Quy về Quách Phác / Guo Pu; bản mở tại Wikisource/ctext | ZH | classical text / scan / transcription | public domain or open transcription; needs edition check | Có | reference / quote ngắn | 4 | phải kiểm tra dị bản và nguồn bản khắc khi trích sâu citeturn4search7turn15search3turn15search8 |
| *地理辨正* | ctext transcription | ZH | classical text | open transcription / needs edition check | Có | reference | 4 | tốt cho truy vết “玄空”, không nên copy dài citeturn25search4turn25search0 |
| *陽宅指南* | ctext transcription | ZH | classical text | open transcription / needs edition check | Có | reference | 3 | hữu ích cho dwelling rules, cần đối chiếu bản in nếu dùng sâu citeturn25search2 |
| *Unraveling feng-shui* | S.-C. Chiou, R. Krishnamurti | EN | academic article PDF | copyrighted journal article | Có, dưới dạng trích dẫn học thuật ngắn | reference / concept core | 5 | nguồn rất mạnh cho Form vs Cosmology, Lo Shu, Later Heaven citeturn11view0turn12view0turn12view1 |
| *Identifying Feng Shui’s Form School Influence…* | Teh Boon Soon, Azizi Bahauddin | EN | academic article PDF | copyrighted academic article | Có, trích dẫn ngắn | reference | 4 | dùng tốt cho form-school design criteria citeturn23view0 |
| *An Introduction to Feng Shui* | Ole Bruun, Cambridge UP | EN | academic book | copyrighted | Có, metadata + internal reference | reference | 5 | không copy dài; rất mạnh cho reading list chính citeturn24search0turn24search3turn24search27 |
| *以八宅明鏡設計坎宅之研究* | 侯威銘 | ZH | academic article | copyrighted | Có, abstract/metadata | reference | 3 | tốt cho use-case mapping, không đủ để làm chân lý core citeturn18view4turn31search23 |
| *宮廟建築風水應用之探索…* | 方冠丁 | ZH | thesis abstract | copyrighted | Có, abstract/metadata | reference / caution | 3 | hữu ích cho period–renovation discussion, nhưng chưa nên coi là chuẩn duy nhất citeturn27view0 |
| *陽宅三要* | 趙九峰 | ZH | book metadata | copyrighted | Có, metadata only | reference | 4 | chỉ lưu metadata và source mapping citeturn31search0turn31search22 |
| *Eight Mansions Bright Mirror* | Terence Chan | EN | modern annotated translation | copyrighted | Có, metadata + internal reference | reference | 4 | rất phù hợp để đối chiếu bảng Ba Zhai sau khi mua/license hợp lệ citeturn31search13 |
| *The Original Eight Mansions Formula* | Stephen Skinner / Chang Ping Lin | EN | translation / modern edition | copyrighted | Có, internal reference | reference | 4 | đặc biệt mạnh cho phạm vi door-opening và 24 mountains citeturn19search25turn19search23turn18view3 |
| *沈氏玄空學* | 沈竹礽 | ZH | book metadata | copyrighted | Có, metadata + internal reference | reference | 4 | nguồn trụ cột cho Phi tinh hệ Thẩm thị, cần license khi khai thác sâu citeturn6search0 |
| *Xuan Kong Purple White Script* | Hung Hin Cheong | EN | modern study of classic | copyrighted | Có, internal reference | reference | 3 | tốt cho advanced phase, không cần cho phase 1 core citeturn31search10turn31search6 |
| HKU SPACE Period 9 event page | HKU SPACE | ZH/EN | educational event page | copyrighted | Có, metadata/reference | reference | 3 | dùng được để neo mốc 2024–2043, không dùng cho rule chi tiết citeturn16search6turn16search0 |
| Master Sean Chan period reference | Master Sean Chan | EN | practitioner reference | copyrighted | Có, nhưng chỉ candidate reference | candidate-core/reference | 3 | hữu ích cho period table và annual formula, cần đối chiếu nguồn in khi khóa engine citeturn18view1turn18view0 |
| Feng Shui Expert kua formula | Aude à la Déco | EN | practitioner reference | copyrighted | Có, candidate reference | candidate-core | 3 | ổn cho công thức life gua; cần thêm print-source để khóa core citeturn18view2 |
| FengShuiNexus Eight Types of Qi | Victor Cheung | EN | practitioner article | copyrighted | Có, candidate reference | reference | 2 | chỉ dùng cho meaning mềm và room-priority, không dùng làm core độc lập citeturn32view0 |

### License review

**Có thể dùng trực tiếp hơn** trong app hoặc pipeline dữ liệu gồm: các **metadata bibliographic**, các **bảng period/time** do team tự dựng lại từ nguồn tham khảo, các **định nghĩa nền đã paraphrase**, và các **classical texts/open transcriptions** ở mức trích ngắn có kiểm duyệt. Nhóm này chủ yếu gồm HKO, Britannica cho khái niệm nền, và các classical/open texts như *葬書*, *地理辨正*, *陽宅指南* — nhưng ngay cả với classical/open texts vẫn cần review edition để tránh lấy nhầm dị bản kém chất lượng. citeturn28search0turn8search1turn9search0turn8search2turn25search4turn25search2

**Chỉ nên dùng làm tham khảo nội bộ**, không chép nội dung dài, gồm gần như toàn bộ **sách hiện đại có bản quyền** và **bản dịch/chú giải hiện đại** như Bruun, Terence Chan, Skinner, *沈氏玄空學*, và các sách về *紫白訣*. Với nhóm này, app có thể lưu **title, author, year, ISBN, notes, source mapping**, nhưng không nên trích nội dung vượt quá mức fair quotation. citeturn24search3turn31search13turn19search25turn6search0turn31search10

**Nguồn không nên copy nội dung dài** gồm cả sách lẫn website practitioner có copyright, kể cả khi website hiển thị rất nhiều nội dung mở. Với practitioner sites, rủi ro không chỉ nằm ở copyright mà còn nằm ở việc **tài liệu thường đã pha diễn giải cá nhân**. Vì vậy pipeline tốt nhất là: dùng các nguồn này để lập **rule candidates**, rồi ghi lại thành **tri thức biên tập nội bộ** sau khi đội ngũ review chéo. citeturn18view1turn18view2turn32view0

**Nguồn cần xin phép hoặc kiểm tra bản quyền thêm** gồm: các luận văn/bài báo không open-license rõ ràng, các bản scan sách đương đại, và các translation hiện đại của cổ thư. **Nguồn nên loại bỏ khỏi core** gồm: pages bán vật phẩm/cure kits, social snippets, nội dung dùng câu chữ gây sợ hãi hay hứa hẹn chắc chắn.  

### Data filter rules

| Lớp dữ liệu | Tiêu chí giữ | Ví dụ |
|---|---|---|
| Core | Tính được, kiểm được, ngôn ngữ ổn định, ít tranh cãi | period table, Lập xuân cutoff, life gua formula, palace mapping |
| Reference | Có giá trị đối chiếu, nhưng còn phụ thuộc trường phái/biên soạn | 8 qi meanings, room-use mappings, period interpretations |
| Quote | Chỉ trích ngắn, có nguồn rõ, có mục đích minh họa | một câu từ *葬書* hoặc chú thích học thuật |
| Rejected | Thiếu provenance, thương mại hóa, ngôn ngữ hù dọa, kết luận cực đoan | blog cure-selling, “ở hướng này chắc chắn phá…” |

## JSON schema đề xuất, risk register, roadmap và câu hỏi cần chốt

### Rule object mẫu

```json
{
  "id": "PT-004",
  "module": "phi_tinh",
  "condition": {
    "room_type": "bedroom",
    "annual_star": [2, 5]
  },
  "result": {
    "action": "reduce_activity_keep_clean",
    "message_key": "bedroom_sensitive_annual_sector"
  },
  "explanation_plain": "Khu vực ngủ đang nằm trong annual sector cần ưu tiên giữ yên hơn; nên giảm động, giữ sạch và tránh kết luận quá mạnh.",
  "severity": "caution",
  "confidence": "reference",
  "source_refs": [
    "turn18view0",
    "turn7search7"
  ],
  "allowed_wording": [
    "nên ưu tiên giữ yên",
    "cần lưu ý thêm",
    "có thể cân nhắc giảm động"
  ],
  "forbidden_wording": [
    "đại hung",
    "ở là gặp họa",
    "chắc chắn xấu",
    "phải đổi nhà"
  ],
  "requires_human_review": false
}
```

### Gợi ý database

| Bảng | Mục đích |
|---|---|
| `sources` | registry nguồn, license, trust, usage note |
| `books` | metadata sách, ISBN, edition, copyright status |
| `chapters` | mapping chương/đoạn quan trọng, không lưu full copyrighted text nếu chưa đủ quyền |
| `rules_core` | rule đã duyệt cho engine |
| `rules_reference` | rule tham khảo, chờ kiểm duyệt |
| `glossary_terms` | Hán-Việt–Anh, định nghĩa ngắn, source refs |
| `star_meanings` | meaning mềm của 9 sao theo từng confidence tier |
| `direction_meanings` | meaning seed của 8 hướng / 8 qi |
| `palace_meanings` | meaning của 9 cung cho Phi tinh |
| `recommendations` | action gợi ý nhẹ theo room type |
| `caution_rules` | vùng cần cảnh báo/ngôn ngữ cần hạn chế |
| `source_refs` | join table nối rule ↔ source |
| `review_logs` | ai duyệt, duyệt ngày nào, rationale gì |

### Engine behavior

Engine không nên trả kết luận tuyệt đối. Engine nên luôn có một lớp **disclaimer ngắn**, nêu rõ đây là **hệ quy chiếu không gian–phương vị**, không phải hệ phán định vận mệnh.  

Nếu thiếu dữ liệu, engine phải nói rõ **thiếu dữ liệu gì**: chưa có hướng nhà, chưa chắc tọa-hướng, chưa có năm đại tu, chưa có room-to-sector mapping, hoặc chưa có khảo sát thực địa.  

Nếu rule mâu thuẫn, engine nên hiển thị **nhiều góc nhìn** với nhãn **core/reference/caution** thay vì ép thành một kết luận duy nhất.  

Nếu gặp vùng nhạy cảm như bệnh nặng, tai họa, kiện tụng, phá sản, sống chết, hôn nhân chắc chắn, engine phải chuyển sang wording kiểu **“nên tham khảo chuyên gia”** hoặc **“chưa đủ căn cứ để tự động kết luận”**.  

Về hành động, engine nên ưu tiên các gợi ý nhẹ: **dọn gọn, giảm động, tăng sáng, thông thoáng, cân nhắc đổi công năng nhẹ, tránh sửa chữa vào vùng nhạy cảm khi chưa đối chiếu thêm**.  

### Risk register

| Rủi ro | Khả năng | Tác động | Mô tả | Giảm thiểu |
|---|---|---|---|---|
| Sai cutoff năm | Trung bình | Cao | Lấy Tết âm thay vì Lập xuân sẽ làm lệch life gua/annual chart | khóa engine theo HKO solar terms |
| Sai hướng căn hộ | Cao | Cao | Apartment facing vs front door là điểm tranh luận | lưu cả `facing_direction` và `main_door_direction`; bắt review khi mơ hồ |
| Sai period của nhà | Trung bình | Cao | khác nhau giữa năm xây, nhập trạch, đại tu | thu đủ ba mốc và flag review |
| Quá phụ thuộc nguồn practitioner | Cao | Trung bình | dễ đưa rule thiếu provenance thành core | tách `candidate-core` khỏi `approved_core` |
| Rò rỉ bản quyền | Trung bình | Cao | vô tình copy dài từ sách/scan có bản quyền | chỉ lưu metadata + note + short quotes có kiểm soát |
| Ngôn ngữ quá mạnh | Cao | Cao | dễ biến app thành công cụ hù dọa | whitelist wording mềm + blacklist wording cấm |
| Bỏ qua hình thế thực địa | Cao | Trung bình | floor plan tốt chưa chắc site tốt | mọi kết quả chỉ theo “desk review”, không thay site audit |
| Trộn Bát trạch và Phi tinh thiếu governance | Trung bình | Trung bình | người dùng nhận output chồng chéo, khó hiểu | rule hierarchy: core/reference/caution + conflict policy |

### Roadmap engine phase đầu, phase sau và phase mở rộng

| Giai đoạn | Mục tiêu | Thành phần nên làm |
|---|---|---|
| Phase đầu | Dựng engine nhẹ, an toàn, có thể kiểm duyệt | life gua, East/West group, house kua seed, period table, annual chart, room-priority recommendations, license registry |
| Phase kế tiếp | Nâng độ chính xác và độ sâu | full natal flying-star chart, reviewed lookup tables từ bản in licensed, apartment-facing policy, renovation policy |
| Phase mở rộng | Hợp nhất lý khí với khảo sát thực địa | form survey inputs, landform checklist, expert override workflow, review logs, explainability layer |

### Danh sách câu hỏi cần chủ dự án chốt

- Có chốt **Lập xuân** là mốc năm bắt buộc cho cả Bát trạch lẫn niên tinh hay không.
- Với **căn hộ**, dự án muốn ưu tiên **front door**, **balcony/main opening**, hay giữ cả hai làm biến đầu vào.
- Có cho phép **house kua ưu tiên hơn life kua** trong phase đầu hay hiển thị song song.
- Với **Bát trạch**, có giữ đúng tinh thần hẹp hơn của Eight Mansions quanh **doorways/pathways/gates**, hay chấp nhận bản mở rộng hiện đại cho mọi phòng nhưng gán confidence thấp hơn.
- Với **Phi tinh**, phase đầu có chỉ làm **annual overlay** hay đã muốn nhập **build year / first occupancy / renovation years** ngay từ đầu.
- Dự án có muốn xây **lookup tables per-gua** như bảng seed trong báo cáo thành `approved_core` sau một vòng kiểm duyệt bằng sách in hay chưa.
- Có chấp nhận dùng **practitioner sources ở mức candidate reference** trong nội bộ hay phải đợi bổ sung thêm nguồn in có bản quyền/giấy phép sạch.
- Hệ severity cuối cùng muốn dùng thang **info / notice / caution / strong_caution** như báo cáo đề xuất hay một taxonomy khác.
- Có cần cơ chế **expert review queue** ngay từ phase đầu cho các case apartment-facing, renovation-reset, hoặc rule conflict.
- Có muốn glossary hiển thị song ngữ **Việt–Hán Việt–Anh** ngay trong app hay chỉ lưu ở backend/reference.

Theo bản đồ nguồn của vòng nghiên cứu này, bước tiếp theo hợp lý nhất để biến nguồn thô thành **Knowledge Base** là: **chốt source registry**, **mua/đăng ký hợp lệ một số sách bản quyền then chốt**, **kiểm duyệt lại bảng lookup Bát trạch bằng bản in**, **đóng gói period/annual algorithms của Phi tinh thành core tables**, rồi mới tách các rule sang ba lớp **approved_core / reference / caution**. Cách đi này tận dụng được phần tính được trước, nhưng vẫn giữ app trong vùng ngôn ngữ nghiên cứu, mềm và có kiểm soát.