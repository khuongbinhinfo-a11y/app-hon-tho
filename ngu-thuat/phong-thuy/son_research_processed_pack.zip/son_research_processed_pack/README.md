# Sơn research processed pack

Gói này được xử lý từ file `deep-research-report(1).md`.

## Mục tiêu

Biến báo cáo nghiên cứu chuyên sâu thành dữ liệu dễ dùng cho:

- mini-app Sơn UI
- rule engine seed
- glossary
- source/license review
- risk register
- roadmap
- prompt giao dev/data reviewer

## Trạng thái

`research_processed_candidate`

Chưa phải dữ liệu production. Những phần có `needs_review`, `reference`, `caution` cần kiểm duyệt trước khi khóa engine.

## Cấu trúc

```text
original/
  deep-research-report.md

docs/
  01_EXECUTIVE_SUMMARY_CLEAN.md
  02_ENGINE_DECISION.md
  03_DEV_INTEGRATION_GUIDE.md
  04_REVIEW_QUEUE.md
  05_COPYWRITING_GUARDRAILS.md

data/
  son_research_manifest.json
  glossary/
  bat_trach/
  phi_tinh/
  governance/

schemas/
  son-bat-trach-engine.schema.json
  son-phi-tinh-engine.schema.json
  son-rule-object.schema.json
  son-knowledge-base.schema.json
  *_example.json

src-ready/
  features/son/data/*.ts
  features/son/engine/*.ts

prompts/
  PROMPT_GIAO_DEV_XU_LY_RESEARCH.txt
  PROMPT_DATA_REVIEWER.txt
```

## Counts

```json
{
  "concept_terms": 20,
  "glossary_seed": 20,
  "sources": 22,
  "candidate_rules": 10,
  "do_not_automate_rules": 8,
  "risk_items": 8,
  "roadmap_phases": 3
}
```

## Cách dùng nhanh

1. Dev copy `src-ready/features/son` vào `src/features/son`.
2. UI dùng các seed để render glossary, sơ đồ, rule explain.
3. Engine thật chỉ dùng rule đã qua review.
4. Không public kết luận phong thủy thật từ dữ liệu candidate.
