# Data tables chính

## Tam đình

| ID | Tên | Vị trí | Safe reading | Risk |
| --- | --- | --- | --- | --- |
| thuong_dinh | Thượng đình | Vùng từ chân tóc đến khoảng giữa hai đầu lông mày, thường quy về vùng trán. | Thượng đình chỉ nên đọc như vùng quan sát về sự cân bằng phần trên khuôn mặt, không dùng để kết luận trí tuệ hay xuất thân. | medium |
| trung_dinh | Trung đình | Vùng từ lông mày đến dưới mũi, gồm mắt, mũi, gò má và vùng trung tâm mặt. | Trung đình có thể được ghi nhận như vùng nổi bật của tổng thể, nhưng cần đối chiếu với thần, khí, sắc và bối cảnh sống. | medium |
| ha_dinh | Hạ đình | Vùng từ dưới mũi đến hết cằm, gồm miệng, môi, nhân trung, hàm và cằm. | Hạ đình chỉ là một vùng quan sát, không dùng để phán tuổi già, phúc phận, con cái hay hôn nhân. | medium |

## Ngũ quan

| ID | Tên | Vai trò | Safe reading | Risk |
| --- | --- | --- | --- | --- |
| eyebrows | Lông mày | Trong ngũ quan, lông mày thường được đọc như nét phụ trợ của thần thái, nhịp khí và sự hài hòa vùng mắt. | Lông mày nên được quan sát cùng mắt và thần sắc; không đọc riêng để kết luận tính cách hay đạo đức. | medium |
| eyes | Mắt | Trong cổ học, mắt thường được xem là vùng biểu hiện thần, sự chú ý và độ tỉnh/tán của thần sắc. | Mắt là vùng dễ bị diễn giải quá mức; chỉ nên ghi nhận thần thái nhất thời và cần xét giấc ngủ, ánh sáng, cảm xúc, sức khỏe. | high |
| nose | Mũi | Mũi là vùng trung tâm khuôn mặt, trong cổ học thường được dùng để quan sát thế trung đình và sự cân xứng tổng thể. | Mũi chỉ nên dùng như dữ liệu hình học và cân bằng vùng trung tâm; không dùng để phán giàu nghèo hay thành bại. | high |
| mouth | Miệng | Miệng thường được đọc cùng thanh âm, biểu cảm và cách giao tiếp, nhưng dễ bị định kiến nếu đọc cứng. | Miệng nên được xem như vùng biểu cảm và giao tiếp trong cổ học, không kết luận lời nói, đạo đức hay tình cảm. | high |
| ears | Tai | Tai trong cổ học thường được xem như vùng phụ trợ về hình khí tổng thể và thời kỳ đầu đời theo một số truyền thống. | Tai chỉ là dữ liệu hình tướng phụ trợ; không dùng để phán tuổi thọ, gia thế, trí tuệ hay phúc phận. | medium |

## Thập nhị cung

| ID | Tên | Vị trí | Safe reading | Status | Risk |
| --- | --- | --- | --- | --- | --- |
| menh_cung | Mệnh cung | Vùng ấn đường, khoảng giữa hai đầu lông mày. | Mệnh cung chỉ nên dùng như mục tra cứu vị trí và ý nghĩa truyền thống; không dùng để phán chắc về đời sống cá nhân. | candidate | medium |
| tai_bach_cung | Tài bạch cung | Thường quy về vùng mũi, nhất là đầu mũi và cánh mũi. | Tài bạch cung chỉ nên dùng như mục tra cứu vị trí và ý nghĩa truyền thống; không dùng để phán chắc về tài vận. | candidate | high |
| huynh_de_cung | Huynh đệ cung | Thường quy về vùng lông mày. | Huynh đệ cung chỉ nên dùng như mục tra cứu vị trí và ý nghĩa truyền thống; không dùng để phán chắc về đời sống cá nhân. | candidate | medium |
| dien_trach_cung | Điền trạch cung | Vùng quanh mắt, khoảng giữa mắt và lông mày theo nhiều truyền thống. | Điền trạch cung chỉ nên dùng như mục tra cứu vị trí và ý nghĩa truyền thống; không dùng để phán chắc về đời sống cá nhân. | candidate | medium |
| tu_tuc_cung | Tử tức cung | Vùng dưới mắt, lệ đường. | Tử tức cung chỉ nên dùng như mục tra cứu vị trí và ý nghĩa truyền thống; không dùng để phán chắc về đời sống cá nhân. | needs_review | high |
| no_boc_cung | Nô bộc cung | Vùng hai bên cằm/hạ đình theo một số truyền thống. | Nô bộc cung chỉ nên dùng như mục tra cứu vị trí và ý nghĩa truyền thống; không dùng để phán chắc về đời sống cá nhân. | candidate | medium |
| phu_the_cung | Phu thê cung | Vùng đuôi mắt, gian môn. | Phu thê cung chỉ nên dùng như mục tra cứu vị trí và ý nghĩa truyền thống; không dùng để phán chắc về hôn nhân. | needs_review | high |
| tat_ach_cung | Tật ách cung | Vùng sơn căn/gốc mũi. | Tật ách cung chỉ nên dùng như mục tra cứu vị trí và ý nghĩa truyền thống; không dùng để phán chắc về sức khỏe. | needs_review | high |
| thien_di_cung | Thiên di cung | Hai bên trán/góc trán ngoài. | Thiên di cung chỉ nên dùng như mục tra cứu vị trí và ý nghĩa truyền thống; không dùng để phán chắc về đời sống cá nhân. | candidate | medium |
| quan_loc_cung | Quan lộc cung | Vùng giữa trán theo đường dọc trung tâm. | Quan lộc cung chỉ nên dùng như mục tra cứu vị trí và ý nghĩa truyền thống; không dùng để phán chắc về đời sống cá nhân. | candidate | medium |
| phuc_duc_cung | Phúc đức cung | Vùng hai bên trán/thái dương theo một số hệ. | Phúc đức cung chỉ nên dùng như mục tra cứu vị trí và ý nghĩa truyền thống; không dùng để phán chắc về đời sống cá nhân. | candidate | medium |
| phu_mau_cung | Phụ mẫu cung | Vùng nhật nguyệt giác, hai góc trán phía trên. | Phụ mẫu cung chỉ nên dùng như mục tra cứu vị trí và ý nghĩa truyền thống; không dùng để phán chắc về đời sống cá nhân. | candidate | medium |

## Vùng mặt

| ID | Tên | Vị trí | Status | Risk |
| --- | --- | --- | --- | --- |
| forehead | Trán | Vùng phía trên lông mày đến chân tóc. | candidate | medium |
| yin_tang | Ấn đường | Khoảng giữa hai đầu lông mày. | candidate | medium |
| shan_gen | Sơn căn | Gốc mũi, vùng nối giữa hai mắt và sống mũi. | candidate | medium |
| eyes_region | Vùng mắt | Hai mắt và vùng mí mắt. | candidate | medium |
| eyebrows_region | Lông mày | Dải lông phía trên mắt. | candidate | medium |
| nose_bridge | Sống mũi | Đường dọc từ sơn căn đến đầu mũi. | candidate | medium |
| nose_tip | Đầu mũi | Phần chóp mũi. | candidate | medium |
| nostrils | Cánh mũi | Hai bên đầu mũi. | candidate | medium |
| cheekbones | Gò má/Lưỡng quyền | Hai vùng xương gò má dưới mắt. | candidate | medium |
| philtrum | Nhân trung | Rãnh dọc giữa mũi và môi trên. | needs_review | high |
| mouth_region | Miệng | Vùng miệng gồm môi và khóe miệng. | candidate | medium |
| lips | Môi | Môi trên và môi dưới. | candidate | medium |
| chin | Cằm | Vùng dưới môi đến hết cằm. | candidate | medium |
| jaw | Hàm | Hai bên hàm dưới. | candidate | medium |
| ears_region | Tai | Hai tai và vành tai. | candidate | medium |
| nasolabial | Pháp lệnh | Hai đường từ cánh mũi xuống quanh miệng, nếu có. | needs_review | medium |
| temples | Thái dương | Hai bên đầu gần đuôi lông mày/đuôi mắt. | candidate | medium |
| under_eye | Lệ đường | Vùng dưới mắt. | needs_review | high |
| outer_eye | Gian môn/đuôi mắt | Vùng đuôi mắt hai bên. | needs_review | high |
| hairline | Chân tóc | Đường tiếp giáp tóc và trán. | candidate | medium |

## Khí - sắc - thần

| ID | Tên | Định nghĩa | Risk |
| --- | --- | --- | --- |
| than | Thần | Trạng thái sống động/tỉnh/tán/mệt trong thần thái. | medium |
| khi | Khí | Khái niệm cổ học chỉ cảm giác sinh lực, nhịp và độ liền mạch của diện mạo. | medium |
| sac | Sắc | Màu và độ nhuận/khô/tươi/xỉn quan sát bên ngoài. | medium |
| hinh | Hình | Cấu trúc và tỷ lệ quan sát được của mặt/thân. | medium |
| thanh | Thanh âm | Giọng nói/nhịp nói trong quan sát cổ học. | medium |
| anh_mat | Ánh mắt | Một phần của thần, thường được người xưa xem là dấu hiệu cần quan sát kỹ. | medium |
| sac_mat | Sắc mặt | Màu sắc và độ tươi của da mặt trong điều kiện quan sát. | high |
| tuoi_nhuan | Tươi nhuận | Cách nói cổ học về cảm giác tươi, có sinh khí, không khô trệ. | medium |
| kho_tre | Khô trệ | Cách nói cổ học về cảm giác thiếu tươi, nặng, bí hoặc mệt. | high |
| dong_thai | Động thái | Cách di chuyển, cử động, nhịp biểu cảm. | medium |

## Knowledge cards

Tổng số: **224** card.

File đầy đủ: `data/knowledge_cards.json`.
