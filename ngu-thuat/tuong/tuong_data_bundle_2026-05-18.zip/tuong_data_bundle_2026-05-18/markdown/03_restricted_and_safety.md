# Restricted và safety

## Safety rules

| ID | Tiêu đề | Rule | Mức |
| --- | --- | --- | --- |
| no_absolute_fate | Không phán số phận tuyệt đối | Mọi kết quả phải dùng ngôn ngữ tham khảo, tránh khẳng định chắc chắn về vận mệnh, giàu nghèo, hôn nhân, tuổi thọ. | block |
| no_morality_judgement | Không phán đạo đức | Không gắn mắt, mày, mũi, miệng, dáng đi hoặc sắc mặt với tốt/xấu, ác/gian, trung/thật. | block |
| no_medical_diagnosis | Không chẩn đoán bệnh | Không kết luận bệnh, bệnh nặng, di truyền, vô sinh, tuổi thọ hoặc tình trạng y tế từ mặt. | block |
| no_crime_prediction | Không dự đoán tội phạm | Không dùng khuôn mặt để dự đoán xu hướng phạm tội, gian dối hay nguy hiểm. | block |
| no_identity_recognition | Không nhận diện danh tính | MVP không upload ảnh và không nhận diện người. Nếu có ảnh ở phase sau, ảnh chỉ dùng làm lớp tham chiếu để người dùng tự đánh dấu vùng học tập. | block |
| no_decision_automation | Không quyết định thay người dùng | Không dùng kết quả cho tuyển dụng, tín dụng, tình cảm, hôn nhân, pháp lý, y tế. | block |
| no_body_shaming | Không miệt thị ngoại hình | Không dùng từ xúc phạm, chê bai, gán giá trị con người với gương mặt/cơ thể. | block |
| confidence_required | Luôn hiển thị mức đủ dữ liệu | Nếu thiếu nhiều trường quan sát, kết quả phải nói dữ liệu chưa đủ thay vì diễn giải dài. | warn |
| uncertain_option | Luôn có lựa chọn Không chắc/Bỏ qua | Mọi input tự quan sát phải cho phép người dùng chọn không chắc hoặc bỏ qua. | warn |
| single_feature_limit | Không đọc một bộ vị riêng lẻ | Nếu người dùng chỉ nhập một vùng, app chỉ trả lời tra cứu, không tạo báo cáo tổng hợp. | warn |

## Restricted rules

| ID | Nội dung | Vì sao nguy hiểm | Chuyển an toàn | Status |
| --- | --- | --- | --- | --- |
| judge_evil_eyes | Phán người gian ác qua mắt | Dễ quy kết đạo đức, xúc phạm và phân biệt đối xử. | Chuyển thành: ánh mắt là vùng biểu hiện thần thái nhất thời; cần quan sát trong bối cảnh, không kết luận đạo đức. | restricted |
| judge_infidelity | Phán ngoại tình/bạc tình qua tướng | Có thể gây tổn thương, xung đột tình cảm và quyết định sai. | Chỉ giữ như mục cảnh báo: không dùng tướng để quyết định quan hệ. | rejected |
| predict_early_death | Phán chết yểu/đoản thọ | Gây sợ hãi, không có cơ sở để nói chắc và liên quan y tế. | Không chuyển thành câu người dùng phổ thông. Đưa vào restricted. | rejected |
| diagnose_disease | Phán bệnh cụ thể qua mặt | Rủi ro y tế, có thể trì hoãn khám chữa bệnh. | Chỉ nói: nếu dấu hiệu bất thường kéo dài, hãy hỏi chuyên gia y tế. | restricted |
| predict_wealth | Phán giàu nghèo chắc chắn | Quy giản con người và gây mê tín quyết định tài chính. | Chuyển thành: vùng này trong cổ học gắn với biểu tượng nguồn lực, không dự đoán tài chính. | restricted |
| predict_marriage_failure | Phán hôn nhân đổ vỡ | Gây bất an và quyết định quan hệ sai. | Chỉ tra cứu vị trí Phu thê cung, không dự đoán kết quả quan hệ. | restricted |
| predict_children | Phán con cái/vô sinh | Rủi ro y tế và cảm xúc cao. | Không đưa ra kết luận; đánh dấu needs_review hoặc restricted. | restricted |
| judge_intelligence | Phán trí tuệ | Kỳ thị ngoại hình và sai về mặt khoa học. | Chuyển thành quan sát hình học thượng đình, không phán trí tuệ. | restricted |
| judge_character | Phán đạo đức cá nhân | Đánh giá con người bằng ngoại hình, rủi ro phân biệt đối xử. | Không dùng; chỉ nói về thuật ngữ và bối cảnh cổ học. | rejected |
| predict_crime | Phán tội phạm | Rủi ro đạo đức/pháp lý rất cao. | Từ chối; app không hỗ trợ. | rejected |
| body_shaming | Miệt thị cơ thể | Gây tổn thương và phân biệt đối xử. | Dùng mô tả trung tính, chỉ ghi nhận dữ liệu quan sát. | restricted |
| rank_human_score | Chấm điểm con người | Tạo ảo giác thẩm quyền và quyết định bất lợi. | Nếu cần điểm, chỉ dùng mức đủ dữ liệu/cân bằng quan sát. | restricted |
| employment_screening | Dùng cho tuyển dụng | Rủi ro phân biệt đối xử và sai mục đích. | App hiển thị cảnh báo không dùng cho tuyển dụng. | rejected |
| credit_screening | Dùng cho tín dụng | Rủi ro pháp lý và đạo đức. | Từ chối; app không hỗ trợ. | rejected |
| legal_screening | Dùng cho pháp lý | Rủi ro rất cao. | Từ chối; app không hỗ trợ. | rejected |
| romantic_decision | Quyết định yêu/cưới bằng tướng | Có thể gây tổn hại quan hệ và tự chủ cá nhân. | Chỉ dùng để học thuật ngữ, không quyết định thay người dùng. | restricted |
| race_ethnicity_inference | Suy luận chủng tộc/sắc tộc | Rủi ro phân biệt đối xử và pháp lý. | Không hỗ trợ. | rejected |
| biometric_identity | Nhận diện danh tính | Liên quan dữ liệu sinh trắc học và riêng tư. | MVP không dùng ảnh; phase sau chỉ đánh dấu vùng học tập. | restricted |

## Câu cảnh báo mặc định

```text
Kết quả chỉ có giá trị tham khảo theo văn hóa cổ học. Không dùng để kết luận nhân phẩm, sức khỏe, năng lực, số phận hay đưa ra quyết định quan trọng về người khác.
```

```text
Dữ liệu quan sát hiện chưa đủ để kết luận tổng thể. Nên xem đây là gợi ý tự soi chiếu, không phải kết luận về con người.
```

```text
App không hỗ trợ đánh giá đạo đức, bệnh tật, tội phạm, tài vận, hôn nhân, tuổi thọ hoặc số phận từ ngoại hình.
```
