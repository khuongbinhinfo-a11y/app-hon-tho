# Bản đồ kiến thức nhánh Tướng

## Định vị

**Tướng - Xem tướng tham khảo** là công cụ học cổ học, tra cứu thuật ngữ và tự quan sát.

Không dùng app như máy phán tướng, không đánh giá người khác, không quyết định thay người dùng.

## Route

```text
/nguthuat/tuong/xem-tuong
```

## Module chính

| ID | Tên | Mục đích |
| --- | --- | --- |
| theory | Khung nền nhân tướng học | Giải thích thuật ngữ nền: hình, thần, khí, sắc, thanh, động/tĩnh tướng. |
| three_courts | Tam đình | Học cách chia khuôn mặt thành thượng/trung/hạ đình và đọc cân bằng tổng thể. |
| five_features | Ngũ quan | Tra cứu mày, mắt, mũi, miệng, tai theo tiêu chí quan sát mềm. |
| twelve_palaces | Thập nhị cung | Bản đồ vị trí và ý nghĩa truyền thống của 12 cung trên mặt. |
| face_regions | Vùng mặt cơ bản | Từ điển vùng mặt để người dùng tự đánh dấu/ghi chú. |
| qi_color_spirit | Khí - sắc - thần | Ghi chú thần thái và khí sắc theo ngày, không y tế hóa. |
| body_posture | Dáng vẻ/cử chỉ | Quan sát phong thái ở mức văn hóa, không body-shaming. |
| safety | Hàng rào an toàn | Chặn các câu phán xét, phán bệnh, phán đạo đức, phán số phận. |

## Luồng MVP đề xuất

1. Người dùng đọc nguyên tắc.
2. Chọn kiểu xem: tổng quan, Tam đình, Ngũ quan, 12 cung, từ điển.
3. Nhập dữ liệu thủ công bằng card.
4. Có lựa chọn `Không chắc / Bỏ qua`.
5. App trả kết quả mềm:
   - Tổng quan quan sát
   - Điểm nổi bật
   - Điểm chưa đủ dữ liệu
   - Diễn giải cổ học tham khảo
   - Gợi ý tự soi chiếu
6. Không có điểm tốt/xấu hoặc vận mệnh.

## Câu hero gợi ý

```text
Tướng - Xem tướng tham khảo
Quan sát hình, thần, khí, sắc theo hệ thống cổ học. Nội dung dùng để học hiểu và tự soi chiếu, không thay thế tư duy độc lập hay đánh giá chuyên môn.
```
