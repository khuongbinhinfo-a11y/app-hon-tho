# MVP roadmap cho app Tướng

| Phase | Mục tiêu | Có | Không có |
| --- | --- | --- | --- |
| MVP 1 | Thư viện và form tự quan sát an toàn | từ điển nhân tướng học<br>Tam đình<br>Ngũ quan<br>12 cung<br>vùng mặt cơ bản<br>cảnh báo an toàn<br>form thủ công<br>kết quả rule-based mềm | upload ảnh<br>AI nhận diện<br>chấm điểm tốt/xấu<br>lưu lịch sử<br>login<br>credit |
| MVP 2 | Nhật ký tự quan sát và học theo ngày | nhật ký khí sắc/thần thái<br>checklist tự quan sát<br>thẻ kiến thức liên quan<br>phân loại thuật ngữ<br>báo cáo mềm theo ngày | tự động đọc ảnh<br>ra quyết định<br>phán bệnh |
| MVP 3 | Ảnh chỉ làm bản đồ học tập nếu cần | người dùng tự tải ảnh nếu đồng ý<br>vẽ khung vùng mặt<br>người dùng tự xác nhận đặc điểm | nhận diện danh tính<br>AI tự phán tốt/xấu<br>suy luận sinh trắc học<br>lưu ảnh mặc định |

## Câu kết luận triển khai

MVP 1 nên là thư viện + form tự quan sát + kết quả mềm.

Không làm upload ảnh, nhận diện ảnh, phán tốt/xấu, phán vận mệnh hoặc lưu lịch sử phức tạp.
