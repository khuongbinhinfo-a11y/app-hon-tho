# Giao việc cho dev/data team

## Mục tiêu

Dựng data layer cho route:

```text
/nguthuat/tuong/xem-tuong
```

Không làm lan sang Tứ Trụ, Phong thủy, Y học, Mai Hoa.

## Việc cần làm

1. Import các file trong `data/`.
2. Ưu tiên guardrail:
   - `safety_rules.json`
   - `restricted_rules.json`
3. Tạo trang học/tra cứu:
   - Tam đình
   - Ngũ quan
   - Thập nhị cung
   - Vùng mặt
   - Khí/sắc/thần
4. Tạo form tự quan sát thủ công từ:
   - `observation_checklists.json`
5. Tạo kết quả mềm từ:
   - `interpretation_templates.json`
6. Dùng `knowledge_cards.json` làm kho card.

## Không được làm

- Không upload ảnh ở MVP.
- Không nhận diện danh tính.
- Không tự động phán mặt.
- Không chấm điểm vận mệnh.
- Không nói người tốt/xấu, gian/ác, bệnh, giàu/nghèo, hôn nhân, tuổi thọ.

## Output kết quả nên có

```text
1. Tổng quan quan sát
2. Điểm nổi bật
3. Điểm chưa đủ dữ liệu
4. Diễn giải cổ học tham khảo
5. Gợi ý tự soi chiếu
6. Cảnh báo an toàn
```

## Nếu người dùng hỏi phán người khác

Trả guardrail:

```text
App không hỗ trợ kết luận về đạo đức, sức khỏe, tài vận, hôn nhân, tội phạm hoặc số phận từ ngoại hình. Bạn có thể dùng chế độ tra cứu thuật ngữ hoặc tự ghi chú quan sát.
```
