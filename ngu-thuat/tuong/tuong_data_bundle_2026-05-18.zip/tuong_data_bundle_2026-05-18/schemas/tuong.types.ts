export type TuongSystem =
  | 'nhan_tuong'
  | 'face_reading'
  | 'body_observation'
  | 'palm_basic'
  | 'general'

export type TuongCategory =
  | 'theory'
  | 'face_region'
  | 'five_features'
  | 'five_organs_face'
  | 'twelve_palaces'
  | 'three_courts'
  | 'qi_color_spirit'
  | 'body_posture'
  | 'palm_basic'
  | 'glossary'
  | 'safety'
  | 'restricted'

export type SourceLevel =
  | 'classical'
  | 'modern_interpretation'
  | 'common_knowledge'
  | 'needs_review'

export type ReviewStatus =
  | 'candidate'
  | 'needs_review'
  | 'approved_basic'
  | 'restricted'

export type AppUseCase =
  | 'lookup'
  | 'onboarding'
  | 'self_observation'
  | 'glossary'
  | 'safety_guardrail'

export type RiskLevel = 'low' | 'medium' | 'high'

export type KnowledgeCard = {
  id: string
  branch: 'tuong'
  system: TuongSystem
  category: TuongCategory
  title: string
  han?: string
  han_viet?: string
  summary: string
  details: string[]
  observation_points: string[]
  safe_reading: string
  avoid_claims: string[]
  warning: string
  tags: string[]
  source_level: SourceLevel
  status: ReviewStatus
  app_use_case: AppUseCase
  risk_level: RiskLevel
}
