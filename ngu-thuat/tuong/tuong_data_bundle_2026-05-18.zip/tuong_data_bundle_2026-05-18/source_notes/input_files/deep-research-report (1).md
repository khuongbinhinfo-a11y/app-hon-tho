# Nghiên cứu data nhân tướng học và phân tích học máy đặc trưng khuôn mặt

## Tóm tắt điều hành

Nhân tướng học, xét theo lịch sử tư tưởng, là truyền thống gán ý nghĩa về tính cách hay số phận cho diện mạo cơ thể và khuôn mặt. Các văn bản kinh điển phương Tây như *Physiognomonica* gắn với truyền thống Aristotle/Pseudo-Aristotle và các trước tác của Lavater cho thấy lĩnh vực này từng có vị thế học thuật trong nhiều thế kỷ; tuy nhiên, các tổng quan lịch sử đương đại và triển lãm của U.S. National Library of Medicine đều xem nhân tướng học là một giả khoa học đã bị bác bỏ, đồng thời nhấn mạnh mối liên hệ của nó với phân loại chủng tộc, ưu sinh học và các hình thức quy kết bản chất từ ngoại hình. citeturn10search1turn10search4turn10search3turn9search27

Trong thời đại học máy, ý tưởng “đọc người qua mặt” quay trở lại dưới dạng phân loại từ ảnh khuôn mặt. Nhưng phần lớn phê bình học thuật hiện đại cho rằng việc suy ra các thuộc tính chuẩn tắc hoặc khó kiểm chứng như đạo đức, xu hướng phạm tội, trí tuệ, năng lực nghề nghiệp, hay “số mệnh” từ ảnh mặt là không đủ cơ sở khoa học và có rủi ro đạo đức rất cao. Các nghiên cứu phê bình gọi đây là sự “hồi sinh” của physiognomy bằng AI, nhấn mạnh rằng loại hệ thống này dễ tái tạo các lịch sử kỳ thị chủng tộc, giới và giai tầng dưới vỏ bọc tính toán. citeturn9search1turn9search14turn9search22turn8search18turn37search8

Về mặt dữ liệu, các bộ dữ liệu khuôn mặt công khai phổ biến như LFW, CelebA, VGGFace2, UTKFace, FairFace và RFW chủ yếu được thiết kế cho nhận dạng khuôn mặt, thuộc tính khuôn mặt, tuổi, giới, hoặc kiểm thử công bằng; chúng **không** được xây dựng như bộ dữ liệu hợp lệ để suy luận nhân cách hay vận mệnh. Nhiều bộ dữ liệu được thu từ Internet, Google Image Search, Flickr, báo chí hoặc ảnh người nổi tiếng; do đó, các vấn đề về đồng ý, giấy phép, mục đích sử dụng và tái sử dụng thương mại là trọng yếu ngay từ giai đoạn thu thập dữ liệu. citeturn31view0turn32view0turn29view0turn34view0turn33view0turn14search2

Về kỹ thuật, trích xuất đặc trưng khuôn mặt hiện đại đi từ landmark/hình học, đến face embeddings kiểu FaceNet/ArcFace, rồi các CNN và Vision Transformer. Tuy vậy, đối với nghiên cứu “nhân tướng học”, các mô hình mạnh hơn không giải quyết được vấn đề cốt lõi là **tính hợp lệ của nhãn**. Một mô hình có AUC cao trên nhãn “tính cách”, “thành công”, hay “xu hướng phạm tội” không chứng minh rằng hiện tượng được dự đoán là bản chất khuôn mặt; nó có thể chỉ học các proxy về giai cấp, chất lượng ảnh, bối cảnh, phong cách chụp, hoặc thiên lệch thể chế. citeturn15search0turn15search9turn16search7turn16search31turn37search3turn37news31turn17search12

Đánh giá mô hình trong lĩnh vực này phải nghiêm ngặt hơn các benchmark thông thường. Các chuẩn tối thiểu nên gồm: chia tập theo **identity-disjoint** để tránh trùng người giữa train/test; kiểm tra rò rỉ dữ liệu và rò rỉ danh tính; báo cáo độ chính xác tổng thể **và** sai lệch theo nhóm; kiểm tra giao cắt nhóm bảo vệ; đánh giá độ bền trước mask, blur, nén JPEG, occlusion và phân phối lệch miền. NIST và các nghiên cứu fairness gần đây đều cho thấy hiệu năng nhận dạng khuôn mặt có thể khác biệt đáng kể giữa các nhóm dân số và trong điều kiện che khuất. citeturn17search3turn17search12turn17search0turn17search4turn17search1turn18search0turn18search13turn18search15

Về pháp lý, ảnh mặt là dữ liệu cá nhân; dưới GDPR, chúng trở thành “dữ liệu sinh trắc học” theo nghĩa đặc biệt khi trải qua xử lý kỹ thuật để cho phép hoặc xác nhận nhận dạng duy nhất. Khung pháp lý EU và Việt Nam hiện đều đặt mức rào chắn cao cho xử lý dữ liệu khuôn mặt, đặc biệt là dữ liệu sinh trắc học, bao gồm yêu cầu đồng ý rõ ràng trong nhiều trường hợp, giới hạn mục đích, kiểm soát truy cập, bảo mật, thời hạn lưu giữ và nghĩa vụ giải trình. AI Act của EU còn cấm một số thực hành như cào vét ảnh mặt không định hướng từ Internet/CCTV để tạo hoặc mở rộng cơ sở dữ liệu nhận dạng khuôn mặt. Ở Việt Nam, Luật Bảo vệ dữ liệu cá nhân số 91/2025/QH15 có hiệu lực từ 01/01/2026, cùng Nghị định 356/2025/NĐ-CP quy định chi tiết, đã bổ sung khuôn khổ rõ hơn cho dữ liệu sinh trắc học và quyền của chủ thể dữ liệu. citeturn19search2turn19search8turn19search1turn19search4turn0search7turn5view3turn25search8turn24search7turn27search0turn6view1turn6view2

Kết luận chính của báo cáo này là: **nếu mục tiêu là xây dựng hệ thống suy luận nhân cách, đạo đức, phạm tội, tài vận, hôn nhân hay số phận từ khuôn mặt, hướng nghiên cứu đó không nên được triển khai như một hệ thống thực tế**. Nếu mục tiêu là nghiên cứu học thuật về dữ liệu khuôn mặt, hình thái học, ontology vùng mặt kiểu Tam đình/Ngũ quan, hoặc đánh giá công bằng và khả năng giải thích của mô hình, thì có thể thực hiện một pipeline nghiên cứu tái lập được, nhưng phải giới hạn ở nhãn quan sát được, có cơ sở pháp lý, có guardrail đạo đức nghiêm ngặt, và không dùng kết quả cho quyết định bất lợi đối với con người. citeturn9search1turn9search27turn14search1turn14search2turn19search3turn25search8

Bốn tham số quan trọng hiện **chưa được đặc tả** trong yêu cầu này là ứng dụng đích, chỉ tiêu hiệu năng, ngân sách và timeline triển khai. Vì vậy, phần kế hoạch thực nghiệm bên dưới được trình bày như một **lộ trình nghiên cứu mẫu**, không phải cam kết triển khai sản phẩm.

| Hạng mục | Trạng thái hiện tại |
|---|---|
| Ứng dụng đích | Chưa đặc tả |
| Chỉ tiêu hiệu năng | Chưa đặc tả |
| Ngân sách | Chưa đặc tả |
| Timeline triển khai | Chưa đặc tả |

## Khung nghiên cứu và tổng quan học thuật

### Ranh giới khái niệm

Nếu phải làm việc với chủ đề “nhân tướng học” trong bối cảnh nghiên cứu dữ liệu và học máy, điều đầu tiên cần làm là tách ba lớp khái niệm ra khỏi nhau. Lớp thứ nhất là **lịch sử tư tưởng**: các hệ thống cổ điển như *Physiognomonica* và Lavater mô tả cách liên hệ diện mạo với tâm tính. Lớp thứ hai là **tâm lý học nhận thức**: con người thực sự có xu hướng hình thành phán đoán rất nhanh từ khuôn mặt, nhưng điều đó chỉ cho thấy hiện tượng nhận thức xã hội, không phải độ đúng của những phán đoán ấy. Lớp thứ ba là **học máy hiện đại**: mô hình có thể học quy luật thống kê trong ảnh, nhưng giá trị của nó phụ thuộc vào việc nhãn có phản ánh một hiện tượng hợp lệ và có thể kiểm chứng hay không. citeturn10search1turn10search4turn8search4turn9search2turn9search1

Các nguồn lịch sử chính cho thấy nhân tướng học có chiều sâu văn bản lâu dài. Bộ *Minor Works* chứa *Physiognomonica* trong truyền thống Aristotle/Pseudo-Aristotle, còn Lavater xuất bản nhiều tập *Essays on Physiognomy* với tham vọng hệ thống hóa “đọc người qua mặt” trong thế kỷ XVIII. Đồng thời, National Library of Medicine mô tả rất rõ rằng sức ảnh hưởng lịch sử ấy không đồng nghĩa với tính khoa học hiện nay; ngược lại, physiognomy ngày nay được xem là đã bị bác bỏ và có di sản gắn với phân loại chủng tộc và ưu sinh học. citeturn10search1turn10search5turn10search4turn10search3turn10search11

### Từ phán đoán khuôn mặt đến phê bình học thuật hiện đại

Tâm lý học hiện đại ghi nhận rằng con người hình thành ấn tượng rất nhanh từ khuôn mặt, và lĩnh vực nghiên cứu face perception từng tạo ra một “sự hồi sinh” hạn chế của quan tâm đến physiognomy theo nghĩa mô tả hành vi phán đoán của con người. Nhưng các bài tổng quan cũng nhấn mạnh khác biệt giữa “con người thường phán đoán từ khuôn mặt” với “có thể suy ra thật sự các đặc điểm nội tâm ổn định từ khuôn mặt”. Nghiên cứu về *physiognomic belief* còn cho thấy niềm tin rằng “mặt nói lên con người” liên hệ với quan điểm tất định sinh học và niềm tin vào một thế giới công bằng, tức là bản thân niềm tin này mang cấu trúc tư tưởng xã hội riêng chứ không phải chỉ là kết quả quan sát trung tính. citeturn8search4turn9search2

Trong AI, các nhà phê bình như Andrews và cộng sự, Scheuerman và cộng sự, Stark, cùng tài liệu của NLM đều cho rằng nhiều nhánh facial analysis hiện nay đã vô tình hồi sinh logic physiognomy: chuyển các phân loại xã hội gây tranh cãi thành bài toán nhận dạng mẫu, rồi xem đầu ra của mô hình như một thực tại tự nhiên. Cụm từ “auto-essentialization” được dùng để chỉ việc biến giới, chủng tộc hoặc thuộc tính xã hội phức tạp thành “bản chất được viết trên mặt”. citeturn9search1turn9search14turn9search22turn8search18turn9search27

### Bài học từ các nghiên cứu gây tranh cãi

Trường hợp điển hình nhất là bản thảo “Automated Inference on Criminality using Face Images”, trong đó tác giả báo cáo rằng họ dùng 1.856 người, gần một nửa là người bị kết án, và huấn luyện logistic regression, KNN, SVM, CNN để phân biệt “criminal” với “non-criminal” chỉ từ ảnh mặt. Bản addendum trên arXiv vẫn còn thể hiện rõ tuyên bố này. citeturn37search3

Nhưng các phê bình học thuật và kỹ thuật sau đó chỉ ra một loạt lỗ hổng: nhãn “phạm tội” là kết quả của hệ thống tư pháp và thực thi pháp luật, không phải thuộc tính sinh học của khuôn mặt; mô hình có thể học camera, hậu cảnh, nén ảnh, phong cách ảnh cơ sở dữ liệu, hoặc thiên lệch thể chế. Các bài phê bình pháp lý và đạo đức về “profiling potential” của computer vision xem đây là ví dụ điển hình cho việc trượt từ nhận dạng khuôn mặt sang dự đoán hành vi hay phẩm chất xã hội bằng proxy lỗi. citeturn37news31turn37search8turn9search1

Vì thế, trong khuôn khổ học thuật nghiêm ngặt, “nghiên cứu data nhân tướng học” chỉ còn có thể đứng vững nếu nó được diễn giải như một nghiên cứu về: lịch sử tư tưởng; ontology khuôn mặt; thiết kế nhãn; fairness; privacy; explainability; và giới hạn của mô hình. Việc dùng khuôn mặt để suy ra đạo đức, trí tuệ, tình trạng phạm tội, năng lực nghề nghiệp, hay vận mệnh không có nền tảng đủ mạnh để xem là bài toán ML hợp lệ. citeturn9search1turn8search18turn14search13turn10search3

Bản brief sản phẩm đã tải lên trong cuộc trò chuyện này cũng đi theo hướng an toàn hơn: chỉ dùng cho học thuật/tự quan sát, không đánh giá đạo đức, bệnh tật, tài vận hay danh tính; có thể xem trực tiếp tại `sandbox:/mnt/data/Văn bản đã dán (1)(18).txt`.

## Thu thập dữ liệu và thiết kế nhãn

### Dữ liệu khuôn mặt công khai nào thực sự phù hợp

Các bộ dữ liệu công khai phổ biến trong học máy khuôn mặt được xây để tối ưu các bài toán như face verification, face recognition, facial attributes, age estimation, fairness audit, hoặc landmark localization. Với một đề tài liên quan “nhân tướng học”, giá trị của chúng nằm ở chỗ cho phép nghiên cứu **cấu trúc khuôn mặt, chú giải bộ phận, độ ổn định của biểu diễn, thiên lệch dữ liệu, và luật riêng tư**, chứ không phải để huấn luyện bộ dự đoán “bản chất con người”. citeturn31view0turn32view0turn29view0turn34view0turn33view0turn35view0

Bảng dưới đây so sánh những bộ dữ liệu công khai đáng chú ý nhất cho mục tiêu nghiên cứu kỹ thuật và đạo đức về facial analysis.

| Bộ dữ liệu | Quy mô và nhãn | Bao phủ nhân khẩu | Giấy phép / truy cập | Đánh giá cho nghiên cứu này |
|---|---|---|---|---|
| **LFW** | 13.233 ảnh, 5.749 cá nhân; thiết kế cho pair matching/verification; ảnh 250×250; phát hiện mặt bằng Viola-Jones rồi lọc tay. citeturn31view0 | Đa dạng tự nhiên về pose, age, gender, race/ethnicity nhưng không được thiết kế cân bằng; RFW cho thấy nhiều benchmark cũ, gồm LFW, không cân bằng mạnh theo chủng tộc. citeturn31view0turn35view0 | Báo cáo kỹ thuật UMass; ảnh thu từ bộ “Faces in the Wild”, tức nguồn web/báo chí tiền kỳ GDPR. citeturn31view0 | Hợp cho benchmark kỹ thuật cơ bản; không phù hợp làm nền cho suy luận nhân tướng học chuẩn tắc. citeturn31view0turn9search1 |
| **CelebA** | 202.599 ảnh người nổi tiếng, 10.177 danh tính; 5 landmarks; 40 thuộc tính nhị phân. citeturn32view0 | Phong phú về pose/background nhưng thiên mạnh về miền celebrity; không công bố cân bằng sắc tộc rõ ràng và thường được xem là lệch phân phối. citeturn32view0turn28search15 | **Chỉ cho nghiên cứu phi thương mại**; ảnh “obtained from the Internet” và không thuộc sở hữu MMLAB; cấm sao chép/phân phối lại rộng rãi. citeturn32view0 | Tốt cho thuộc tính bề mặt và landmark; rủi ro pháp lý cao hơn nếu tái sử dụng ngoài nghiên cứu. citeturn32view0turn14search2 |
| **VGGFace2** | 3,31 triệu ảnh, 9.131 chủ thể; nhấn mạnh pose/age variation; có meta và 5 keypoints. citeturn11search7turn29view0 | Miền danh tính lớn, nhiều độ tuổi/nghề nghiệp/ethnicities, nhưng vẫn là dữ liệu web-scraped theo logic tìm kiếm ảnh. citeturn11search7turn29view0 | Ảnh được tải từ Google Image Search; trang Oxford cho biết link tải không còn được cung cấp từ website. citeturn29view0 | Rất hữu ích cho pretrain embeddings và kiểm tra độ bền theo tuổi/góc mặt; không nên xem là dữ liệu “có đồng ý trực tiếp”. citeturn11search7turn29view0turn14search2 |
| **FairFace** | 108.501 ảnh; 7 nhóm race; nhãn race, gender, age; thiết kế để đo và giảm bias. citeturn28search15turn33view0 | Đây là bộ công khai cân bằng hơn nhiều so với các bộ trước đó; có East Asian, Southeast Asian, Middle Eastern, Latino, v.v. citeturn28search15turn33view0 | Repository ghi **CC BY 4.0**; bài báo kết luận dữ liệu bắt nguồn từ YFCC100M với giấy phép Creative Commons. citeturn30view0turn33view0 | Là lựa chọn tốt nhất để audit fairness và huấn luyện baseline “ít lệch hơn”; vẫn cần cẩn trọng vì race là nhãn xã hội có yếu tố chủ quan. citeturn33view0 |
| **UTKFace** | 20.000+ ảnh; nhãn tuổi, giới, race nhúng trong tên file; có 68 landmarks. citeturn34view0 | Tuổi 0–116; race chia 5 nhóm khá thô; nhãn tuổi/giới/race được ước lượng bằng DEX rồi human double-check. citeturn34view0 | **Chỉ cho nghiên cứu phi thương mại**; ảnh thu từ Internet, bản quyền thuộc chủ sở hữu gốc. citeturn34view0 | Hữu ích cho nghiên cứu tuổi/landmarks/ontology vùng mặt; không nên dùng làm nguồn “sự thật nền” cho race hoặc thuộc tính xã hội sâu. citeturn34view0turn33view0 |
| **RFW** | Bộ benchmark công bằng theo chủng tộc; 4 subset Caucasian/Asian/Indian/African; mỗi subset khoảng 10K ảnh của 3K người; 6K cặp khó cho protocol giống LFW. citeturn35view0 | Thiết kế để đo racial bias công bằng hơn; Table 2 của bài báo cho thấy phân phối 25/25/25/25 ở test. citeturn35view0 | Dùng chủ yếu cho **đánh giá**, không phải nguồn training mặc định. citeturn35view0 | Rất nên dùng làm external benchmark fairness; không phải dữ liệu cho inference nhân tướng học. citeturn35view0turn17search1 |

### Bài toán thu thập dữ liệu không chỉ là “có ảnh”

Tổng quan *About Face* khảo sát hơn 100 bộ dữ liệu khuôn mặt được xây từ 1976 đến 2019, với khoảng 145 triệu ảnh và hơn 17 triệu chủ thể, và chỉ ra rằng cách dữ liệu được thu thập luôn phản ánh động cơ chính trị, năng lực công nghệ và chuẩn mực của từng thời kỳ. Nói cách khác, dataset không phải vật trung tính. Với khuôn mặt, nguồn ảnh, bối cảnh chụp, và logic lấy mẫu quan trọng không kém kiến trúc mô hình. citeturn14search2turn14search6

Vì thế, với đề tài này, chiến lược thu thập dữ liệu nên tuân theo thứ tự ưu tiên sau. Bậc ưu tiên cao nhất là dùng bộ dữ liệu có điều khoản rõ, có paper gốc, có mô tả nguồn và có giá trị trực tiếp cho bài toán kỹ thuật như landmarks, age bins, fairness audit. Bậc thấp hơn là bộ dữ liệu web-scraped nhưng thiếu điều khoản hoặc thiếu đường truy cập chính thức. Bậc cần tránh là tự scrape ảnh chân dung từ mạng xã hội, CCTV hay trải nghiệm người dùng để tạo tập dữ liệu “nhân tướng”. Điều này không chỉ rủi ro pháp lý mà còn đẩy nghiên cứu vào cùng logic mà AI Act của EU nhắm tới khi cấm cào vét ảnh mặt không định hướng để tạo hay mở rộng cơ sở dữ liệu. citeturn30view0turn32view0turn29view0turn0search7

Rủi ro stewardship cũng là vấn đề thực tế: MegaFace — một benchmark lớn từng rất quan trọng — hiện đã bị decommission và không còn phân phối dữ liệu; các tranh luận về đạo đức bộ dữ liệu khuôn mặt trong những năm gần đây cho thấy ngay cả benchmark nổi tiếng cũng có thể rơi vào tình trạng ngừng cấp phát hoặc phải đánh giá lại việc dùng tiếp dữ liệu đã bị rút xuống. citeturn13search2turn13search11turn14search13

### Thiết kế nhãn cho một dự án “nhân tướng học”

Điểm quyết định thành bại của nghiên cứu này không phải là backbone, mà là **ngữ nghĩa của nhãn**. Một schema nhãn khả dĩ nên chia ít nhất thành ba lớp.

Lớp thứ nhất là **nhãn quan sát được**: landmark points, tỷ lệ hình học giữa vùng mặt, pose, độ che khuất, chất lượng ảnh, tuổi/gender bins nếu có cơ sở pháp lý, vùng mặt như trán–ấn đường–mắt–mũi–miệng–cằm–tai, hoặc ontology kiểu Tam đình/Ngũ quan dưới dạng chia vùng và thuật ngữ học thuật. Các nhãn này có thể anotate và kiểm thử được bằng nhiều annotator. citeturn15search2turn31view0turn32view0turn34view0

Lớp thứ hai là **nhãn proxy xã hội**: race, ethnicity, attractiveness, “looks trustworthy”, hoặc các nhãn tự khai về tính cách. Những nhãn này vẫn có thể dùng trong nghiên cứu, nhưng phải kèm protocol nghiêm ngặt về cách anotate, agreement, độ bất định, và cảnh báo rằng đây là nhãn xã hội hoặc nhãn nhận thức, không phải “sự thật sinh học”. FairFace chính bài báo cũng giải thích rằng race là khái niệm đa chiều, skin color không đủ thay thế race, và nhãn race do con người gán luôn có tính chủ quan. citeturn33view0

Lớp thứ ba là **nhãn chuẩn tắc hoặc tiên đoán bản chất**: đạo đức, trí tuệ, xu hướng phạm tội, khả năng thành công, “giàu nghèo”, “bạc tình”, “yểu mệnh”, hay bất kỳ phát biểu nào gắn số phận chắc chắn với khuôn mặt. Nhãn loại này nên bị xem là *restricted* hoặc *rejected* ngay từ design review, vì chúng không tách được thiên lệch xã hội ra khỏi tín hiệu hình ảnh, đồng thời tái tạo đúng logic bị phê bình trong physiognomic AI. citeturn9search1turn8search18turn37search3turn37news31

Với nhu cầu Việt hóa tri thức kiểu Tam đình, Ngũ quan, Thập nhị cung, cách đúng về mặt ML là biến chúng thành **ontology chú giải vùng mặt** và **thẻ từ điển thuật ngữ**, chứ không biến chúng thành nhãn mục tiêu để suy ra “vận mệnh”. Đây cũng là hướng khớp hơn với brief sản phẩm hiện có trong cuộc trò chuyện này.

## Đặc trưng khuôn mặt và họ mô hình

### Từ hình học đến biểu diễn sâu

Con đường kỹ thuật cổ điển nhất là landmark-based geometry. Bài báo của Kazemi và Sullivan cho thấy có thể định vị landmark khuôn mặt rất nhanh bằng ensemble of regression trees, và các bộ dữ liệu như CelebA, VGGFace2, UTKFace đều cung cấp sẵn hoặc hỗ trợ 5–68 keypoints. Ưu điểm lớn nhất của nhánh này là tính giải thích: ta biết mô hình dùng khoảng cách mắt, chiều cao mũi, góc miệng hay tỷ lệ của các vùng nào. Nhược điểm là nó bỏ lỡ texture, tín hiệu ảnh tinh vi, và dễ suy giảm khi occlusion hoặc head rotation mạnh. citeturn15search2turn32view0turn29view0turn34view0turn18search23turn18search27

Nhánh thứ hai là face embeddings. FaceNet học một không gian nhúng Euclidean sao cho khoảng cách phản ánh mức giống nhau giữa khuôn mặt; ArcFace sau đó tăng tính phân biệt bằng additive angular margin loss. Đây là các lựa chọn rất mạnh nếu mục tiêu là biểu diễn khuôn mặt chung rồi gắn đầu ra nhiệm vụ khác ở phía sau. Nhưng khi tái sử dụng embeddings cho “nhân tướng học”, cần nhớ rằng embedding nhận dạng khuôn mặt có thể giữ lại nhiều thông tin ngoài danh tính, như tuổi, giới, chất lượng ảnh, race proxy hoặc yếu tố phi-danh tính khác. Điều này làm downstream task rất dễ học các proxy nhạy cảm. citeturn15search0turn15search9turn17search20

Nhánh thứ ba là end-to-end CNN hoặc Vision Transformer. VGGFace2 và nhiều benchmark khác cho thấy ResNet-family vẫn là chuẩn mạnh cho facial tasks; gần đây, các biến thể transformer như fViT hay TransFace cho thấy khả năng cạnh tranh cao trong face recognition. Vấn đề là khi sang bài toán nhãn xã hội mềm hoặc nhãn gây tranh cãi, mô hình càng mạnh càng có nguy cơ khai thác các shortcut trong dữ liệu thay vì học “cấu trúc sinh học” như người dùng thường kỳ vọng. citeturn11search7turn16search7turn16search31turn17search12

### Khả năng giải thích không phải lá bùa miễn trách nhiệm

Grad-CAM, Integrated Gradients và SHAP là ba hướng XAI quan trọng để kiểm tra mô hình đang chú ý vùng nào của ảnh và đặc trưng nào đóng góp nhiều cho dự đoán. Chúng rất hữu ích trong nghiên cứu facial analysis, nhất là để xem mô hình có thực sự nhìn vào vùng mặt hay đang dựa vào hậu cảnh, chất lượng ảnh, watermark, hoặc kiểu crop. citeturn15search3turn16search0turn16search14

Tuy nhiên, saliency map đẹp không có nghĩa là giải thích đáng tin. Công trình *Sanity Checks for Saliency Maps* cho thấy việc chỉ đánh giá bằng trực quan có thể đánh lừa nhà nghiên cứu; một số phương pháp “giải thích” gần như không phụ thuộc vào mô hình hoặc dữ liệu học được. Vì vậy, bất kỳ phần XAI nào trong lĩnh vực này cũng nên đi kèm kiểm thử sanity checks, ablation, và đối chiếu với baseline hình học/landmark. citeturn16search1turn16search5

### Bảng so sánh các họ mô hình

| Họ phương pháp | Ví dụ đại diện | Dữ liệu đầu vào | Điểm mạnh | Hạn chế/rủi ro | Vai trò khuyến nghị |
|---|---|---|---|---|---|
| **Landmark + đặc trưng hình học** | Kazemi & Sullivan 2014; logistic regression / SVM phía sau. citeturn15search2 | 5–68 điểm mốc, tỷ lệ vùng mặt | Dễ giải thích; phù hợp ontology vùng mặt như Tam đình/Ngũ quan; chi phí tính toán thấp | Nhạy với occlusion, pose cực đoan; bỏ lỡ texture | **Baseline bắt buộc** cho mọi nghiên cứu nghiêm ngặt |
| **Embeddings tiền huấn luyện** | FaceNet, ArcFace. citeturn15search0turn15search9 | Ảnh mặt đã align | Hiệu quả cao; thuận tiện transfer learning; dễ so sánh nhiều nhãn | Dễ mang theo proxy nhạy cảm và thông tin phi-danh tính; cần kiểm tra leakage. citeturn17search20 | Phù hợp nhất cho nghiên cứu biểu diễn và audit fairness |
| **CNN end-to-end** | ResNet/VGGFace2-style training. citeturn11search7 | Ảnh mặt thô hoặc đã căn chỉnh | Mạnh trên ảnh thực; học được texture và tương tác phi tuyến | Dễ học shortcut; khó diễn giải hơn; cần nhiều dữ liệu sạch | Chỉ nên dùng sau khi baseline landmark và embedding đã hoàn tất |
| **Vision Transformer** | fViT, TransFace. citeturn16search7turn16search31 | Patchified face image | Có tiềm năng tốt ở quy mô dữ liệu lớn; linh hoạt | Đòi hỏi dữ liệu và tài nguyên cao; không giải quyết vấn đề hợp lệ của nhãn | Không nên là điểm khởi đầu nếu mục tiêu chưa rõ |
| **XAI phụ trợ** | Grad-CAM, Integrated Gradients, SHAP. citeturn15search3turn16search0turn16search14 | Mô hình đã huấn luyện | Giúp phát hiện shortcut, bias, vùng chú ý | Có thể gây ảo tưởng minh bạch nếu không có sanity checks. citeturn16search1turn16search5 | Nên là lớp kiểm tra, không phải bằng chứng hợp lệ của bài toán |

Một kết luận quan trọng là: với chủ đề nhạy cảm như “nhân tướng học”, **mô hình càng dễ giải thích càng có giá trị học thuật ban đầu**. Baseline landmark + mô hình tuyến tính thường nên được ưu tiên hơn end-to-end ViT nếu mục tiêu là hiểu cấu trúc nhãn, chứ không phải đua benchmark. citeturn15search2turn16search1turn17search12

## Huấn luyện, đánh giá và độ tin cậy

### Chia tập, cross-validation và kiểm soát rò rỉ

Trong facial ML, rò rỉ danh tính là sai lầm rất dễ mắc. Nghiên cứu gần đây về identity overlap chỉ ra rằng việc đảm bảo train/test identity-disjoint không hề đơn giản khi các bộ dữ liệu được lắp ghép độc lập; nếu cùng một người xuất hiện ở cả train và test, ước lượng hiệu năng sẽ bị lạc quan quá mức. Vì thế, cross-validation bắt buộc phải grouping theo identity, không grouping theo ảnh. citeturn17search3

Ngoài rò rỉ danh tính, còn có rò rỉ qua pipeline: chuẩn hóa dùng toàn tập, augment không tách theo fold, dedup làm sai thời điểm, hoặc chọn siêu tham số trên test ngoài. Tổng quan về data leakage cho thấy đây là một trong các nguồn chính tạo ra khủng hoảng tái lập trong ML. Với đề tài “nhân tướng học”, nơi nhãn vốn đã mong manh, bất kỳ rò rỉ nào cũng làm kết quả gần như vô nghĩa. citeturn17search12

Một protocol tối thiểu hợp lệ vì vậy nên gồm ba lớp đánh giá. Thứ nhất là grouped 5-fold CV theo identity trên tập phát triển. Thứ hai là external test set độc lập về danh tính và nguồn dữ liệu, ví dụ train trên FairFace/UTKFace rồi test trên RFW hoặc một bộ fairness benchmark khác tùy nhiệm vụ. Thứ ba là kiểm tra overlap liên-dataset bằng face embeddings và so khớp tên danh tính trước khi công bố kết quả. citeturn17search3turn35view0

### Metrics nào mới đáng báo cáo

Nếu vẫn thực hiện nghiên cứu facial-feature ML ở phạm vi thấp rủi ro, chỉ báo cáo accuracy là không đủ. Tối thiểu nên có balanced accuracy hoặc macro-F1 để tránh tập lệch nhãn; AUROC/AUPRC khi bài toán là phân loại nhị phân hoặc đa nhãn; và calibration như Brier score hoặc ECE nếu đầu ra được dùng như xác suất. Với fairness, cần báo cáo per-group TPR/FPR, worst-group accuracy/TPR, khoảng cách giữa nhóm tốt nhất và tệ nhất, và kiểm tra intersectional nếu có race × gender × age. Các nghiên cứu fairness gần đây nhấn mạnh rằng accuracy có thể chỉ giảm ít, trong khi TPR hoặc disparate mistreatment chênh mạnh giữa nhóm. citeturn17search1turn17search5

NIST duy trì hẳn một nhánh báo cáo demographic effects cho face recognition, còn RFW và các nghiên cứu tiếp theo cho thấy hiệu năng trên các nhóm dân số khác nhau có thể khác biệt rõ rệt. Đây là lý do fairness testing phải đi từ “đo chênh lệch” chứ không chỉ “báo số trung bình”. citeturn17search0turn17search4turn17search21turn35view0

### Độ bền và kiểm thử ngoài phân phối

Hệ thống facial analysis cần được kiểm tra ở các điều kiện phá vỡ giả định: mask, kính, tóc che mặt, blur, nén JPEG, crop xấu, ánh sáng mạnh/yếu, yaw/pitch/roll cực đoan, và biến thể ngoài phân phối. NIST FRVT Part 6B cho thấy việc đeo khẩu trang làm suy giảm đáng kể độ chính xác của face recognition; OODFace gần đây còn xây các benchmark riêng với hàng chục kịch bản OOD cho nhận dạng khuôn mặt. citeturn18search0turn18search6turn18search13turn18search15

Đối với nghiên cứu kiểu ontology vùng mặt, landmark detector cũng phải được đánh giá riêng vì sai số ở bước định vị vùng mặt sẽ lan truyền sang toàn bộ downstream analysis. Các công trình landmark under occlusion và occlusion-robust landmark detection nhấn mạnh đây là một failure mode có tính hệ thống. citeturn18search23turn18search27

### Ma trận đánh giá khuyến nghị

| Lớp đánh giá | Báo cáo tối thiểu | Lý do |
|---|---|---|
| Hiệu năng tổng thể | Macro-F1, balanced accuracy, AUROC/AUPRC nếu phù hợp | Tránh ảo giác hiệu năng do lệch lớp |
| Identity safety | Identity-disjoint split; kiểm tra overlap liên-dataset | Tránh optimistic bias do trùng người. citeturn17search3 |
| Fairness | Per-group TPR/FPR; worst-group; gap giữa nhóm; giao cắt nhóm | Accuracy trung bình che khuất sai lệch. citeturn17search1turn17search5 |
| Calibration | Brier/ECE; reliability curve | Cần nếu dùng xác suất đầu ra cho quyết định hay giao diện |
| Robustness | Mask, occlusion, blur, JPEG, low-light, OOD | Facial models rất nhạy với biến dạng chụp. citeturn18search0turn18search15 |
| Explainability | Grad-CAM/IG/SHAP + sanity checks | Tránh ngộ nhận từ heatmap bắt mắt. citeturn15search3turn16search0turn16search1 |
| Tái lập | Seed, version dataset, config, datasheet/model card | Giảm khủng hoảng tái lập và data leakage. citeturn17search12turn14search2 |

## Quyền riêng tư, đạo đức và pháp lý

### GDPR, EDPB và AI Act

Theo định nghĩa phổ biến của GDPR, “biometric data” là dữ liệu cá nhân phát sinh từ xử lý kỹ thuật đặc thù liên quan đến đặc điểm vật lý, sinh lý hoặc hành vi và cho phép hoặc xác nhận nhận dạng duy nhất của một người; ví dụ bao gồm facial images khi được xử lý theo cách đó. Một nuance rất quan trọng là video hay ảnh thô không phải lúc nào cũng là “special category biometric data” dưới Điều 9 nếu chưa qua xử lý kỹ thuật nhằm nhận dạng, nhưng chúng vẫn là dữ liệu cá nhân và vẫn chịu ràng buộc của GDPR. citeturn19search2turn19search8

EDPB đã ban hành hướng dẫn về facial recognition trong lĩnh vực thực thi pháp luật và nhấn mạnh rủi ro cao đối với quyền và tự do của chủ thể dữ liệu; EDPS và EDPB cũng từng công khai kêu gọi cấm sử dụng AI để tự động nhận diện các đặc điểm con người trong không gian công cộng dễ dẫn đến giám sát sinh trắc hàng loạt và phân biệt không công bằng. citeturn19search1turn19search4turn19search3turn19search10

Về khung AI, tóm tắt chính thức của EU cho AI Act nêu rõ một số thực hành bị cấm, gồm cào vét ảnh mặt không định hướng từ Internet hoặc CCTV để tạo/mở rộng cơ sở dữ liệu nhận dạng khuôn mặt, dùng dữ liệu sinh trắc để suy ra đặc tính được bảo vệ, social scoring, và một số hình thức đánh giá nguy cơ phạm tội. Điều này có ý nghĩa trực tiếp với mọi đề tài “nhân tướng học bằng ML”: nếu bài toán tiến gần tới phân loại con người theo đặc tính nhạy cảm hoặc dự đoán tư cách xã hội từ mặt, rủi ro pháp lý ở châu Âu tăng rất mạnh. citeturn0search7

### Khung pháp lý Việt Nam

Ở Việt Nam, cột mốc mới nhất là Luật Bảo vệ dữ liệu cá nhân số 91/2025/QH15, ban hành ngày 26/06/2025 và có hiệu lực từ 01/01/2026. Chính phủ sau đó ban hành Nghị định 356/2025/NĐ-CP ngày 31/12/2025 để quy định chi tiết và thi hành luật này. citeturn5view3turn6view0

Nguồn chính thức của Chính phủ về Luật Bảo vệ dữ liệu cá nhân nêu riêng Điều 31 về dữ liệu vị trí và dữ liệu sinh trắc học, trong đó dữ liệu sinh trắc học được hiểu là dữ liệu về thuộc tính vật lý, đặc điểm sinh học cá biệt và ổn định để xác định một người. Cùng nguồn này cũng nêu yêu cầu cụ thể: cơ quan/tổ chức/cá nhân thu thập và xử lý dữ liệu sinh trắc học phải có biện pháp bảo mật vật lý cho thiết bị lưu trữ và truyền tải, hạn chế quyền truy cập, có hệ thống theo dõi để phòng ngừa/phát hiện xâm phạm, và nếu xử lý gây thiệt hại thì phải thông báo cho chủ thể dữ liệu theo quy định. citeturn24search1turn25search8

Nghị định 356/2025 còn cho thấy dữ liệu sinh trắc học được xem là dữ liệu cá nhân nhạy cảm và bên xử lý dữ liệu nhạy cảm phải thiết lập quy định phân quyền giới hạn truy cập, quy trình xử lý và biện pháp bảo mật. Screenshot của văn bản triển khai cũng thể hiện các mốc phản hồi ngắn đối với yêu cầu của chủ thể dữ liệu như rút lại đồng ý, hạn chế xử lý, xem/chỉnh sửa/xóa dữ liệu. citeturn6view1turn6view2

Trước khi Luật 91/2025 có hiệu lực, Nghị định 13/2023/NĐ-CP là nền tảng chính của Việt Nam về bảo vệ dữ liệu cá nhân. Nguồn chính thức của Chính phủ về toàn văn Nghị định 13 ghi rõ rằng sự đồng ý phải được thể hiện rõ ràng, cụ thể bằng văn bản, giọng nói, tick ô đồng ý, cú pháp tin nhắn hoặc thiết lập kỹ thuật; sự im lặng hoặc không phản hồi **không** được coi là đồng ý; và với dữ liệu cá nhân nhạy cảm, chủ thể phải được thông báo rằng dữ liệu đang xử lý là dữ liệu nhạy cảm. Đây là nền tảng đặc biệt quan trọng với mọi dự án xử lý ảnh mặt. citeturn27search0turn24search11

Một điểm nữa rất đáng chú ý là pháp luật Việt Nam cũng quy định dữ liệu cá nhân thu được từ ghi âm, ghi hình nơi công cộng chỉ được lưu trữ trong thời gian cần thiết cho mục đích thu thập; hết thời hạn phải xóa hoặc hủy. Điều này khiến chiến lược “cứ thu CCTV/public photos để nghiên cứu sau” không còn là lựa chọn an toàn mặc định. citeturn24search7turn27search8

### Bảng rủi ro đạo đức và biện pháp giảm thiểu

| Rủi ro | Cách nó xuất hiện trong nghiên cứu khuôn mặt | Vì sao nghiêm trọng | Giảm thiểu đề xuất | Trạng thái khuyến nghị |
|---|---|---|---|---|
| **Cào vét ảnh không có đồng ý** | Tự scrape web, social, CCTV, ảnh công cộng | Vi phạm riêng tư, mục đích sử dụng, stewardship; AI Act EU còn cấm một số trường hợp. citeturn0search7turn27search0 | Chỉ dùng dataset có điều khoản rõ; log legal basis; cơ chế xóa/opt-out | **Không khuyến nghị** |
| **Nhãn chuẩn tắc/pseudoscience** | “Đạo đức”, “tội phạm”, “thông minh”, “số mệnh” | Không có construct validity; dễ tái tạo phân biệt đối xử. citeturn9search1turn37search3turn37news31 | Loại khỏi schema; chuyển thành ontology thuật ngữ hoặc self-observation | **Restricted/Rejected** |
| **Thiên lệch dân số** | Dữ liệu lệch White/celebrity/ảnh đẹp/studio | Gây chênh hiệu năng, sai lầm bất công giữa nhóm. citeturn28search15turn17search0turn17search1 | Ưu tiên FairFace/RFW; worst-group evaluation; intersectional analysis | **Phải kiểm thử** |
| **Rò rỉ danh tính** | Cùng người xuất hiện ở train/test hoặc giữa các benchmark | Làm tăng khống hiệu năng; phá hỏng kết luận khoa học. citeturn17search3turn17search12 | Group split theo identity; overlap scan trước công bố | **Phải chặn** |
| **Embedding leakage / tái nhận diện** | Chia sẻ face embeddings như dữ liệu “vô danh” | Embeddings có thể vẫn chứa tín hiệu nhận dạng và thông tin nhạy cảm. citeturn17search20 | Không công khai embedding thô; access control; privacy review | **Rủi ro cao** |
| **Lạm dụng trong tuyển dụng/tín dụng/pháp lý** | Dùng đầu ra facial model cho quyết định bất lợi | Xâm hại quyền, tạo phân biệt đối xử quy mô lớn. citeturn19search3turn14search13 | Cấm use-case ngay từ policy; model card nêu rõ “not for adverse decisions” | **Cấm triển khai** |
| **Giải thích giả** | Heatmap đẹp nhưng không phản ánh mô hình thật | Tạo cảm giác “mô hình minh bạch” giả. citeturn16search1 | Sanity checks, ablation, baseline landmark | **Phải kiểm tra** |
| **Synthetic data leakage** | Dùng mặt tổng hợp thay dữ liệu thật nhưng rò rỉ danh tính gốc | Tưởng là an toàn nhưng vẫn mang dấu vết nhận dạng. citeturn14search4turn17search16turn17search28 | Test similarity leakage; ưu tiên synthetic có audit | **Khả thi nhưng phải audit** |

Nếu nối báo cáo này với brief sản phẩm đã tải lên, hướng phù hợp nhất về đạo đức là xem ứng dụng như **từ điển thuật ngữ / ontology vùng mặt / công cụ tự ghi chú**, không phải “máy phán tướng”. Về mặt quản trị rủi ro, điều này là đúng cả về học thuật lẫn pháp lý.

## Pipeline tái lập và kế hoạch thực nghiệm khuyến nghị

### Flow nghiên cứu đề xuất

Vì ứng dụng đích, KPI, ngân sách và timeline chưa được đặc tả, pipeline dưới đây được thiết kế như một **research-only workflow** cho hai mục tiêu an toàn:  
một là số hóa ontology khuôn mặt kiểu Tam đình/Ngũ quan như hệ thống chú giải;  
hai là đánh giá fairness, robustness và explainability của facial representations trên dữ liệu công khai hợp lệ. Cách làm này bám chặt các bài học từ survey dataset, fairness benchmarks, landmark/embedding papers và khung pháp lý hiện hành. citeturn14search2turn15search2turn15search0turn15search9turn17search1turn17search3turn25search8

```mermaid
flowchart TD
    A[Xác định bài toán] --> B{Nhãn có quan sát được,\ncó cơ sở pháp lý và có thể kiểm chứng?}
    B -- Không --> Z[Loại bỏ hoặc chuyển sang ontology thuật ngữ]
    B -- Có --> C[Lập datasheet + legal basis + risk register]
    C --> D[Thu thập dữ liệu hợp lệ\nFairFace / UTKFace / CelebA / LFW / RFW]
    D --> E[Tiền xử lý\nface detect, align, quality control, dedup]
    E --> F[Chia tập theo identity\nGroupKFold và external holdout]
    F --> G[Baseline hình học\nlandmarks + linear model]
    G --> H[Baseline embedding\nFaceNet / ArcFace frozen head]
    H --> I[Mô hình mạnh hơn\nCNN hoặc ViT nếu thật sự cần]
    I --> J[Đánh giá tổng thể + fairness + calibration]
    J --> K[Đánh giá robustness\nmask/blur/occlusion/OOD]
    K --> L[XAI + sanity checks]
    L --> M{Rủi ro còn chấp nhận được?}
    M -- Không --> N[Giảm phạm vi hoặc dừng nghiên cứu]
    M -- Có --> O[Báo cáo + datasheet + model card + giới hạn sử dụng]
```

### Cấu hình tái lập được đề nghị

Bắt đầu bằng một **baseline hình học**. Ảnh được chuẩn hóa bằng face detection và alignment; trích 5 hoặc 68 landmarks; chuẩn hóa landmark theo inter-ocular distance; tạo vector tỷ lệ vùng mặt, góc, khoảng cách và chỉ số đối xứng. Phần học máy có thể là logistic regression hoặc linear SVM với regularization grid `C ∈ {0.01, 0.1, 1, 10}`. Đánh giá bằng `GroupKFold(n=5)` theo identity, macro-F1, balanced accuracy, và chênh lệch worst-group. Baseline này là bắt buộc trước khi dùng embeddings hoặc CNN, vì nó cho thấy mô hình tuyến tính có khai thác được gì từ hình học thuần hay không. citeturn15search2turn17search3turn17search1

Tiếp theo là **baseline embedding đóng băng**. Dùng backbone FaceNet hoặc ArcFace đã pretrain; input 112×112 hoặc 160×160 tùy implementation; đóng băng backbone trong vòng thí nghiệm đầu để tránh mô hình hút mọi proxy trong ảnh. Chỉ huấn luyện head nhỏ, ví dụ MLP hai lớp `512 → 128 → output`, `dropout=0.2`, `AdamW lr ∈ {1e-4, 3e-4, 1e-3}`, `batch ∈ {128, 256}`, `max_epoch=30`, `early_stopping_patience=5`. Mục tiêu ở đây không phải “đạt SOTA”, mà là đo xem embedding mang theo những tín hiệu nào và chúng đổi khác ra sao giữa các nhóm dân số. citeturn15search0turn15search9turn17search20turn17search1

Chỉ khi hai baseline trên đã ổn và nhãn đủ vững mới nên sang **fine-tune CNN**. Đề xuất ban đầu là ResNet-50 với `input=224×224`, mixed precision, `SGD momentum=0.9` hoặc `AdamW`, `lr_head≈1e-3`, `lr_backbone≈1e-4`, `weight_decay=1e-4`, `batch≈128`, `epoch=30–90`, augment nhẹ như horizontal flip, light color jitter, random crop nhỏ; tránh augment quá mạnh làm méo hình học nếu bài toán thiên về morphology. citeturn11search7turn18search15

Vision Transformer chỉ nên là **pha sau**. Các công trình fViT và TransFace cho thấy transformer có thể rất mạnh cho face recognition, nhưng đây là lựa chọn tốn dữ liệu và compute, đồng thời không giải quyết bài toán hợp lệ của nhãn. Nếu nhãn vẫn là socially loaded hoặc proxy mềm, chuyển từ ResNet sang ViT thường làm tăng rủi ro học shortcut nhiều hơn là tăng giá trị khoa học. citeturn16search7turn16search31

### Kế hoạch thực nghiệm và tài nguyên ước tính

| Pha | Mục tiêu | Dữ liệu ưu tiên | Cấu hình đề xuất | Chỉ số bắt buộc | Tài nguyên ước tính |
|---|---|---|---|---|---|
| **Pha audit dữ liệu** | Dedupe, quality control, legal review, label map | FairFace, UTKFace, CelebA metadata, LFW, RFW. citeturn30view0turn34view0turn32view0turn31view0turn35view0 | CPU-heavy; face detect/alignment batch; identity overlap scan | Số lượng sau lọc, tỉ lệ ảnh lỗi, subgroup coverage | 1 máy CPU 16 core + 1 GPU 12–24GB; 1–3 ngày |
| **Pha baseline hình học** | Đo tín hiệu từ landmarks/ratios | UTKFace, CelebA, ảnh đã align | 68 landmarks; logistic/SVM; 5-fold grouped CV | Macro-F1, balanced acc, worst-group gap | 1 GPU nhỏ hoặc CPU; <1 ngày |
| **Pha embedding frozen** | Audit thông tin trong biểu diễn | FairFace + external RFW | ArcFace/FaceNet frozen; MLP head; epoch tối đa 30 | AUROC/F1 + subgroup TPR/FPR + calibration | 1 GPU 24GB; 1–3 ngày |
| **Pha fine-tune CNN** | Kiểm tra giá trị thêm của end-to-end learning | FairFace hoặc tập hợp có legal basis rõ | ResNet-50; batch ~128; 30–90 epoch; early stop | Toàn bộ metric fairness + robustness + XAI sanity | 2 GPU 24GB; 3–7 ngày |
| **Pha robustness/OOD** | Đo độ bền khi che khuất / dịch miền | RFW + benchmark OOD + synthetic corruptions | Test-only hoặc fine-tune nhẹ domain adaptation | Mask/blur/JPEG/occlusion/OOD degradation | 1–2 GPU 24GB; 1–2 ngày |
| **Pha ViT tùy chọn** | Nghiên cứu nâng cao, không phải MVP | VGGFace2-scale hoặc pretrain thích hợp | ViT/TransFace; compute lớn | Chỉ triển khai nếu nhãn hợp lệ và baseline đã rõ | 4–8 GPU 40–80GB; 1–3 tuần |

Các con số tài nguyên trên là **ước tính vận hành** dựa trên quy mô dữ liệu và họ mô hình trong các paper/dataset gốc, không phải báo giá.

### Lộ trình mẫu

Vì timeline thực tế chưa được đặc tả, biểu đồ dưới đây chỉ là **lịch nghiên cứu mẫu** trong khoảng 12 tuần để đi từ audit dữ liệu đến báo cáo học thuật.

```mermaid
gantt
    title Lộ trình nghiên cứu mẫu cho facial-feature study
    dateFormat  YYYY-MM-DD
    section Khởi động
    Đặc tả bài toán và legal review        :a1, 2026-05-19, 10d
    Datasheet và risk register             :a2, after a1, 7d
    section Dữ liệu
    Thu thập hợp lệ và quality control     :b1, after a2, 14d
    Dedupe và identity overlap scan        :b2, after b1, 7d
    section Mô hình
    Baseline landmark                      :c1, after b2, 7d
    Baseline embedding                     :c2, after c1, 10d
    CNN fine-tuning có kiểm soát           :c3, after c2, 14d
    section Đánh giá
    Fairness + robustness + XAI            :d1, after c3, 14d
    section Tổng hợp
    Viết model card và báo cáo             :e1, after d1, 10d
```

### Khuyến nghị thực chất cho hướng nghiên cứu tiếp theo

Khuyến nghị đầu tiên là **đổi mục tiêu nghiên cứu** từ “dự đoán con người từ mặt” sang “đo, mô tả, và kiểm tra các biểu diễn khuôn mặt dưới ràng buộc fairness–privacy–explainability”. Trong khuôn khổ đó, ontology kiểu Tam đình, Ngũ quan, bộ vị khuôn mặt có thể được số hóa như từ điển và schema annotation vùng mặt, hoàn toàn hữu ích cho sản phẩm giáo dục hoặc self-observation mà không phải hứa hẹn tiên đoán số phận. citeturn15search2turn14search2turn9search1

Khuyến nghị thứ hai là **loại bỏ toàn bộ nhãn deterministic/normative** khỏi pipeline sản xuất: phạm tội, đạo đức, trí tuệ, tài vận, “bạc tình”, “yểu mệnh”, “giàu nghèo chắc chắn”, đánh giá tuyển dụng hay tín dụng. Đây không chỉ là vấn đề đạo đức mà còn là vấn đề hợp lệ khoa học và pháp lý. citeturn37search3turn37news31turn19search3turn0search7

Khuyến nghị thứ ba là **ưu tiên data governance hơn model size**. Một datasheet tốt, consent rõ ràng, subgroup coverage được ghi chép, protocol identity-disjoint, và model card minh bạch sẽ có giá trị khoa học hơn một backbone lớn nhưng được huấn luyện trên nhãn yếu và dữ liệu mù mờ. citeturn14search2turn14search1turn17search3turn17search12

Khuyến nghị thứ tư là nghiên cứu **synthetic face data** như một hướng giảm phụ thuộc vào ảnh thật, nhưng chỉ dùng sau khi kiểm tra identity leakage. Có bằng chứng rằng dữ liệu tổng hợp có thể hỗ trợ fairness-aware face recognition, song cũng có nghiên cứu cảnh báo rò rỉ danh tính từ dữ liệu tổng hợp. citeturn14search4turn17search16turn17search28

Khuyến nghị cuối cùng là: nếu mục tiêu sản phẩm là một công cụ học thuật bằng tiếng Việt, hướng phù hợp nhất là xây một lớp dữ liệu gồm glossary, ontology vùng mặt, self-observation checklist, và cảnh báo an toàn; còn nếu mục tiêu là hệ thống ML ra quyết định về con người từ khuôn mặt, thì bằng chứng hiện có không ủng hộ việc triển khai đó trong môi trường thực tế. citeturn10search3turn9search1turn25search8turn27search0