TÓM TẮT CHUYỂN CHAT: APP TƯỚNG / XEM TƯỚNG THAM KHẢO

## 1. Bối cảnh hệ app hiện tại

Dự án đang dùng repo chung:

```text
app-hon-tho
```

Domain app:

```text
https://app.hontho.com
```

Đây là khu ứng dụng **Cổ học**, không còn định vị là “Hồn Thơ App” ở UI chính nữa.

Các trang đã live:

```text
/
→ Khu ứng dụng Cổ học

/nguthuat
→ Trang Ngũ thuật

/tam-thuc
→ Trang Tam thức

/nguthuat/menh/tutru
→ Đã gắn app Tứ Trụ thật
```

Trong Ngũ thuật có 5 nhánh:

```text
Sơn  → /nguthuat/son/phongthu
Y    → /nguthuat/y/yhoc
Mệnh → /nguthuat/menh/tutru
Bốc  → /nguthuat/boc/maihoa
Tướng → /nguthuat/tuong/xem-tuong
```

Hiện route Tướng đang là placeholder. Việc tiếp theo là nghiên cứu và thiết kế nội dung cho app:

```text
/nguthuat/tuong/xem-tuong
```

---

## 2. Định vị app Tướng

Tên app nên dùng:

```text
Tướng - Xem tướng tham khảo
```

Hoặc:

```text
Nhân tướng học tham khảo
```

Không dùng cách gọi quá mạnh như:

```text
Đoán vận mệnh
Phán số mệnh
Nhìn mặt biết người
Xem tướng chính xác tuyệt đối
```

Định vị đúng:

```text
Ứng dụng tham khảo cổ học về Nhân tướng học, giúp người dùng tự quan sát các đặc điểm hình tướng theo hệ thống cổ học, diễn giải thận trọng, không kết luận tuyệt đối.
```

Tinh thần nội dung:

```text
tham khảo
tự quan sát
học hiểu
đối chiếu cổ học
không phán xét
không hù dọa
không kết luận đạo đức, trí tuệ, sức khỏe, số phận tuyệt đối
```

---

## 3. Nguyên tắc an toàn nội dung

App Tướng phải cực kỳ cẩn thận vì liên quan gương mặt/con người.

Không được để app nói kiểu:

```text
Người này xấu
Người này gian
Người này ác
Người này đoản thọ
Người này nghèo
Người này phản bội
Người này bệnh nặng
Người này chắc chắn thành công/thất bại
```

Thay bằng cách nói mềm:

```text
Theo cách phân loại cổ học, đặc điểm này thường được xếp vào nhóm...
Dữ liệu quan sát chưa đủ để kết luận.
Nên xem đây là gợi ý tự soi chiếu, không phải kết luận về con người.
Cần kết hợp bối cảnh sống, hành vi, giáo dục, sức khỏe, môi trường và lựa chọn cá nhân.
```

Không dùng app cho:

```text
tuyển dụng
đánh giá đạo đức người khác
kết luận bệnh lý
kết luận tâm lý
kết luận tội phạm
hẹn hò/quyết định cưới hỏi một cách máy móc
đánh giá giá trị con người
```

---

## 4. Phạm vi app Tướng giai đoạn 1

Giai đoạn 1 nên làm **Nhân tướng diện bộ**, tức quan sát khuôn mặt theo hệ thống cổ học.

Chưa cần nhận diện ảnh bằng AI.

Nên dùng cách:

```text
Người dùng tự chọn đặc điểm quan sát qua form/card.
App tổng hợp diễn giải theo rule/data.
```

Không nên làm ngay:

```text
Upload ảnh rồi AI tự phán mặt
```

Nếu sau này có upload ảnh, chỉ nên dùng để:

```text
hiển thị ảnh tham chiếu
vẽ khung gợi ý vùng quan sát
người dùng tự xác nhận đặc điểm
```

Không để hệ thống tự động kết luận từ ảnh.

---

## 5. Module nội dung nên có

### A. Tổng quan Nhân tướng học

Giải thích:

```text
Nhân tướng học là một nhánh tham khảo trong cổ học, quan sát hình, thần, khí, sắc, âm thanh, dáng điệu và sự quân bình.
```

Các khái niệm nhập môn:

```text
Hình
Thần
Khí
Sắc
Thanh
Cốt
Nhục
Tam đình
Ngũ quan
Thập nhị cung
Ngũ nhạc
Tứ đậu
```

### B. Tam đình

Chia khuôn mặt thành 3 vùng:

```text
Thượng đình: trán
Trung đình: mày, mắt, mũi, gò má
Hạ đình: miệng, cằm, hàm
```

App cần cho người dùng chọn:

```text
Thượng đình rộng/vừa/hẹp
Trung đình cân/khuyết/lệch
Hạ đình đầy/vừa/yếu
Ba đình cân đối hay lệch
```

Kết quả chỉ nên nói:

```text
Mức độ cân bằng tổng thể
Vùng nào nổi bật
Vùng nào cần quan sát thêm
Ý nghĩa tham khảo theo cổ học
```

### C. Ngũ quan

5 phần chính:

```text
Mày
Mắt
Mũi
Miệng
Tai
```

Mỗi phần cần có:

```text
Đặc điểm quan sát
Cách cổ học thường phân loại
Diễn giải mềm
Điểm cần tránh kết luận
```

Ví dụ:

```text
Mắt:
- sáng/tĩnh/động
- thần mắt ổn hay tán
- ánh nhìn có định hay không
```

Không kết luận kiểu “mắt này gian”. Chỉ nói:

```text
Theo cổ học, thần mắt được xem là phần biểu hiện sự tập trung và khí lực tinh thần. Tuy nhiên cần quan sát thêm hành vi và bối cảnh.
```

### D. Thập nhị cung trên mặt

Có thể xây module tham khảo:

```text
Mệnh cung
Tài bạch
Quan lộc
Phụ mẫu
Huynh đệ
Phu thê
Tử tức
Tật ách
Thiên di
Nô bộc
Phúc đức
Điền trạch
```

Nhưng giai đoạn 1 không nên làm quá nặng. Chỉ cần:

```text
hiển thị bản đồ vị trí
giải thích khái niệm
cho người dùng chọn có/không có dấu hiệu nổi bật
```

Không phán mạnh về hôn nhân, bệnh tật, tiền bạc.

### E. Hình khuôn mặt

Các nhóm tham khảo:

```text
mặt tròn
mặt vuông
mặt dài
mặt trái xoan
mặt tam giác
mặt gầy
mặt đầy
mặt lệch/cân
```

Diễn giải nên theo hướng:

```text
khí chất biểu tượng trong cổ học
khuynh hướng quan sát
điểm cần cân nhắc
```

Không kết luận tính cách cứng.

### F. Khí sắc

Module này cần rất thận trọng.

Chỉ nên nói:

```text
sắc mặt sáng/tối/khô/nhuận chỉ là quan sát bề ngoài
có thể bị ảnh hưởng bởi ánh sáng, giấc ngủ, sức khỏe, camera, trang điểm, tuổi tác
không dùng để chẩn đoán bệnh
```

Nên có cảnh báo:

```text
Nếu có dấu hiệu sức khỏe bất thường, hãy hỏi chuyên gia y tế.
```

### G. Thần thái và dáng vẻ

Có thể có phần:

```text
thần sắc
ánh nhìn
dáng ngồi
dáng đi
giọng nói
tác phong
```

Nhưng chỉ dùng làm tham khảo văn hóa, không kết luận nhân phẩm.

---

## 6. Luồng trải nghiệm app giai đoạn 1

Đề xuất flow:

### Bước 1: Mở app

Route:

```text
/nguthuat/tuong/xem-tuong
```

Hero:

```text
Tướng - Xem tướng tham khảo
Quan sát hình, thần, khí, sắc theo hệ thống cổ học. Nội dung chỉ dùng để học hiểu và tự soi chiếu, không thay thế đánh giá chuyên môn hay quyết định cá nhân.
```

CTA:

```text
Bắt đầu quan sát
Đọc nguyên tắc sử dụng
```

### Bước 2: Chọn kiểu xem

Các lựa chọn:

```text
Xem tổng quan khuôn mặt
Xem Tam đình
Xem Ngũ quan
Xem Thập nhị cung
Tự học bản đồ Nhân tướng
```

### Bước 3: Nhập dữ liệu thủ công

Dạng card chọn:

```text
Khuôn mặt: tròn / vuông / dài / trái xoan / chưa rõ
Tam đình: cân / lệch nhẹ / lệch rõ / chưa rõ
Mắt: thần ổn / tán / mệt / chưa rõ
Mũi: sống mũi rõ / thấp / đầy / gầy / chưa rõ
Miệng: cân / lệch / môi dày / môi mỏng / chưa rõ
Tai: rõ / nhỏ / áp sát / vểnh / chưa rõ
```

Mỗi mục phải có nút:

```text
Không chắc / Bỏ qua
```

### Bước 4: Kết quả

Kết quả gồm 5 phần:

```text
1. Tổng quan quan sát
2. Các điểm nổi bật
3. Các điểm chưa đủ dữ liệu
4. Diễn giải cổ học tham khảo
5. Gợi ý tự soi chiếu / điều chỉnh đời sống
```

Không có điểm số tốt/xấu kiểu 90/100.

Nếu cần điểm, chỉ dùng:

```text
Mức độ dữ liệu: thấp / vừa / khá
Mức độ cân bằng quan sát: thấp / vừa / khá
```

Không chấm “vận mệnh”.

---

## 7. Data cần chuẩn bị

Nên làm data dạng JSON/TS, không hardcode lung tung trong component.

Các bảng data nên có:

```text
faceShapes
threeCourts
fiveFeatures
twelvePalaces
complexionNotes
spiritNotes
glossary
safetyRules
interpretationTemplates
```

Ví dụ schema:

```ts
type ObservationRule = {
  id: string
  group: 'face_shape' | 'three_courts' | 'five_features' | 'twelve_palaces' | 'spirit' | 'complexion'
  label: string
  observation: string
  classicalMeaning: string
  softInterpretation: string
  caution: string
  avoidSaying: string[]
  confidenceNeed: 'low' | 'medium' | 'high'
}
```

Mỗi rule phải có:

```text
ý nghĩa cổ học
cách nói mềm
điều cần tránh
mức độ chắc chắn
```

---

## 8. Engine diễn giải

Engine không được kiểu:

```text
input A → phán B chắc chắn
```

Mà nên là:

```text
input A + B + C → tạo nhóm nhận xét mềm
```

Engine cần có:

```text
- gom nhóm quan sát
- phát hiện thiếu dữ liệu
- phát hiện mâu thuẫn
- giảm độ chắc chắn nếu người dùng chọn “không rõ”
- không xuất câu kết luận cực đoan
- luôn kèm disclaimer mềm
```

Ví dụ output:

```text
Dữ liệu hiện tại thiên về quan sát vùng Trung đình và Ngũ quan. Một vài dấu hiệu trong cổ học thường được liên hệ với khả năng tập trung và cách xử lý việc thực tế. Tuy nhiên, do thiếu dữ liệu về thần sắc, khí sắc và bối cảnh đời sống, kết quả chỉ nên xem như gợi ý tham khảo.
```

---

## 9. UI/UX mong muốn

Tone giống hệ app hiện tại:

```text
cổ học
trầm
vàng đồng
đen nâu
giấy cổ
thủy mặc
không neon
không game phép thuật
không SaaS quá hiện đại
```

Mobile phải tốt:

```text
header gọn: Cổ học + hamburger
không horizontal scroll
card dễ bấm
font tiếng Việt rõ
nút tối thiểu 44px
```

Trang Tướng nên có:

```text
hero cổ học
bản đồ khuôn mặt dạng minh họa line-art
card Tam đình
card Ngũ quan
card Thập nhị cung
form từng bước
kết quả dạng báo cáo mềm
glossary
nguyên tắc sử dụng
```

---

## 10. Ảnh/asset cần tạo sau

Cần chuẩn bị asset riêng cho Tướng:

```text
bg-tuong-hero.webp
icon-face-map.webp
icon-three-courts.webp
icon-five-features.webp
icon-twelve-palaces.webp
illustration-face-lineart.webp
illustration-result-scroll.webp
```

Thư mục đề xuất:

```text
apps/web/public/images/tuong/
```

Map public path:

```text
/images/tuong/bg-tuong-hero.webp
/images/tuong/icon-face-map.webp
/images/tuong/icon-three-courts.webp
/images/tuong/icon-five-features.webp
/images/tuong/icon-twelve-palaces.webp
```

---

## 11. Phạm vi dev nên làm trước

Mốc 1: dựng app Tướng bản khung

```text
/nguthuat/tuong/xem-tuong
```

Có:

```text
hero
nguyên tắc sử dụng
3-4 module card
form quan sát thủ công
kết quả demo rule-based
mobile responsive
```

Chưa cần:

```text
upload ảnh
AI nhận diện mặt
database
login
lưu lịch sử
credit
backend
```

Mốc 2: thêm data thật

```text
Tam đình
Ngũ quan
Thập nhị cung
Hình khuôn mặt
Thần khí sắc
Glossary
```

Mốc 3: tinh chỉnh engine

```text
kiểm tra mâu thuẫn
độ chắc chắn
thiếu dữ liệu
câu chữ an toàn
```

---

## 12. Câu chữ mẫu cho app

Hero:

```text
Tướng - Xem tướng tham khảo
Quan sát hình, thần, khí, sắc theo hệ thống cổ học. Nội dung dùng để học hiểu và tự soi chiếu, không thay thế tư duy độc lập hay đánh giá chuyên môn.
```

Disclaimer:

```text
Kết quả chỉ có giá trị tham khảo theo văn hóa cổ học. Không dùng để kết luận nhân phẩm, sức khỏe, năng lực, số phận hay đưa ra quyết định quan trọng về người khác.
```

Kết quả mẫu:

```text
Dữ liệu quan sát hiện thiên về vùng Ngũ quan. Một số đặc điểm được cổ học xem là dấu hiệu cần đối chiếu thêm với thần sắc và khí sắc. Vì còn thiếu bối cảnh, kết quả nên dùng như gợi ý tự soi chiếu, không phải kết luận.
```

Nút:

```text
Bắt đầu quan sát
Xem bản đồ khuôn mặt
Đọc nguyên tắc
Tạo báo cáo tham khảo
Quay về Ngũ thuật
```

---

## 13. Điều cấm trong app Tướng

Không viết:

```text
tướng này xấu
người này ác
người này nghèo
người này phản bội
người này bệnh
người này chết sớm
người này gian
người này bất tài
người này chắc chắn thành công
```

Không làm tính năng:

```text
chấm điểm con người
xếp hạng đẹp/xấu
đoán bệnh từ mặt
đoán đạo đức/tội phạm
đánh giá tuyển dụng
đánh giá bạn đời/người yêu theo kiểu quyết định hộ
```

---

## 14. Kết luận cho bên xử lý

App Tướng nên làm theo hướng:

```text
Cổ học tham khảo + tự quan sát + rule-based + ngôn từ thận trọng
```

Không làm theo hướng:

```text
AI phán mặt / xem số tuyệt đối / nhận diện ảnh rồi kết luận con người
```

Giai đoạn đầu chỉ cần khung app đẹp, dữ liệu thủ công, kết quả mềm, cùng tone với hệ Cổ học hiện tại. Sau khi khung ổn mới bổ sung data Nhân tướng học sâu hơn.
