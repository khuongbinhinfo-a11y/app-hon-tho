# Cơ sở xử lý từ file nghiên cứu

Bộ zip này được xử lý theo 3 trục:

## 1. Giữ lại làm data app

- Nhân tướng học dạng học thuật/tự quan sát.
- Tam đình.
- Ngũ quan.
- Thập nhị cung.
- Vùng mặt.
- Khí, sắc, thần.
- Dáng vẻ/cử chỉ ở mức mô tả trung tính.
- Tướng tay chỉ để phase sau.

## 2. Chuyển thành guardrail

Các phần học máy/AI khuôn mặt, privacy, fairness, dataset, legal risk được giữ làm rào chắn:

- Không dùng AI để suy luận nhân cách hay số phận.
- Không dùng ảnh mặt ở MVP.
- Không nhận diện sinh trắc học.
- Không dùng dữ liệu mặt cho quyết định bất lợi.

## 3. Khóa/restricted

Những nội dung có nguy cơ phán xét người khác bị đưa vào `restricted_rules.json`:

- phán gian/ác
- phán ngoại tình
- phán chết yểu
- phán bệnh
- phán tài vận chắc chắn
- phán hôn nhân
- phán con cái
- phán trí tuệ
- phán tội phạm
- body-shaming

## Ghi chú

Một số mục cổ học được đánh dấu `candidate` hoặc `needs_review` vì vị trí/ý nghĩa có thể khác nhau theo nguồn/phái. Trước khi public sâu nên có người am hiểu Nhân tướng học kiểm duyệt.
