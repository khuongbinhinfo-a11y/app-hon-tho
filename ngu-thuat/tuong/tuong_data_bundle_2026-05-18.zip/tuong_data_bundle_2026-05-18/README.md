# Gói data Tướng - Xem tướng tham khảo

Ngày tạo: 2026-05-18

## Mục tiêu

Gói này chuyển file nghiên cứu Nhân tướng học thành data có cấu trúc để làm mini-app:

`/nguthuat/tuong/xem-tuong`

App được định vị là thư viện cổ học và công cụ tự quan sát. Không phải máy phán tướng.

## Nguyên tắc cứng

- Không upload ảnh trong MVP 1.
- Không nhận diện danh tính.
- Không AI tự phán mặt.
- Không phán người tốt/xấu, gian/ác, giàu/nghèo, bệnh/tội, hôn nhân, tuổi thọ, con cái.
- Không dùng cho tuyển dụng, pháp lý, y tế, tín dụng, tình cảm/hôn nhân.
- Luôn có lựa chọn `Không chắc / Bỏ qua`.
- Nếu thiếu dữ liệu, trả về `Dữ liệu chưa đủ`.

## Cấu trúc thư mục

```text
data/
  import_index.json
  knowledge_map.json
  knowledge_cards.json
  three_courts.json
  five_features.json
  twelve_palaces.json
  face_regions.json
  qi_color_spirit.json
  safety_rules.json
  restricted_rules.json
  glossary.json
  interpretation_templates.json
  mvp_roadmap.json
  app_questions.json
  observation_checklists.json
  sources_to_review.json

schemas/
  knowledge_card.schema.json
  tuong.types.ts

markdown/
  01_knowledge_map.md
  02_data_tables.md
  03_restricted_and_safety.md
  04_mvp_roadmap.md
  05_dev_handoff.md

source_notes/
  processed_research_basis.md
  input_files/
```

## Số lượng data

- Knowledge cards: 224
- Tam đình: 3
- Ngũ quan: 5
- 12 cung: 12
- Vùng mặt: 20
- Khí/sắc/thần: 10
- Safety rules: 10
- Restricted rules: 18

## Cách dùng nhanh cho dev

1. Load `data/import_index.json`.
2. Import guardrail trước: `safety_rules.json` và `restricted_rules.json`.
3. Dựng từ điển từ `glossary.json`.
4. Dựng module học từ `three_courts.json`, `five_features.json`, `twelve_palaces.json`, `face_regions.json`, `qi_color_spirit.json`.
5. Sinh kết quả bằng `interpretation_templates.json`.
6. Dùng `knowledge_cards.json` làm kho card tra cứu.

## Trạng thái kiểm duyệt

- `approved_basic`: có thể dùng ở MVP với câu chữ mềm.
- `candidate`: cần đối chiếu nguồn trước khi public sâu.
- `needs_review`: cần người am hiểu Nhân tướng học kiểm duyệt.
- `restricted`: chỉ dùng nội bộ để chặn hoặc chuyển hướng.
