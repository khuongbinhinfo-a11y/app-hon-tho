Gói này là bộ thẻ kiến thức mẫu cho Tứ Trụ.

Dùng để dev copy vào repo và chạy thử cơ chế: lá số -> kéo thẻ kiến thức liên quan -> hiển thị cho người dùng.

Nó không phải data nghiên cứu đầy đủ, chỉ là mẫu chạy được trước.
