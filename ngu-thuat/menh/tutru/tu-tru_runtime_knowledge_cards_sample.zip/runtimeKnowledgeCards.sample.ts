export type KnowledgeCardStatus = "usable" | "review" | "internal";

export type KnowledgeCard = {
  id: string;
  title: string;
  topic: string;
  status: KnowledgeCardStatus;
  whenUse: {
    stems?: string[];
    branches?: string[];
    pillars?: string[];
    dayMasters?: string[];
    elements?: string[];
    hiddenStems?: string[];
    relations?: string[];
    topics?: string[];
  };
  tags: string[];
  body: string;
  usageNote: string;
  sourceCandidates?: string[];
};

export const runtimeKnowledgeCards: KnowledgeCard[] = [
  {
    id: "know_nhat_chu",
    title: "Nhật chủ",
    topic: "Trục đọc",
    status: "usable",
    whenUse: { topics: ["nhat-chu"] },
    tags: ["nhat-chu", "tru-ngay", "thap-than"],
    body: "Nhật chủ là Thiên Can của trụ ngày. Trong Tứ Trụ, đây là trục chính để đối chiếu Ngũ hành, Thập thần và các quan hệ sinh khắc trong toàn cục.",
    usageNote: "Dùng để xác định điểm quy chiếu của bản đồ. Không dùng riêng Nhật chủ để kết luận về đời người.",
    sourceCandidates: ["gls_tu_tru", "gls_thap_than"]
  },
  {
    id: "know_nham_thuy",
    title: "Nhâm Thủy",
    topic: "Nhật chủ",
    status: "usable",
    whenUse: { dayMasters: ["Nhâm Thủy"], stems: ["Nhâm"], elements: ["Thủy"] },
    tags: ["nham", "thuy", "nham-thuy", "nhat-chu"],
    body: "Nhâm thuộc Dương Thủy. Khi Nhâm là Nhật chủ, các hành Kim, Thủy, Mộc, Hỏa, Thổ được đọc theo quan hệ sinh trợ, đồng hành, sinh xuất, khắc chế hoặc tạo áp lực quanh trục Thủy.",
    usageNote: "Dùng để giải thích trục đọc Nhâm Thủy ở lớp cơ bản, chưa phải kết luận mạnh yếu cuối cùng.",
    sourceCandidates: ["gls_thien_can", "gls_ngu_hanh"]
  },
  {
    id: "know_thien_can",
    title: "Thiên Can",
    topic: "Can Chi",
    status: "usable",
    whenUse: { topics: ["thien-can"] },
    tags: ["thien-can", "can-chi", "stem"],
    body: "Thiên Can là lớp ký hiệu đứng trên trong cặp Can Chi. Mỗi Can mang tính âm/dương và một hành tương ứng, dùng để đọc quan hệ với Nhật chủ.",
    usageNote: "Dùng để giải thích lớp Can trong bốn trụ.",
    sourceCandidates: ["gls_thien_can", "rule_ganzhi_parity_pairing"]
  },
  {
    id: "know_dia_chi",
    title: "Địa Chi",
    topic: "Can Chi",
    status: "usable",
    whenUse: { topics: ["dia-chi"] },
    tags: ["dia-chi", "can-chi", "branch"],
    body: "Địa Chi là lớp ký hiệu đứng dưới trong cặp Can Chi. Mỗi Chi gắn với thời gian, phương vị, hành khí và có thể chứa các Tàng can bên trong.",
    usageNote: "Dùng để giải thích lớp Chi và mở đường đọc Tàng can.",
    sourceCandidates: ["gls_dia_chi", "gls_tang_can"]
  },
  {
    id: "know_can_chi",
    title: "Can Chi",
    topic: "Can Chi",
    status: "usable",
    whenUse: { topics: ["can-chi"] },
    tags: ["can-chi", "luc-thap-hoa-giap", "tu-tru"],
    body: "Can Chi là hệ phối hợp Thiên Can và Địa Chi thành vòng sáu mươi cặp. Trong Tứ Trụ, năm, tháng, ngày và giờ đều được biểu thị bằng một cặp Can Chi.",
    usageNote: "Dùng để giải thích vì sao kết quả được trình bày thành bốn cặp như Giáp Tý, Đinh Sửu.",
    sourceCandidates: ["gls_can_chi", "rule_ganzhi_parity_pairing"]
  },
  {
    id: "know_ngu_hanh",
    title: "Ngũ hành",
    topic: "Ngũ hành",
    status: "usable",
    whenUse: { topics: ["ngu-hanh"] },
    tags: ["ngu-hanh", "kim", "moc", "thuy", "hoa", "tho"],
    body: "Ngũ hành gồm Kim, Mộc, Thủy, Hỏa, Thổ. Trong bản đồ Tứ Trụ, mỗi hành có thể xuất hiện qua Thiên Can, Địa Chi và Tàng can, từ đó tạo nên sự phân bố khí trong toàn cục.",
    usageNote: "Dùng để đọc phân bố và quan hệ, không dùng riêng để kết luận tốt xấu.",
    sourceCandidates: ["gls_ngu_hanh", "topic_map_ngu_hanh"]
  },
  {
    id: "know_tang_can",
    title: "Tàng can",
    topic: "Tàng can",
    status: "usable",
    whenUse: { topics: ["tang-can"] },
    tags: ["tang-can", "dia-chi", "hidden-stems"],
    body: "Tàng can là các Thiên Can ẩn trong Địa Chi. Lớp này giúp đọc sâu hơn phần khí nằm dưới bề mặt của từng Chi.",
    usageNote: "Dùng để giải thích lớp ẩn bên trong Địa Chi. Khi đọc phải đặt cùng toàn cục.",
    sourceCandidates: ["gls_tang_can", "topic_map_tang_can"]
  },
  {
    id: "know_thap_than",
    title: "Thập thần",
    topic: "Thập thần",
    status: "usable",
    whenUse: { topics: ["thap-than"] },
    tags: ["thap-than", "nhat-chu", "relationship"],
    body: "Thập thần là hệ tên gọi các quan hệ giữa những Can khác với Nhật chủ. Nó không phải một nhãn tính cách cố định, mà là lớp quan hệ để đối chiếu trong bản đồ.",
    usageNote: "Dùng để giải thích quan hệ với Nhật chủ, không dùng riêng để phán nghề nghiệp, hôn nhân hay tài vận.",
    sourceCandidates: ["gls_thap_than", "topic_map_thap_than"]
  },
  {
    id: "know_lap_xuan",
    title: "Lập Xuân",
    topic: "Lịch pháp",
    status: "usable",
    whenUse: { topics: ["lap-xuan", "tiet-khi"] },
    tags: ["lap-xuan", "tiet-khi", "tru-nam", "tru-thang"],
    body: "Lập Xuân là mốc tiết khí quan trọng khi đối chiếu trụ năm và trụ tháng trong Tứ Trụ. Người sinh trước Lập Xuân có thể vẫn thuộc trụ năm trước theo cách tính tiết khí.",
    usageNote: "Dùng để giải thích các trường hợp năm dương lịch khác với trụ năm theo tiết khí.",
    sourceCandidates: ["gls_tiet_khi", "rule_year_pillar_lap_xuan"]
  },
  {
    id: "know_tiet_khi",
    title: "Tiết khí",
    topic: "Lịch pháp",
    status: "usable",
    whenUse: { topics: ["tiet-khi"] },
    tags: ["tiet-khi", "lich-phap", "tru-thang"],
    body: "Tiết khí là các mốc phân chia khí hậu trong năm. Trong Tứ Trụ, trụ tháng thường được đối chiếu theo tiết khí thay vì chỉ lấy tháng dương lịch thông thường.",
    usageNote: "Dùng để giải thích vì sao tháng sinh cần qua lớp lịch pháp trước khi lập trụ.",
    sourceCandidates: ["gls_tiet_khi", "topic_map_lich_phap"]
  },
  {
    id: "know_gio_mui",
    title: "Giờ Mùi",
    topic: "Trụ giờ",
    status: "usable",
    whenUse: { branches: ["Mùi"], topics: ["tru-gio"] },
    tags: ["gio-mui", "mui", "tru-gio"],
    body: "Giờ Mùi thuộc khoảng thời gian đầu giờ chiều trong hệ mười hai giờ Chi. Khi sinh vào 14:00 theo giờ địa phương, trụ giờ thường rơi vào chi Mùi.",
    usageNote: "Dùng để giải thích cách nhận diện Chi của trụ giờ.",
    sourceCandidates: ["rule_hour_branch_double_hour"]
  },
  {
    id: "know_tang_can_ty",
    title: "Tàng can của Tý",
    topic: "Tàng can",
    status: "usable",
    whenUse: { branches: ["Tý"], hiddenStems: ["Quý"] },
    tags: ["ty", "tang-can", "quy", "thuy"],
    body: "Tý chứa tàng can Quý, thuộc lớp Thủy. Khi bản đồ có Tý, cần xem lớp Thủy ẩn này cùng Nhật chủ và các trụ còn lại.",
    usageNote: "Dùng để giải thích Tàng can của Địa Chi Tý.",
    sourceCandidates: ["gls_tang_can", "topic_map_tang_can"]
  },
  {
    id: "know_tang_can_suu",
    title: "Tàng can của Sửu",
    topic: "Tàng can",
    status: "usable",
    whenUse: { branches: ["Sửu"], hiddenStems: ["Kỷ", "Quý", "Tân"] },
    tags: ["suu", "tang-can", "ky", "quy", "tan", "tho", "thuy", "kim"],
    body: "Sửu chứa các tàng can Kỷ, Quý, Tân. Điều này cho thấy trong Chi Sửu có lớp Thổ, Thủy và Kim ẩn, cần đọc cùng toàn cục thay vì chỉ nhìn hành bề mặt.",
    usageNote: "Dùng để giải thích Tàng can của Địa Chi Sửu.",
    sourceCandidates: ["gls_tang_can", "topic_map_tang_can"]
  },
  {
    id: "know_tang_can_tuat",
    title: "Tàng can của Tuất",
    topic: "Tàng can",
    status: "usable",
    whenUse: { branches: ["Tuất"], hiddenStems: ["Mậu", "Tân", "Đinh"] },
    tags: ["tuat", "tang-can", "mau", "tan", "dinh", "tho", "kim", "hoa"],
    body: "Tuất chứa các tàng can Mậu, Tân, Đinh. Khi bản đồ có Tuất, lớp Thổ, Kim và Hỏa ẩn cần được đưa vào phần phân bố và đối chiếu.",
    usageNote: "Dùng để giải thích Tàng can của Địa Chi Tuất.",
    sourceCandidates: ["gls_tang_can", "topic_map_tang_can"]
  },
  {
    id: "know_tang_can_mui",
    title: "Tàng can của Mùi",
    topic: "Tàng can",
    status: "usable",
    whenUse: { branches: ["Mùi"], hiddenStems: ["Kỷ", "Đinh", "Ất"] },
    tags: ["mui", "tang-can", "ky", "dinh", "at", "tho", "hoa", "moc"],
    body: "Mùi chứa các tàng can Kỷ, Đinh, Ất. Khi đọc bản đồ có Mùi, cần lưu ý lớp Thổ, Hỏa và Mộc ẩn bên trong Chi này.",
    usageNote: "Dùng để giải thích Tàng can của Địa Chi Mùi.",
    sourceCandidates: ["gls_tang_can", "topic_map_tang_can"]
  },
  {
    id: "know_kim_sinh_thuy",
    title: "Kim sinh Thủy",
    topic: "Quan hệ Ngũ hành",
    status: "usable",
    whenUse: { relations: ["Kim sinh Thủy"], dayMasters: ["Nhâm Thủy", "Quý Thủy"] },
    tags: ["kim", "thuy", "sinh", "ho-tro", "day-master-thuy"],
    body: "Theo quan hệ Ngũ hành, Kim sinh Thủy. Với Nhật chủ thuộc Thủy, các yếu tố Kim thường được xem là lớp sinh trợ trong đọc cấu trúc cơ bản.",
    usageNote: "Dùng để nhận diện lực hỗ trợ Nhật chủ Thủy, chưa phải kết luận vượng suy cuối cùng.",
    sourceCandidates: ["gls_ngu_hanh"]
  },
  {
    id: "know_tho_khac_thuy",
    title: "Thổ khắc Thủy",
    topic: "Quan hệ Ngũ hành",
    status: "usable",
    whenUse: { relations: ["Thổ khắc Thủy"], dayMasters: ["Nhâm Thủy", "Quý Thủy"] },
    tags: ["tho", "thuy", "khac", "ap-luc", "day-master-thuy"],
    body: "Theo quan hệ Ngũ hành, Thổ khắc Thủy. Với Nhật chủ thuộc Thủy, các yếu tố Thổ có thể được xem là lực tạo áp lực trong lớp đọc cấu trúc cơ bản.",
    usageNote: "Dùng để nhận diện lực khắc chế Nhật chủ Thủy, cần xét thêm mùa sinh và toàn cục.",
    sourceCandidates: ["gls_ngu_hanh"]
  },
  {
    id: "know_thuy_sinh_moc",
    title: "Thủy sinh Mộc",
    topic: "Quan hệ Ngũ hành",
    status: "usable",
    whenUse: { relations: ["Thủy sinh Mộc"], dayMasters: ["Nhâm Thủy", "Quý Thủy"] },
    tags: ["thuy", "moc", "sinh-xuat", "day-master-thuy"],
    body: "Theo quan hệ Ngũ hành, Thủy sinh Mộc. Với Nhật chủ Thủy, Mộc là lớp được Nhật chủ sinh xuất, biểu thị hướng khí đi ra khỏi trục Thủy trong cấu trúc cơ bản.",
    usageNote: "Dùng để giải thích quan hệ sinh xuất, không dùng riêng để kết luận tốt xấu.",
    sourceCandidates: ["gls_ngu_hanh"]
  },
  {
    id: "know_thuy_khac_hoa",
    title: "Thủy khắc Hỏa",
    topic: "Quan hệ Ngũ hành",
    status: "usable",
    whenUse: { relations: ["Thủy khắc Hỏa"], dayMasters: ["Nhâm Thủy", "Quý Thủy"] },
    tags: ["thuy", "hoa", "khac", "day-master-thuy"],
    body: "Theo quan hệ Ngũ hành, Thủy khắc Hỏa. Với Nhật chủ Thủy, Hỏa là lớp bị Nhật chủ khắc trong sơ đồ quan hệ cơ bản.",
    usageNote: "Dùng để nhận diện quan hệ khắc xuất, cần đọc cùng vị trí và toàn cục.",
    sourceCandidates: ["gls_ngu_hanh"]
  },
  {
    id: "know_hanh_noi_bat",
    title: "Hành nổi bật",
    topic: "Ngũ hành",
    status: "usable",
    whenUse: { topics: ["element-balance"] },
    tags: ["ngu-hanh", "noi-bat", "phan-bo"],
    body: "Hành nổi bật là hành xuất hiện nhiều hơn trong các lớp Can, Chi và Tàng can. Đây là dấu hiệu cấu trúc cần quan sát, chưa phải kết luận tốt xấu.",
    usageNote: "Dùng để giải thích nhãn nổi bật trong biểu đồ Ngũ hành.",
    sourceCandidates: ["gls_ngu_hanh"]
  },
  {
    id: "know_hanh_it_xuat_hien",
    title: "Hành ít xuất hiện",
    topic: "Ngũ hành",
    status: "usable",
    whenUse: { topics: ["element-balance"] },
    tags: ["ngu-hanh", "it-xuat-hien", "phan-bo"],
    body: "Hành ít xuất hiện là hành có tần suất thấp hơn trong lớp tính cơ bản. Cần đọc cùng mùa sinh và toàn cục, không nên kết luận là thiếu hay xấu chỉ từ con số.",
    usageNote: "Dùng để giải thích nhãn ít xuất hiện trong biểu đồ Ngũ hành.",
    sourceCandidates: ["gls_ngu_hanh"]
  },
  {
    id: "know_sinh_tro_nhat_chu",
    title: "Sinh trợ Nhật chủ",
    topic: "Ngũ hành",
    status: "usable",
    whenUse: { topics: ["day-master-relations"] },
    tags: ["nhat-chu", "sinh-tro", "ngu-hanh"],
    body: "Sinh trợ Nhật chủ là nhóm yếu tố cùng hành hoặc sinh ra hành của Nhật chủ. Lớp này giúp nhận diện các lực hỗ trợ trong bản đồ.",
    usageNote: "Dùng để mô tả quan hệ hỗ trợ, không dùng riêng để kết luận thuận lợi tuyệt đối.",
    sourceCandidates: ["gls_ngu_hanh", "gls_thap_than"]
  },
  {
    id: "know_ap_luc_nhat_chu",
    title: "Áp lực lên Nhật chủ",
    topic: "Ngũ hành",
    status: "usable",
    whenUse: { topics: ["day-master-relations"] },
    tags: ["nhat-chu", "ap-luc", "khac-che", "ngu-hanh"],
    body: "Áp lực lên Nhật chủ là nhóm yếu tố khắc hoặc làm tiêu hao trục Nhật chủ theo quan hệ Ngũ hành. Lớp này cần đọc cùng vị trí, mùa sinh và toàn cục.",
    usageNote: "Dùng để mô tả lực gây áp lực trong cấu trúc, không đồng nghĩa xấu tuyệt đối.",
    sourceCandidates: ["gls_ngu_hanh", "gls_thap_than"]
  },
  {
    id: "know_dong_van",
    title: "Dòng vận",
    topic: "Dòng vận",
    status: "review",
    whenUse: { topics: ["dai-van", "luu-nien"] },
    tags: ["dai-van", "luu-nien", "chu-ky"],
    body: "Dòng vận là lớp chu kỳ dùng để đối chiếu sau khi đã có bản đồ gốc. Trong bản hiện tại, phần này chỉ nên xem như lớp tham khảo, chưa phải kết luận sự kiện.",
    usageNote: "Dùng để giải thích khu Dòng vận. Chưa dùng làm kết luận tự động khi engine vận chưa hoàn chỉnh.",
    sourceCandidates: ["topic_map_dai_van", "topic_map_luu_nien"]
  }
];
