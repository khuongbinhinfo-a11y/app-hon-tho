import type { KnowledgeCard } from "../data/runtimeKnowledgeCards";
import { runtimeKnowledgeCards } from "../data/runtimeKnowledgeCards";

type PillarLike = {
  stem?: string;
  branch?: string;
  pillar?: string;
  element?: string;
  hiddenStems?: string[];
};

type ChartLike = {
  pillars?: {
    year?: PillarLike;
    month?: PillarLike;
    day?: PillarLike;
    hour?: PillarLike;
  };
  summary?: {
    dayMaster?: string;
    elementBalance?: Record<string, number>;
  };
};

export type KnowledgeMatch = KnowledgeCard & {
  reason: string;
  score: number;
};

const normalize = (value: string) =>
  value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d")
    .replace(/\s+/g, "-");

export function buildKnowledgeQueryKeys(chart: ChartLike): string[] {
  const keys = new Set<string>(["topic:can-chi", "topic:ngu-hanh", "topic:tang-can", "topic:thap-than"]);
  const pillars = chart.pillars ? Object.values(chart.pillars).filter(Boolean) as PillarLike[] : [];

  for (const pillar of pillars) {
    if (pillar.stem) keys.add(`stem:${normalize(pillar.stem)}`);
    if (pillar.branch) keys.add(`branch:${normalize(pillar.branch)}`);
    if (pillar.pillar) keys.add(`pillar:${normalize(pillar.pillar)}`);
    if (pillar.element) keys.add(`element:${normalize(pillar.element)}`);
    for (const hs of pillar.hiddenStems ?? []) keys.add(`hidden-stem:${normalize(hs)}`);
  }

  if (chart.summary?.dayMaster) {
    keys.add(`day-master:${normalize(chart.summary.dayMaster)}`);
    if (chart.summary.dayMaster.includes("Thủy")) {
      keys.add("relation:kim-sinh-thuy");
      keys.add("relation:tho-khac-thuy");
      keys.add("relation:thuy-sinh-moc");
      keys.add("relation:thuy-khac-hoa");
      keys.add("topic:day-master-relations");
    }
  }

  if (chart.summary?.elementBalance) keys.add("topic:element-balance");
  if (pillars.some((p) => p.branch === "Mùi")) keys.add("topic:tru-gio");
  keys.add("topic:tiet-khi");
  keys.add("topic:lap-xuan");

  return [...keys];
}

function cardScore(card: KnowledgeCard, queryKeys: string[], chart: ChartLike): { score: number; reason: string } {
  let score = 0;
  const reasons: string[] = [];
  const keySet = new Set(queryKeys);
  const pillars = chart.pillars ? Object.values(chart.pillars).filter(Boolean) as PillarLike[] : [];
  const stems = pillars.map((p) => p.stem).filter(Boolean) as string[];
  const branches = pillars.map((p) => p.branch).filter(Boolean) as string[];
  const pillarNames = pillars.map((p) => p.pillar).filter(Boolean) as string[];
  const hiddenStems = pillars.flatMap((p) => p.hiddenStems ?? []);
  const dayMaster = chart.summary?.dayMaster;

  for (const tag of card.tags) {
    const normalizedTag = normalize(tag);
    if ([...keySet].some((key) => key.endsWith(normalizedTag) || normalizedTag.includes(key.replace(/^[^:]+:/, "")))) {
      score += 4;
    }
  }

  if (card.whenUse.stems?.some((s) => stems.includes(s))) { score += 10; reasons.push("trùng Thiên Can trong bản đồ"); }
  if (card.whenUse.branches?.some((b) => branches.includes(b))) { score += 12; reasons.push("trùng Địa Chi trong bản đồ"); }
  if (card.whenUse.pillars?.some((p) => pillarNames.includes(p))) { score += 14; reasons.push("trùng trụ Can Chi trong bản đồ"); }
  if (dayMaster && card.whenUse.dayMasters?.includes(dayMaster)) { score += 16; reasons.push(`liên quan Nhật chủ ${dayMaster}`); }
  if (card.whenUse.hiddenStems?.some((h) => hiddenStems.includes(h))) { score += 8; reasons.push("trùng Tàng can trong bản đồ"); }
  if (card.whenUse.relations?.some((r) => keySet.has(`relation:${normalize(r)}`))) { score += 14; reasons.push("liên quan quan hệ Ngũ hành với Nhật chủ"); }
  if (card.whenUse.topics?.some((t) => keySet.has(`topic:${normalize(t)}`) || keySet.has(`topic:${t}`))) { score += 6; reasons.push("trùng chủ đề cần đọc"); }

  if (card.status === "usable") score += 2;
  if (card.status === "internal") score -= 50;

  return { score, reason: reasons[0] ?? "liên quan đến bản đồ Tứ Trụ" };
}

export function matchKnowledgeForChart(chart: ChartLike, cards: KnowledgeCard[] = runtimeKnowledgeCards) {
  const queryKeys = buildKnowledgeQueryKeys(chart);
  const matchedCards = cards
    .map((card) => ({ ...card, ...cardScore(card, queryKeys, chart) }))
    .filter((card) => card.status !== "internal" && card.score > 0)
    .sort((a, b) => b.score - a.score);

  return {
    queryKeys,
    matchedCards,
    priorityCards: matchedCards.slice(0, 10)
  };
}
