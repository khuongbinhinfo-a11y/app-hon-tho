# Y học cổ học - Folk Care data package

Gói này chuyển file `deep-research-report (1).md` thành data/engine cho module:

**Cẩm nang chăm sóc đời sống an toàn**

## File đề xuất copy vào repo

```txt
ngu-thuat/y/yhoc/src/data/yhoc/folkCareTypes.ts
ngu-thuat/y/yhoc/src/data/yhoc/folkCareCategories.ts
ngu-thuat/y/yhoc/src/data/yhoc/folkCareSafety.ts
ngu-thuat/y/yhoc/src/data/yhoc/folkCare.ts
ngu-thuat/y/yhoc/src/data/yhoc/folkCareIndex.ts
ngu-thuat/y/yhoc/src/engine/folkCareEngine.ts
```

## Nội dung chính

- 50 `FolkCareItem`
- 6 nhóm danh mục
- Rule an toàn: red flag, nhóm nhạy cảm, safetyLevel high
- Engine `interpretFolkCare(input)`
- Không kê đơn, không liều lượng, không dùng làm chẩn đoán

## Nguyên tắc

Module này chỉ nên hiển thị như “tham khảo / chăm sóc nhẹ”.
Không gọi là “mẹo chữa bệnh”, không hứa hiệu quả, không hướng dẫn tự xử lý tình trạng nặng.

## Test nhanh sau khi copy

```powershell
cd "D:\Wep_Yhocnhanai\Web_Goc_Binh_Yen\app-hontho\ngu-thuat\y\yhoc"
npm run build
```

## Gợi ý UI

Thêm tab hoặc card mới trong app Y:

- Cẩm nang chăm sóc đời sống
- Tìm theo tình huống
- Lọc theo nhóm
- Mỗi item hiển thị:
  - tình huống
  - có thể thử
  - nên tránh
  - không phù hợp cho ai
  - khi nào đi khám
  - cảnh báo an toàn

Nếu `interpretFolkCare(...).emergencyFirst === true`, chỉ hiển thị warning/nextActions, không hiển thị mẹo.
