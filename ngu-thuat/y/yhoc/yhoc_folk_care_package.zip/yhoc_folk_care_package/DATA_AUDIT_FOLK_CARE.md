# Folk Care data audit notes

Generated files: 2026-05-19T11:50:37.430338Z

## Counts

- Categories: 6
- Items: 50
- High safety items: 5
- Medium safety items: 3
- Low safety items: 42

## Safety approach

- No gram/ml dosage.
- No formula mixing.
- No promises of cure.
- Red flags are prioritized.
- Sensitive profiles hide folk notes and ingredient-based notes.
- High-safety items only show doctor-first guidance.

## Known limitation

This is a structured MVP data pack. Before production, a qualified YHCT/medical reviewer should review wording and every folk note.
