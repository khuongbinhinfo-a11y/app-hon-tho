// src/data/yhoc/folkCareCategories.ts
import type { FolkCareItem } from './folkCareTypes';

export const FOLK_CARE_CATEGORIES = [
  { id: "cold_weather", name: "Cảm lạnh / thời tiết", icon: "🌬️", description: "Các khó chịu nhẹ liên quan gió lạnh, ẩm, khô họng, sổ mũi, mệt sau dầm mưa." },
  { id: "digestion", name: "Tiêu hóa", icon: "🍚", description: "Các khó chịu nhẹ sau ăn như đầy bụng, ăn không tiêu, táo bón nhẹ, tiêu lỏng nhẹ." },
  { id: "sleep_mind", name: "Ngủ nghỉ / thần chí", icon: "🌙", description: "Khó ngủ nhẹ, thức khuya, căng thẳng, lo nghĩ, bồn chồn nhẹ." },
  { id: "body_movement", name: "Cơ xương / sinh hoạt", icon: "🪷", description: "Mỏi cổ vai gáy, mỏi lưng, mỏi mắt, tê mỏi do tư thế, mệt sau vận động." },
  { id: "hot_dry_damp", name: "Nóng / khô / ẩm", icon: "💧", description: "Nóng trong nhẹ, khô miệng, da khô, nặng người khi trời ẩm." },
  { id: "family_women", name: "Phụ nữ / gia đình", icon: "🛡️", description: "Mệt trước kỳ kinh, khó chịu ngày hành kinh, thai kỳ, sau sinh, trẻ nhỏ. Nhóm này luôn thận trọng." },
] as const;

export type FolkCareCategoryId = typeof FOLK_CARE_CATEGORIES[number]['id'];

export function getFolkCareCategoryLabel(categoryId: string) {
  return FOLK_CARE_CATEGORIES.find((category) => category.id === categoryId)?.name ?? categoryId;
}

export function groupFolkCareByCategory(items: FolkCareItem[]) {
  return FOLK_CARE_CATEGORIES.map((category) => ({
    ...category,
    items: items.filter((item) => item.categoryId === category.id),
  }));
}
