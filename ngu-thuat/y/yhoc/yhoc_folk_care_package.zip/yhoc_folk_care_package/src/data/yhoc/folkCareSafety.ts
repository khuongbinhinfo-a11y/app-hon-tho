// src/data/yhoc/folkCareSafety.ts
// Quy tắc an toàn chung cho module Cẩm nang chăm sóc đời sống.
// Không dùng nội dung này để tự xử lý tình trạng nặng.

export const FOLK_CARE_GLOBAL_DISCLAIMER =
  'Các gợi ý chỉ mang tính tham khảo, không phải chẩn đoán và không thay thế bác sĩ. Nếu tình trạng nặng lên, kéo dài hoặc có dấu hiệu nguy hiểm, hãy liên hệ cơ sở y tế.';

export const FOLK_CARE_FORBIDDEN_WORDING = [
  'chữa khỏi',
  'trị dứt',
  'bảo đảm khỏi',
  'bài thuốc đặc trị',
  'tự chữa tại nhà',
  'bốc thuốc',
  'thần dược',
  'liều lượng',
  'uống theo thang',
  'thay thế bác sĩ',
];

export const FOLK_CARE_UNSAFE_GROUPS = [
  'Trẻ nhỏ',
  'Phụ nữ mang thai',
  'Người đang cho con bú',
  'Người cao tuổi yếu',
  'Người bệnh nền nặng',
  'Người đang dùng thuốc dài ngày',
  'Người có dị ứng hoặc từng phản ứng với nguyên liệu được nhắc đến',
];

export const FOLK_CARE_INGREDIENT_WARNINGS: Record<string, string> = {
  honey:
    'Mật ong không dùng cho trẻ dưới 1 tuổi. Người dị ứng hoặc đang cần kiểm soát đường huyết nên hỏi bác sĩ trước.',
  ginger:
    'Gừng chỉ nên xem là gia vị/kinh nghiệm tham khảo. Người loét dạ dày nặng, đang dùng thuốc chống đông, thai kỳ hoặc bệnh nền nên hỏi bác sĩ.',
  salt:
    'Không lạm dụng muối. Người tăng huyết áp, bệnh thận hoặc phù cần thận trọng.',
  steam:
    'Không tự xông hơi/xông mặt khi sốt cao, khó thở, trẻ nhỏ, người cao tuổi yếu, bệnh tim mạch hoặc nguy cơ bỏng.',
  alcohol:
    'Không dùng rượu thuốc/rượu ngâm để tự xử lý khó chịu thường ngày.',
};

export const FOLK_CARE_RED_FLAGS = [
  'Đau ngực',
  'Khó thở',
  'Sốt cao hoặc sốt kéo dài',
  'Co giật',
  'Ngất',
  'Lơ mơ',
  'Liệt mặt/tay/chân',
  'Nói khó',
  'Đau đầu dữ dội đột ngột',
  'Đau bụng dữ dội',
  'Nôn liên tục',
  'Nôn ra máu',
  'Đi cầu ra máu',
  'Dấu hiệu mất nước',
  'Ra huyết bất thường',
  'Thai kỳ có bất thường',
  'Trẻ nhỏ có dấu hiệu nặng',
  'Ý nghĩ tự hại',
];

export const FOLK_CARE_UI_WORDING = [
  'Các gợi ý dưới đây chỉ mang tính tham khảo và không thay thế ý kiến bác sĩ.',
  'Nếu tình trạng kéo dài hoặc nặng lên, hãy đi khám để được đánh giá phù hợp.',
  'Ưu tiên nghỉ ngơi, nước ấm, ăn uống nhẹ, vận động nhẹ và theo dõi triệu chứng.',
  'Nếu bạn đang mang thai, cho con bú, có bệnh nền hoặc dùng thuốc dài ngày, hãy hỏi bác sĩ trước khi áp dụng mẹo dân gian.',
  'Đối với trẻ nhỏ, không tự áp dụng mẹo dân gian khi chưa hỏi bác sĩ nhi.',
  'Khi có dấu hiệu nguy hiểm, app sẽ ẩn mẹo chăm sóc và ưu tiên cảnh báo đi khám/cấp cứu.',
];
