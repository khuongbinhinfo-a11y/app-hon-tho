// src/data/yhoc/folkCareTypes.ts
// Module: Cẩm nang chăm sóc đời sống an toàn
// Generated from deep-research-report (1).md.
// Scope: tham khảo, tự chăm sóc nhẹ, không chẩn đoán, không kê đơn, không liều lượng.

export type FolkCareEvidenceLevel =
  | 'general_self_care'
  | 'folk_experience'
  | 'classical_reference'
  | 'needs_expert_review';

export type FolkCareSafetyLevel = 'low' | 'medium' | 'high';

export type FolkCareItem = {
  id: string;
  category: string;
  categoryId: string;
  title: string;
  situation: string;
  commonSigns: string[];
  classicalView?: string;
  safeCare: string[];
  folkNotes?: string[];
  foodLifestyleNotes?: string[];
  avoid: string[];
  notFor: string[];
  redFlags: string[];
  whenToSeeDoctor: string[];
  appWording: {
    short: string;
    detailed: string;
  };
  forbiddenClaims: string[];
  evidenceLevel: FolkCareEvidenceLevel;
  safetyLevel: FolkCareSafetyLevel;
  sources: string[];
};

export type FolkCareUserProfile = {
  isPregnant?: boolean;
  isBreastfeeding?: boolean;
  isChild?: boolean;
  isElderly?: boolean;
  hasChronicCondition?: boolean;
  usesLongTermMedication?: boolean;
  hasKnownAllergy?: boolean;
};

export type FolkCareInput = {
  selectedItemId?: string;
  selectedCategoryId?: string;
  signs?: string[];
  redFlags?: string[];
  durationDays?: number;
  profile?: FolkCareUserProfile;
};

export type FolkCareResult = {
  emergencyFirst: boolean;
  hiddenForSafety: boolean;
  item?: FolkCareItem;
  visibleSafeCare: string[];
  visibleFolkNotes: string[];
  visibleFoodLifestyleNotes: string[];
  warnings: string[];
  nextActions: string[];
  confidence: 'low' | 'medium';
};
