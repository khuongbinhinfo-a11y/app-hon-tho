// src/data/yhoc/folkCare.ts
import type { FolkCareItem } from './folkCareTypes';

export const FOLK_CARE_ITEMS: FolkCareItem[] = [
  {
      id: "cold_light",
      category: "Cảm lạnh / thời tiết",
      categoryId: "cold_weather",
      title: "Cảm lạnh nhẹ",
      situation: "Cảm giác ớn lạnh, mệt, hắt hơi hoặc chảy mũi nhẹ sau khi gặp gió lạnh.",
      commonSigns: [
        "ớn lạnh",
        "hắt hơi",
        "mệt nhẹ"
      ],
      classicalView: "Theo cách nói cổ học, nhóm này thường được mô tả quanh yếu tố phong, hàn, táo hoặc sự thay đổi thời tiết làm cơ thể khó chịu.",
      safeCare: [
        "Nghỉ ngơi ở nơi ấm, thoáng và tránh gió lùa trực tiếp.",
        "Uống nước ấm từng ngụm, không dùng đồ quá lạnh.",
        "Giữ ấm cổ, ngực, bàn chân; theo dõi thân nhiệt và nhịp thở."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm, giữ ấm cổ/ngực/bàn chân; nếu có nhắc gừng hoặc mật ong thì chỉ xem là kinh nghiệm tham khảo và cần tránh ở nhóm nguy cơ."
      ],
      foodLifestyleNotes: [
        "Ưu tiên món ấm, mềm, dễ tiêu như cháo loãng hoặc súp nhẹ.",
        "Tránh rượu bia, đồ lạnh, đồ quá cay nóng khi người đang mệt."
      ],
      avoid: [
        "Không tự xông hơi khi sốt cao, khó thở, người già yếu hoặc trẻ nhỏ.",
        "Không cạo gió mạnh, không dùng rượu thuốc, không trì hoãn đi khám nếu có dấu hiệu nặng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao hoặc sốt kéo dài",
        "Khó thở",
        "Đau ngực",
        "Co giật",
        "Lơ mơ hoặc yếu liệt tay chân"
      ],
      whenToSeeDoctor: [
        "Triệu chứng nặng lên hoặc không giảm sau vài ngày.",
        "Có sốt cao, khó thở, đau ngực, lơ mơ hoặc co giật.",
        "Người bệnh nền, thai kỳ, trẻ nhỏ hoặc người cao tuổi nên hỏi bác sĩ sớm."
      ],
      appWording: {
        short: "Cảm lạnh nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống cảm lạnh nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "folk_experience",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "runny_nose_light",
      category: "Cảm lạnh / thời tiết",
      categoryId: "cold_weather",
      title: "Sổ mũi nhẹ",
      situation: "Chảy nước mũi hoặc nghẹt mũi nhẹ, chưa có sốt cao hay khó thở.",
      commonSigns: [
        "chảy nước mũi",
        "nghẹt mũi",
        "hắt hơi"
      ],
      classicalView: "Theo cách nói cổ học, nhóm này thường được mô tả quanh yếu tố phong, hàn, táo hoặc sự thay đổi thời tiết làm cơ thể khó chịu.",
      safeCare: [
        "Nghỉ ngơi ở nơi ấm, thoáng và tránh gió lùa trực tiếp.",
        "Uống nước ấm từng ngụm, không dùng đồ quá lạnh.",
        "Giữ ấm cổ, ngực, bàn chân; theo dõi thân nhiệt và nhịp thở."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm, giữ ấm cổ/ngực/bàn chân; nếu có nhắc gừng hoặc mật ong thì chỉ xem là kinh nghiệm tham khảo và cần tránh ở nhóm nguy cơ."
      ],
      foodLifestyleNotes: [
        "Ưu tiên món ấm, mềm, dễ tiêu như cháo loãng hoặc súp nhẹ.",
        "Tránh rượu bia, đồ lạnh, đồ quá cay nóng khi người đang mệt."
      ],
      avoid: [
        "Không tự xông hơi khi sốt cao, khó thở, người già yếu hoặc trẻ nhỏ.",
        "Không cạo gió mạnh, không dùng rượu thuốc, không trì hoãn đi khám nếu có dấu hiệu nặng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao hoặc sốt kéo dài",
        "Khó thở",
        "Đau ngực",
        "Co giật",
        "Lơ mơ hoặc yếu liệt tay chân"
      ],
      whenToSeeDoctor: [
        "Triệu chứng nặng lên hoặc không giảm sau vài ngày.",
        "Có sốt cao, khó thở, đau ngực, lơ mơ hoặc co giật.",
        "Người bệnh nền, thai kỳ, trẻ nhỏ hoặc người cao tuổi nên hỏi bác sĩ sớm."
      ],
      appWording: {
        short: "Sổ mũi nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống sổ mũi nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "folk_experience",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "cold_hands_feet",
      category: "Cảm lạnh / thời tiết",
      categoryId: "cold_weather",
      title: "Lạnh tay chân",
      situation: "Tay chân lạnh hơn thường lệ khi thời tiết lạnh hoặc sau khi ngồi lâu.",
      commonSigns: [
        "tay chân lạnh",
        "rùng mình",
        "sợ lạnh"
      ],
      classicalView: "Theo cách nói cổ học, nhóm này thường được mô tả quanh yếu tố phong, hàn, táo hoặc sự thay đổi thời tiết làm cơ thể khó chịu.",
      safeCare: [
        "Nghỉ ngơi ở nơi ấm, thoáng và tránh gió lùa trực tiếp.",
        "Uống nước ấm từng ngụm, không dùng đồ quá lạnh.",
        "Giữ ấm cổ, ngực, bàn chân; theo dõi thân nhiệt và nhịp thở."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm, giữ ấm cổ/ngực/bàn chân; nếu có nhắc gừng hoặc mật ong thì chỉ xem là kinh nghiệm tham khảo và cần tránh ở nhóm nguy cơ."
      ],
      foodLifestyleNotes: [
        "Ưu tiên món ấm, mềm, dễ tiêu như cháo loãng hoặc súp nhẹ.",
        "Tránh rượu bia, đồ lạnh, đồ quá cay nóng khi người đang mệt."
      ],
      avoid: [
        "Không tự xông hơi khi sốt cao, khó thở, người già yếu hoặc trẻ nhỏ.",
        "Không cạo gió mạnh, không dùng rượu thuốc, không trì hoãn đi khám nếu có dấu hiệu nặng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao hoặc sốt kéo dài",
        "Khó thở",
        "Đau ngực",
        "Co giật",
        "Lơ mơ hoặc yếu liệt tay chân"
      ],
      whenToSeeDoctor: [
        "Triệu chứng nặng lên hoặc không giảm sau vài ngày.",
        "Có sốt cao, khó thở, đau ngực, lơ mơ hoặc co giật.",
        "Người bệnh nền, thai kỳ, trẻ nhỏ hoặc người cao tuổi nên hỏi bác sĩ sớm."
      ],
      appWording: {
        short: "Lạnh tay chân: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống tay chân lạnh, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "folk_experience",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "dry_throat_light",
      category: "Cảm lạnh / thời tiết",
      categoryId: "cold_weather",
      title: "Khô họng nhẹ",
      situation: "Cảm giác họng khô, vướng nhẹ, thường rõ hơn khi thiếu nước hoặc nằm điều hòa.",
      commonSigns: [
        "khô họng",
        "vướng họng",
        "khát nhẹ"
      ],
      classicalView: "Theo cách nói cổ học, nhóm này thường được mô tả quanh yếu tố phong, hàn, táo hoặc sự thay đổi thời tiết làm cơ thể khó chịu.",
      safeCare: [
        "Nghỉ ngơi ở nơi ấm, thoáng và tránh gió lùa trực tiếp.",
        "Uống nước ấm từng ngụm, không dùng đồ quá lạnh.",
        "Giữ ấm cổ, ngực, bàn chân; theo dõi thân nhiệt và nhịp thở."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm, giữ ấm cổ/ngực/bàn chân; nếu có nhắc gừng hoặc mật ong thì chỉ xem là kinh nghiệm tham khảo và cần tránh ở nhóm nguy cơ."
      ],
      foodLifestyleNotes: [
        "Ưu tiên món ấm, mềm, dễ tiêu như cháo loãng hoặc súp nhẹ.",
        "Tránh rượu bia, đồ lạnh, đồ quá cay nóng khi người đang mệt."
      ],
      avoid: [
        "Không tự xông hơi khi sốt cao, khó thở, người già yếu hoặc trẻ nhỏ.",
        "Không cạo gió mạnh, không dùng rượu thuốc, không trì hoãn đi khám nếu có dấu hiệu nặng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao hoặc sốt kéo dài",
        "Khó thở",
        "Đau ngực",
        "Co giật",
        "Lơ mơ hoặc yếu liệt tay chân"
      ],
      whenToSeeDoctor: [
        "Triệu chứng nặng lên hoặc không giảm sau vài ngày.",
        "Có sốt cao, khó thở, đau ngực, lơ mơ hoặc co giật.",
        "Người bệnh nền, thai kỳ, trẻ nhỏ hoặc người cao tuổi nên hỏi bác sĩ sớm."
      ],
      appWording: {
        short: "Khô họng nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống khô họng nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "folk_experience",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "dry_cough_no_fever",
      category: "Cảm lạnh / thời tiết",
      categoryId: "cold_weather",
      title: "Ho khan nhẹ không sốt",
      situation: "Ho khan lác đác, không sốt cao, không khó thở, không đau ngực.",
      commonSigns: [
        "ho khan",
        "ngứa họng",
        "không sốt cao"
      ],
      classicalView: "Theo cách nói cổ học, nhóm này thường được mô tả quanh yếu tố phong, hàn, táo hoặc sự thay đổi thời tiết làm cơ thể khó chịu.",
      safeCare: [
        "Nghỉ ngơi ở nơi ấm, thoáng và tránh gió lùa trực tiếp.",
        "Uống nước ấm từng ngụm, không dùng đồ quá lạnh.",
        "Giữ ấm cổ, ngực, bàn chân; theo dõi thân nhiệt và nhịp thở."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm, giữ ấm cổ/ngực/bàn chân; nếu có nhắc gừng hoặc mật ong thì chỉ xem là kinh nghiệm tham khảo và cần tránh ở nhóm nguy cơ."
      ],
      foodLifestyleNotes: [
        "Ưu tiên món ấm, mềm, dễ tiêu như cháo loãng hoặc súp nhẹ.",
        "Tránh rượu bia, đồ lạnh, đồ quá cay nóng khi người đang mệt."
      ],
      avoid: [
        "Không tự xông hơi khi sốt cao, khó thở, người già yếu hoặc trẻ nhỏ.",
        "Không cạo gió mạnh, không dùng rượu thuốc, không trì hoãn đi khám nếu có dấu hiệu nặng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao hoặc sốt kéo dài",
        "Khó thở",
        "Đau ngực",
        "Co giật",
        "Lơ mơ hoặc yếu liệt tay chân"
      ],
      whenToSeeDoctor: [
        "Triệu chứng nặng lên hoặc không giảm sau vài ngày.",
        "Có sốt cao, khó thở, đau ngực, lơ mơ hoặc co giật.",
        "Người bệnh nền, thai kỳ, trẻ nhỏ hoặc người cao tuổi nên hỏi bác sĩ sớm."
      ],
      appWording: {
        short: "Ho khan nhẹ không sốt: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống ho khan nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "folk_experience",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "rain_fatigue",
      category: "Cảm lạnh / thời tiết",
      categoryId: "cold_weather",
      title: "Mệt sau dầm mưa",
      situation: "Cảm giác lạnh, uể oải, nặng đầu nhẹ sau khi bị ướt mưa.",
      commonSigns: [
        "mệt",
        "lạnh người",
        "nặng đầu nhẹ"
      ],
      classicalView: "Theo cách nói cổ học, nhóm này thường được mô tả quanh yếu tố phong, hàn, táo hoặc sự thay đổi thời tiết làm cơ thể khó chịu.",
      safeCare: [
        "Nghỉ ngơi ở nơi ấm, thoáng và tránh gió lùa trực tiếp.",
        "Uống nước ấm từng ngụm, không dùng đồ quá lạnh.",
        "Giữ ấm cổ, ngực, bàn chân; theo dõi thân nhiệt và nhịp thở."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm, giữ ấm cổ/ngực/bàn chân; nếu có nhắc gừng hoặc mật ong thì chỉ xem là kinh nghiệm tham khảo và cần tránh ở nhóm nguy cơ."
      ],
      foodLifestyleNotes: [
        "Ưu tiên món ấm, mềm, dễ tiêu như cháo loãng hoặc súp nhẹ.",
        "Tránh rượu bia, đồ lạnh, đồ quá cay nóng khi người đang mệt."
      ],
      avoid: [
        "Không tự xông hơi khi sốt cao, khó thở, người già yếu hoặc trẻ nhỏ.",
        "Không cạo gió mạnh, không dùng rượu thuốc, không trì hoãn đi khám nếu có dấu hiệu nặng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao hoặc sốt kéo dài",
        "Khó thở",
        "Đau ngực",
        "Co giật",
        "Lơ mơ hoặc yếu liệt tay chân"
      ],
      whenToSeeDoctor: [
        "Triệu chứng nặng lên hoặc không giảm sau vài ngày.",
        "Có sốt cao, khó thở, đau ngực, lơ mơ hoặc co giật.",
        "Người bệnh nền, thai kỳ, trẻ nhỏ hoặc người cao tuổi nên hỏi bác sĩ sớm."
      ],
      appWording: {
        short: "Mệt sau dầm mưa: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống mệt sau dầm mưa, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "folk_experience",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "wind_headache_light",
      category: "Cảm lạnh / thời tiết",
      categoryId: "cold_weather",
      title: "Đau đầu nhẹ do gió lạnh",
      situation: "Đầu hơi nặng hoặc đau âm ỉ sau khi đi gió, không dữ dội đột ngột.",
      commonSigns: [
        "đau đầu nhẹ",
        "sợ gió",
        "căng vùng trán"
      ],
      classicalView: "Theo cách nói cổ học, nhóm này thường được mô tả quanh yếu tố phong, hàn, táo hoặc sự thay đổi thời tiết làm cơ thể khó chịu.",
      safeCare: [
        "Nghỉ ngơi ở nơi ấm, thoáng và tránh gió lùa trực tiếp.",
        "Uống nước ấm từng ngụm, không dùng đồ quá lạnh.",
        "Giữ ấm cổ, ngực, bàn chân; theo dõi thân nhiệt và nhịp thở."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm, giữ ấm cổ/ngực/bàn chân; nếu có nhắc gừng hoặc mật ong thì chỉ xem là kinh nghiệm tham khảo và cần tránh ở nhóm nguy cơ."
      ],
      foodLifestyleNotes: [
        "Ưu tiên món ấm, mềm, dễ tiêu như cháo loãng hoặc súp nhẹ.",
        "Tránh rượu bia, đồ lạnh, đồ quá cay nóng khi người đang mệt."
      ],
      avoid: [
        "Không tự xông hơi khi sốt cao, khó thở, người già yếu hoặc trẻ nhỏ.",
        "Không cạo gió mạnh, không dùng rượu thuốc, không trì hoãn đi khám nếu có dấu hiệu nặng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao hoặc sốt kéo dài",
        "Khó thở",
        "Đau ngực",
        "Co giật",
        "Lơ mơ hoặc yếu liệt tay chân"
      ],
      whenToSeeDoctor: [
        "Triệu chứng nặng lên hoặc không giảm sau vài ngày.",
        "Có sốt cao, khó thở, đau ngực, lơ mơ hoặc co giật.",
        "Người bệnh nền, thai kỳ, trẻ nhỏ hoặc người cao tuổi nên hỏi bác sĩ sớm."
      ],
      appWording: {
        short: "Đau đầu nhẹ do gió lạnh: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống đau đầu nhẹ do gió lạnh, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "folk_experience",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "weather_change_fatigue",
      category: "Cảm lạnh / thời tiết",
      categoryId: "cold_weather",
      title: "Mệt khi đổi thời tiết",
      situation: "Uể oải, nhạy với gió/lạnh/ẩm khi thời tiết thay đổi.",
      commonSigns: [
        "uể oải",
        "nhạy thời tiết",
        "ngủ không sâu"
      ],
      classicalView: "Theo cách nói cổ học, nhóm này thường được mô tả quanh yếu tố phong, hàn, táo hoặc sự thay đổi thời tiết làm cơ thể khó chịu.",
      safeCare: [
        "Nghỉ ngơi ở nơi ấm, thoáng và tránh gió lùa trực tiếp.",
        "Uống nước ấm từng ngụm, không dùng đồ quá lạnh.",
        "Giữ ấm cổ, ngực, bàn chân; theo dõi thân nhiệt và nhịp thở."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm, giữ ấm cổ/ngực/bàn chân; nếu có nhắc gừng hoặc mật ong thì chỉ xem là kinh nghiệm tham khảo và cần tránh ở nhóm nguy cơ."
      ],
      foodLifestyleNotes: [
        "Ưu tiên món ấm, mềm, dễ tiêu như cháo loãng hoặc súp nhẹ.",
        "Tránh rượu bia, đồ lạnh, đồ quá cay nóng khi người đang mệt."
      ],
      avoid: [
        "Không tự xông hơi khi sốt cao, khó thở, người già yếu hoặc trẻ nhỏ.",
        "Không cạo gió mạnh, không dùng rượu thuốc, không trì hoãn đi khám nếu có dấu hiệu nặng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao hoặc sốt kéo dài",
        "Khó thở",
        "Đau ngực",
        "Co giật",
        "Lơ mơ hoặc yếu liệt tay chân"
      ],
      whenToSeeDoctor: [
        "Triệu chứng nặng lên hoặc không giảm sau vài ngày.",
        "Có sốt cao, khó thở, đau ngực, lơ mơ hoặc co giật.",
        "Người bệnh nền, thai kỳ, trẻ nhỏ hoặc người cao tuổi nên hỏi bác sĩ sớm."
      ],
      appWording: {
        short: "Mệt khi đổi thời tiết: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống mệt do đổi thời tiết, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "folk_experience",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "bloating_after_meal",
      category: "Tiêu hóa",
      categoryId: "digestion",
      title: "Đầy bụng sau ăn",
      situation: "Bụng căng, ợ hơi hoặc khó chịu nhẹ sau bữa ăn, không đau dữ dội.",
      commonSigns: [
        "đầy bụng",
        "ợ hơi",
        "khó chịu sau ăn"
      ],
      classicalView: "Theo cổ học, nhóm này thường liên hệ đến tỳ vị, sự vận hóa sau ăn và trạng thái khí cơ vùng trung tiêu.",
      safeCare: [
        "Ăn chậm, nhai kỹ, tạm giảm lượng ăn ở bữa kế tiếp.",
        "Uống nước ấm từng ngụm nhỏ.",
        "Đi bộ chậm sau ăn khi không đau bụng dữ dội."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm hoặc món mềm dễ tiêu; nếu có nhắc gừng thì người dạ dày nặng, người dùng thuốc chống đông hoặc thai kỳ nên hỏi bác sĩ."
      ],
      foodLifestyleNotes: [
        "Chọn bữa nhẹ, mềm, ít dầu mỡ; tránh nằm ngay sau ăn.",
        "Quan sát thức ăn nào dễ làm khó chịu để điều chỉnh dần."
      ],
      avoid: [
        "Không tự dùng nhiều loại thuốc tiêu hóa cùng lúc.",
        "Không uống rượu thuốc, không xoa bóp mạnh vùng bụng khi đau.",
        "Không cố ăn thêm khi đang buồn nôn hoặc đầy tức."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau bụng dữ dội",
        "Nôn liên tục",
        "Nôn ra máu",
        "Đi cầu ra máu",
        "Dấu hiệu mất nước",
        "Sụt cân nhanh không rõ nguyên nhân"
      ],
      whenToSeeDoctor: [
        "Đau bụng tăng nhanh hoặc đau dữ dội.",
        "Nôn liên tục, đi cầu ra máu, phân đen hoặc mất nước.",
        "Tình trạng kéo dài, tái diễn nhiều lần hoặc đi kèm sụt cân."
      ],
      appWording: {
        short: "Đầy bụng sau ăn: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống đầy bụng sau ăn, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "indigestion_light",
      category: "Tiêu hóa",
      categoryId: "digestion",
      title: "Ăn không tiêu nhẹ",
      situation: "Cảm giác thức ăn lâu xuống, nặng bụng sau khi ăn nhiều hoặc ăn vội.",
      commonSigns: [
        "ăn không tiêu",
        "nặng bụng",
        "ngấy"
      ],
      classicalView: "Theo cổ học, nhóm này thường liên hệ đến tỳ vị, sự vận hóa sau ăn và trạng thái khí cơ vùng trung tiêu.",
      safeCare: [
        "Ăn chậm, nhai kỹ, tạm giảm lượng ăn ở bữa kế tiếp.",
        "Uống nước ấm từng ngụm nhỏ.",
        "Đi bộ chậm sau ăn khi không đau bụng dữ dội."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm hoặc món mềm dễ tiêu; nếu có nhắc gừng thì người dạ dày nặng, người dùng thuốc chống đông hoặc thai kỳ nên hỏi bác sĩ."
      ],
      foodLifestyleNotes: [
        "Chọn bữa nhẹ, mềm, ít dầu mỡ; tránh nằm ngay sau ăn.",
        "Quan sát thức ăn nào dễ làm khó chịu để điều chỉnh dần."
      ],
      avoid: [
        "Không tự dùng nhiều loại thuốc tiêu hóa cùng lúc.",
        "Không uống rượu thuốc, không xoa bóp mạnh vùng bụng khi đau.",
        "Không cố ăn thêm khi đang buồn nôn hoặc đầy tức."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau bụng dữ dội",
        "Nôn liên tục",
        "Nôn ra máu",
        "Đi cầu ra máu",
        "Dấu hiệu mất nước",
        "Sụt cân nhanh không rõ nguyên nhân"
      ],
      whenToSeeDoctor: [
        "Đau bụng tăng nhanh hoặc đau dữ dội.",
        "Nôn liên tục, đi cầu ra máu, phân đen hoặc mất nước.",
        "Tình trạng kéo dài, tái diễn nhiều lần hoặc đi kèm sụt cân."
      ],
      appWording: {
        short: "Ăn không tiêu nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống ăn không tiêu nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "mild_nausea_after_meal",
      category: "Tiêu hóa",
      categoryId: "digestion",
      title: "Buồn nôn nhẹ sau ăn",
      situation: "Hơi buồn nôn sau bữa ăn, chưa nôn liên tục và chưa mất nước.",
      commonSigns: [
        "buồn nôn",
        "khó chịu dạ dày",
        "ợ hơi"
      ],
      classicalView: "Theo cổ học, nhóm này thường liên hệ đến tỳ vị, sự vận hóa sau ăn và trạng thái khí cơ vùng trung tiêu.",
      safeCare: [
        "Ăn chậm, nhai kỹ, tạm giảm lượng ăn ở bữa kế tiếp.",
        "Uống nước ấm từng ngụm nhỏ.",
        "Đi bộ chậm sau ăn khi không đau bụng dữ dội."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm hoặc món mềm dễ tiêu; nếu có nhắc gừng thì người dạ dày nặng, người dùng thuốc chống đông hoặc thai kỳ nên hỏi bác sĩ."
      ],
      foodLifestyleNotes: [
        "Chọn bữa nhẹ, mềm, ít dầu mỡ; tránh nằm ngay sau ăn.",
        "Quan sát thức ăn nào dễ làm khó chịu để điều chỉnh dần."
      ],
      avoid: [
        "Không tự dùng nhiều loại thuốc tiêu hóa cùng lúc.",
        "Không uống rượu thuốc, không xoa bóp mạnh vùng bụng khi đau.",
        "Không cố ăn thêm khi đang buồn nôn hoặc đầy tức."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau bụng dữ dội",
        "Nôn liên tục",
        "Nôn ra máu",
        "Đi cầu ra máu",
        "Dấu hiệu mất nước",
        "Sụt cân nhanh không rõ nguyên nhân"
      ],
      whenToSeeDoctor: [
        "Đau bụng tăng nhanh hoặc đau dữ dội.",
        "Nôn liên tục, đi cầu ra máu, phân đen hoặc mất nước.",
        "Tình trạng kéo dài, tái diễn nhiều lần hoặc đi kèm sụt cân."
      ],
      appWording: {
        short: "Buồn nôn nhẹ sau ăn: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống buồn nôn nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "weak_digestion",
      category: "Tiêu hóa",
      categoryId: "digestion",
      title: "Tiêu hóa yếu",
      situation: "Dễ đầy bụng, ăn ít đã no, cần quan sát nhịp ăn ngủ và mức căng thẳng.",
      commonSigns: [
        "ăn ít đã no",
        "đầy bụng",
        "mệt sau ăn"
      ],
      classicalView: "Theo cổ học, nhóm này thường liên hệ đến tỳ vị, sự vận hóa sau ăn và trạng thái khí cơ vùng trung tiêu.",
      safeCare: [
        "Ăn chậm, nhai kỹ, tạm giảm lượng ăn ở bữa kế tiếp.",
        "Uống nước ấm từng ngụm nhỏ.",
        "Đi bộ chậm sau ăn khi không đau bụng dữ dội."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm hoặc món mềm dễ tiêu; nếu có nhắc gừng thì người dạ dày nặng, người dùng thuốc chống đông hoặc thai kỳ nên hỏi bác sĩ."
      ],
      foodLifestyleNotes: [
        "Chọn bữa nhẹ, mềm, ít dầu mỡ; tránh nằm ngay sau ăn.",
        "Quan sát thức ăn nào dễ làm khó chịu để điều chỉnh dần."
      ],
      avoid: [
        "Không tự dùng nhiều loại thuốc tiêu hóa cùng lúc.",
        "Không uống rượu thuốc, không xoa bóp mạnh vùng bụng khi đau.",
        "Không cố ăn thêm khi đang buồn nôn hoặc đầy tức."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau bụng dữ dội",
        "Nôn liên tục",
        "Nôn ra máu",
        "Đi cầu ra máu",
        "Dấu hiệu mất nước",
        "Sụt cân nhanh không rõ nguyên nhân"
      ],
      whenToSeeDoctor: [
        "Đau bụng tăng nhanh hoặc đau dữ dội.",
        "Nôn liên tục, đi cầu ra máu, phân đen hoặc mất nước.",
        "Tình trạng kéo dài, tái diễn nhiều lần hoặc đi kèm sụt cân."
      ],
      appWording: {
        short: "Tiêu hóa yếu: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống tiêu hóa yếu, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "mild_constipation",
      category: "Tiêu hóa",
      categoryId: "digestion",
      title: "Táo bón nhẹ",
      situation: "Đi ngoài khó hơn thường lệ, không đau dữ dội, không có máu.",
      commonSigns: [
        "đi ngoài khó",
        "phân khô",
        "ít đi ngoài"
      ],
      classicalView: "Theo cổ học, nhóm này thường liên hệ đến tỳ vị, sự vận hóa sau ăn và trạng thái khí cơ vùng trung tiêu.",
      safeCare: [
        "Ăn chậm, nhai kỹ, tạm giảm lượng ăn ở bữa kế tiếp.",
        "Uống nước ấm từng ngụm nhỏ.",
        "Đi bộ chậm sau ăn khi không đau bụng dữ dội."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm hoặc món mềm dễ tiêu; nếu có nhắc gừng thì người dạ dày nặng, người dùng thuốc chống đông hoặc thai kỳ nên hỏi bác sĩ."
      ],
      foodLifestyleNotes: [
        "Chọn bữa nhẹ, mềm, ít dầu mỡ; tránh nằm ngay sau ăn.",
        "Quan sát thức ăn nào dễ làm khó chịu để điều chỉnh dần."
      ],
      avoid: [
        "Không tự dùng nhiều loại thuốc tiêu hóa cùng lúc.",
        "Không uống rượu thuốc, không xoa bóp mạnh vùng bụng khi đau.",
        "Không cố ăn thêm khi đang buồn nôn hoặc đầy tức."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau bụng dữ dội",
        "Nôn liên tục",
        "Nôn ra máu",
        "Đi cầu ra máu",
        "Dấu hiệu mất nước",
        "Sụt cân nhanh không rõ nguyên nhân"
      ],
      whenToSeeDoctor: [
        "Đau bụng tăng nhanh hoặc đau dữ dội.",
        "Nôn liên tục, đi cầu ra máu, phân đen hoặc mất nước.",
        "Tình trạng kéo dài, tái diễn nhiều lần hoặc đi kèm sụt cân."
      ],
      appWording: {
        short: "Táo bón nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống táo bón nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "loose_stool_light",
      category: "Tiêu hóa",
      categoryId: "digestion",
      title: "Đi ngoài lỏng nhẹ",
      situation: "Phân lỏng vài lần, chưa có sốt cao, máu, mất nước hoặc đau dữ dội.",
      commonSigns: [
        "phân lỏng",
        "bụng sôi",
        "mệt nhẹ"
      ],
      classicalView: "Theo cổ học, nhóm này thường liên hệ đến tỳ vị, sự vận hóa sau ăn và trạng thái khí cơ vùng trung tiêu.",
      safeCare: [
        "Ăn chậm, nhai kỹ, tạm giảm lượng ăn ở bữa kế tiếp.",
        "Uống nước ấm từng ngụm nhỏ.",
        "Đi bộ chậm sau ăn khi không đau bụng dữ dội."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm hoặc món mềm dễ tiêu; nếu có nhắc gừng thì người dạ dày nặng, người dùng thuốc chống đông hoặc thai kỳ nên hỏi bác sĩ."
      ],
      foodLifestyleNotes: [
        "Chọn bữa nhẹ, mềm, ít dầu mỡ; tránh nằm ngay sau ăn.",
        "Quan sát thức ăn nào dễ làm khó chịu để điều chỉnh dần."
      ],
      avoid: [
        "Không tự dùng nhiều loại thuốc tiêu hóa cùng lúc.",
        "Không uống rượu thuốc, không xoa bóp mạnh vùng bụng khi đau.",
        "Không cố ăn thêm khi đang buồn nôn hoặc đầy tức."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau bụng dữ dội",
        "Nôn liên tục",
        "Nôn ra máu",
        "Đi cầu ra máu",
        "Dấu hiệu mất nước",
        "Sụt cân nhanh không rõ nguyên nhân"
      ],
      whenToSeeDoctor: [
        "Đau bụng tăng nhanh hoặc đau dữ dội.",
        "Nôn liên tục, đi cầu ra máu, phân đen hoặc mất nước.",
        "Tình trạng kéo dài, tái diễn nhiều lần hoặc đi kèm sụt cân."
      ],
      appWording: {
        short: "Đi ngoài lỏng nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống đi ngoài lỏng nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "bitter_mouth_oily",
      category: "Tiêu hóa",
      categoryId: "digestion",
      title: "Miệng đắng / ngấy dầu",
      situation: "Miệng đắng, ngấy dầu sau ăn nhiều đồ chiên, nhiều gia vị hoặc ngủ kém.",
      commonSigns: [
        "miệng đắng",
        "ngấy dầu",
        "ăn kém ngon"
      ],
      classicalView: "Theo cổ học, nhóm này thường liên hệ đến tỳ vị, sự vận hóa sau ăn và trạng thái khí cơ vùng trung tiêu.",
      safeCare: [
        "Ăn chậm, nhai kỹ, tạm giảm lượng ăn ở bữa kế tiếp.",
        "Uống nước ấm từng ngụm nhỏ.",
        "Đi bộ chậm sau ăn khi không đau bụng dữ dội."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm hoặc món mềm dễ tiêu; nếu có nhắc gừng thì người dạ dày nặng, người dùng thuốc chống đông hoặc thai kỳ nên hỏi bác sĩ."
      ],
      foodLifestyleNotes: [
        "Chọn bữa nhẹ, mềm, ít dầu mỡ; tránh nằm ngay sau ăn.",
        "Quan sát thức ăn nào dễ làm khó chịu để điều chỉnh dần."
      ],
      avoid: [
        "Không tự dùng nhiều loại thuốc tiêu hóa cùng lúc.",
        "Không uống rượu thuốc, không xoa bóp mạnh vùng bụng khi đau.",
        "Không cố ăn thêm khi đang buồn nôn hoặc đầy tức."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau bụng dữ dội",
        "Nôn liên tục",
        "Nôn ra máu",
        "Đi cầu ra máu",
        "Dấu hiệu mất nước",
        "Sụt cân nhanh không rõ nguyên nhân"
      ],
      whenToSeeDoctor: [
        "Đau bụng tăng nhanh hoặc đau dữ dội.",
        "Nôn liên tục, đi cầu ra máu, phân đen hoặc mất nước.",
        "Tình trạng kéo dài, tái diễn nhiều lần hoặc đi kèm sụt cân."
      ],
      appWording: {
        short: "Miệng đắng / ngấy dầu: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống miệng đắng nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "post_fatty_meal_heavy",
      category: "Tiêu hóa",
      categoryId: "digestion",
      title: "Nặng bụng sau bữa nhiều dầu",
      situation: "Bụng nặng, ngán, muốn nằm sau bữa nhiều dầu mỡ.",
      commonSigns: [
        "nặng bụng",
        "ngán",
        "buồn ngủ sau ăn"
      ],
      classicalView: "Theo cổ học, nhóm này thường liên hệ đến tỳ vị, sự vận hóa sau ăn và trạng thái khí cơ vùng trung tiêu.",
      safeCare: [
        "Ăn chậm, nhai kỹ, tạm giảm lượng ăn ở bữa kế tiếp.",
        "Uống nước ấm từng ngụm nhỏ.",
        "Đi bộ chậm sau ăn khi không đau bụng dữ dội."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm hoặc món mềm dễ tiêu; nếu có nhắc gừng thì người dạ dày nặng, người dùng thuốc chống đông hoặc thai kỳ nên hỏi bác sĩ."
      ],
      foodLifestyleNotes: [
        "Chọn bữa nhẹ, mềm, ít dầu mỡ; tránh nằm ngay sau ăn.",
        "Quan sát thức ăn nào dễ làm khó chịu để điều chỉnh dần."
      ],
      avoid: [
        "Không tự dùng nhiều loại thuốc tiêu hóa cùng lúc.",
        "Không uống rượu thuốc, không xoa bóp mạnh vùng bụng khi đau.",
        "Không cố ăn thêm khi đang buồn nôn hoặc đầy tức."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau bụng dữ dội",
        "Nôn liên tục",
        "Nôn ra máu",
        "Đi cầu ra máu",
        "Dấu hiệu mất nước",
        "Sụt cân nhanh không rõ nguyên nhân"
      ],
      whenToSeeDoctor: [
        "Đau bụng tăng nhanh hoặc đau dữ dội.",
        "Nôn liên tục, đi cầu ra máu, phân đen hoặc mất nước.",
        "Tình trạng kéo dài, tái diễn nhiều lần hoặc đi kèm sụt cân."
      ],
      appWording: {
        short: "Nặng bụng sau bữa nhiều dầu: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống nặng bụng sau bữa dầu mỡ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "mild_burp",
      category: "Tiêu hóa",
      categoryId: "digestion",
      title: "Ợ hơi nhẹ",
      situation: "Ợ hơi lặp lại sau ăn nhanh, uống nước có gas hoặc căng thẳng.",
      commonSigns: [
        "ợ hơi",
        "đầy tức nhẹ",
        "ăn nhanh"
      ],
      classicalView: "Theo cổ học, nhóm này thường liên hệ đến tỳ vị, sự vận hóa sau ăn và trạng thái khí cơ vùng trung tiêu.",
      safeCare: [
        "Ăn chậm, nhai kỹ, tạm giảm lượng ăn ở bữa kế tiếp.",
        "Uống nước ấm từng ngụm nhỏ.",
        "Đi bộ chậm sau ăn khi không đau bụng dữ dội."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm hoặc món mềm dễ tiêu; nếu có nhắc gừng thì người dạ dày nặng, người dùng thuốc chống đông hoặc thai kỳ nên hỏi bác sĩ."
      ],
      foodLifestyleNotes: [
        "Chọn bữa nhẹ, mềm, ít dầu mỡ; tránh nằm ngay sau ăn.",
        "Quan sát thức ăn nào dễ làm khó chịu để điều chỉnh dần."
      ],
      avoid: [
        "Không tự dùng nhiều loại thuốc tiêu hóa cùng lúc.",
        "Không uống rượu thuốc, không xoa bóp mạnh vùng bụng khi đau.",
        "Không cố ăn thêm khi đang buồn nôn hoặc đầy tức."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau bụng dữ dội",
        "Nôn liên tục",
        "Nôn ra máu",
        "Đi cầu ra máu",
        "Dấu hiệu mất nước",
        "Sụt cân nhanh không rõ nguyên nhân"
      ],
      whenToSeeDoctor: [
        "Đau bụng tăng nhanh hoặc đau dữ dội.",
        "Nôn liên tục, đi cầu ra máu, phân đen hoặc mất nước.",
        "Tình trạng kéo dài, tái diễn nhiều lần hoặc đi kèm sụt cân."
      ],
      appWording: {
        short: "Ợ hơi nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống ợ hơi nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "falling_asleep_hard",
      category: "Ngủ nghỉ / thần chí",
      categoryId: "sleep_mind",
      title: "Khó vào giấc nhẹ",
      situation: "Nằm lâu mới ngủ, thường liên quan màn hình, lo nghĩ hoặc giờ ngủ thất thường.",
      commonSigns: [
        "khó vào giấc",
        "suy nghĩ nhiều",
        "thức khuya"
      ],
      classicalView: "Theo cổ học, giấc ngủ và thần chí thường được nhìn cùng khí huyết, tâm thần, can khí và nhịp sinh hoạt.",
      safeCare: [
        "Giảm ánh sáng mạnh và màn hình trước giờ ngủ.",
        "Thở chậm, thư giãn vai cổ, ghi lại điều đang lo để tạm gác.",
        "Giữ giờ ngủ - thức tương đối đều trong vài ngày."
      ],
      folkNotes: [
        "Một số gia đình dùng thói quen tắt màn hình sớm, ngâm chân ấm vừa phải hoặc nghe âm thanh nhẹ; không dùng rượu hay thảo dược an thần tùy tiện."
      ],
      foodLifestyleNotes: [
        "Tránh bữa tối quá no, cà phê hoặc chất kích thích về chiều tối.",
        "Dùng bữa nhẹ, ấm và dễ tiêu nếu bụng trống làm khó ngủ."
      ],
      avoid: [
        "Không tự dùng rượu để ngủ.",
        "Không lạm dụng thực phẩm/thảo dược an thần khi chưa hỏi chuyên gia.",
        "Không xem app như công cụ xử lý khủng hoảng tinh thần."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Ý nghĩ tự hại",
        "Hoảng loạn dữ dội",
        "Đau đầu dữ dội đột ngột",
        "Nói khó hoặc yếu liệt",
        "Ngất"
      ],
      whenToSeeDoctor: [
        "Mất ngủ kéo dài, ảnh hưởng mạnh đến sinh hoạt.",
        "Có ý nghĩ tự hại, hoảng loạn, lơ mơ hoặc dấu thần kinh bất thường.",
        "Đang dùng thuốc tâm thần hoặc có bệnh nền nên hỏi bác sĩ trước mọi mẹo."
      ],
      appWording: {
        short: "Khó vào giấc nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống khó ngủ nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "waking_at_night",
      category: "Ngủ nghỉ / thần chí",
      categoryId: "sleep_mind",
      title: "Hay tỉnh giấc",
      situation: "Dễ tỉnh giữa đêm rồi khó ngủ lại, chưa có dấu hiệu khủng hoảng tinh thần.",
      commonSigns: [
        "tỉnh giữa đêm",
        "ngủ không sâu",
        "mệt sáng"
      ],
      classicalView: "Theo cổ học, giấc ngủ và thần chí thường được nhìn cùng khí huyết, tâm thần, can khí và nhịp sinh hoạt.",
      safeCare: [
        "Giảm ánh sáng mạnh và màn hình trước giờ ngủ.",
        "Thở chậm, thư giãn vai cổ, ghi lại điều đang lo để tạm gác.",
        "Giữ giờ ngủ - thức tương đối đều trong vài ngày."
      ],
      folkNotes: [
        "Một số gia đình dùng thói quen tắt màn hình sớm, ngâm chân ấm vừa phải hoặc nghe âm thanh nhẹ; không dùng rượu hay thảo dược an thần tùy tiện."
      ],
      foodLifestyleNotes: [
        "Tránh bữa tối quá no, cà phê hoặc chất kích thích về chiều tối.",
        "Dùng bữa nhẹ, ấm và dễ tiêu nếu bụng trống làm khó ngủ."
      ],
      avoid: [
        "Không tự dùng rượu để ngủ.",
        "Không lạm dụng thực phẩm/thảo dược an thần khi chưa hỏi chuyên gia.",
        "Không xem app như công cụ xử lý khủng hoảng tinh thần."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Ý nghĩ tự hại",
        "Hoảng loạn dữ dội",
        "Đau đầu dữ dội đột ngột",
        "Nói khó hoặc yếu liệt",
        "Ngất"
      ],
      whenToSeeDoctor: [
        "Mất ngủ kéo dài, ảnh hưởng mạnh đến sinh hoạt.",
        "Có ý nghĩ tự hại, hoảng loạn, lơ mơ hoặc dấu thần kinh bất thường.",
        "Đang dùng thuốc tâm thần hoặc có bệnh nền nên hỏi bác sĩ trước mọi mẹo."
      ],
      appWording: {
        short: "Hay tỉnh giấc: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống hay tỉnh giấc, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "late_night_fatigue",
      category: "Ngủ nghỉ / thần chí",
      categoryId: "sleep_mind",
      title: "Mệt sau thức khuya",
      situation: "Uể oải, nặng đầu, thiếu tỉnh táo sau vài đêm ngủ muộn.",
      commonSigns: [
        "uể oải",
        "nặng đầu",
        "buồn ngủ ban ngày"
      ],
      classicalView: "Theo cổ học, giấc ngủ và thần chí thường được nhìn cùng khí huyết, tâm thần, can khí và nhịp sinh hoạt.",
      safeCare: [
        "Giảm ánh sáng mạnh và màn hình trước giờ ngủ.",
        "Thở chậm, thư giãn vai cổ, ghi lại điều đang lo để tạm gác.",
        "Giữ giờ ngủ - thức tương đối đều trong vài ngày."
      ],
      folkNotes: [
        "Một số gia đình dùng thói quen tắt màn hình sớm, ngâm chân ấm vừa phải hoặc nghe âm thanh nhẹ; không dùng rượu hay thảo dược an thần tùy tiện."
      ],
      foodLifestyleNotes: [
        "Tránh bữa tối quá no, cà phê hoặc chất kích thích về chiều tối.",
        "Dùng bữa nhẹ, ấm và dễ tiêu nếu bụng trống làm khó ngủ."
      ],
      avoid: [
        "Không tự dùng rượu để ngủ.",
        "Không lạm dụng thực phẩm/thảo dược an thần khi chưa hỏi chuyên gia.",
        "Không xem app như công cụ xử lý khủng hoảng tinh thần."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Ý nghĩ tự hại",
        "Hoảng loạn dữ dội",
        "Đau đầu dữ dội đột ngột",
        "Nói khó hoặc yếu liệt",
        "Ngất"
      ],
      whenToSeeDoctor: [
        "Mất ngủ kéo dài, ảnh hưởng mạnh đến sinh hoạt.",
        "Có ý nghĩ tự hại, hoảng loạn, lơ mơ hoặc dấu thần kinh bất thường.",
        "Đang dùng thuốc tâm thần hoặc có bệnh nền nên hỏi bác sĩ trước mọi mẹo."
      ],
      appWording: {
        short: "Mệt sau thức khuya: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống mệt sau thức khuya, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "mild_stress",
      category: "Ngủ nghỉ / thần chí",
      categoryId: "sleep_mind",
      title: "Căng thẳng nhẹ",
      situation: "Cảm giác áp lực, hồi hộp nhẹ, chưa có hoảng loạn dữ dội.",
      commonSigns: [
        "căng thẳng",
        "hồi hộp nhẹ",
        "khó thư giãn"
      ],
      classicalView: "Theo cổ học, giấc ngủ và thần chí thường được nhìn cùng khí huyết, tâm thần, can khí và nhịp sinh hoạt.",
      safeCare: [
        "Giảm ánh sáng mạnh và màn hình trước giờ ngủ.",
        "Thở chậm, thư giãn vai cổ, ghi lại điều đang lo để tạm gác.",
        "Giữ giờ ngủ - thức tương đối đều trong vài ngày."
      ],
      folkNotes: [
        "Một số gia đình dùng thói quen tắt màn hình sớm, ngâm chân ấm vừa phải hoặc nghe âm thanh nhẹ; không dùng rượu hay thảo dược an thần tùy tiện."
      ],
      foodLifestyleNotes: [
        "Tránh bữa tối quá no, cà phê hoặc chất kích thích về chiều tối.",
        "Dùng bữa nhẹ, ấm và dễ tiêu nếu bụng trống làm khó ngủ."
      ],
      avoid: [
        "Không tự dùng rượu để ngủ.",
        "Không lạm dụng thực phẩm/thảo dược an thần khi chưa hỏi chuyên gia.",
        "Không xem app như công cụ xử lý khủng hoảng tinh thần."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Ý nghĩ tự hại",
        "Hoảng loạn dữ dội",
        "Đau đầu dữ dội đột ngột",
        "Nói khó hoặc yếu liệt",
        "Ngất"
      ],
      whenToSeeDoctor: [
        "Mất ngủ kéo dài, ảnh hưởng mạnh đến sinh hoạt.",
        "Có ý nghĩ tự hại, hoảng loạn, lơ mơ hoặc dấu thần kinh bất thường.",
        "Đang dùng thuốc tâm thần hoặc có bệnh nền nên hỏi bác sĩ trước mọi mẹo."
      ],
      appWording: {
        short: "Căng thẳng nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống căng thẳng nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "overthinking",
      category: "Ngủ nghỉ / thần chí",
      categoryId: "sleep_mind",
      title: "Lo nghĩ nhiều",
      situation: "Đầu óc xoay quanh nhiều việc, ảnh hưởng nhẹ tới ngủ nghỉ.",
      commonSigns: [
        "lo nghĩ",
        "khó tập trung",
        "thở nông"
      ],
      classicalView: "Theo cổ học, giấc ngủ và thần chí thường được nhìn cùng khí huyết, tâm thần, can khí và nhịp sinh hoạt.",
      safeCare: [
        "Giảm ánh sáng mạnh và màn hình trước giờ ngủ.",
        "Thở chậm, thư giãn vai cổ, ghi lại điều đang lo để tạm gác.",
        "Giữ giờ ngủ - thức tương đối đều trong vài ngày."
      ],
      folkNotes: [
        "Một số gia đình dùng thói quen tắt màn hình sớm, ngâm chân ấm vừa phải hoặc nghe âm thanh nhẹ; không dùng rượu hay thảo dược an thần tùy tiện."
      ],
      foodLifestyleNotes: [
        "Tránh bữa tối quá no, cà phê hoặc chất kích thích về chiều tối.",
        "Dùng bữa nhẹ, ấm và dễ tiêu nếu bụng trống làm khó ngủ."
      ],
      avoid: [
        "Không tự dùng rượu để ngủ.",
        "Không lạm dụng thực phẩm/thảo dược an thần khi chưa hỏi chuyên gia.",
        "Không xem app như công cụ xử lý khủng hoảng tinh thần."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Ý nghĩ tự hại",
        "Hoảng loạn dữ dội",
        "Đau đầu dữ dội đột ngột",
        "Nói khó hoặc yếu liệt",
        "Ngất"
      ],
      whenToSeeDoctor: [
        "Mất ngủ kéo dài, ảnh hưởng mạnh đến sinh hoạt.",
        "Có ý nghĩ tự hại, hoảng loạn, lơ mơ hoặc dấu thần kinh bất thường.",
        "Đang dùng thuốc tâm thần hoặc có bệnh nền nên hỏi bác sĩ trước mọi mẹo."
      ],
      appWording: {
        short: "Lo nghĩ nhiều: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống lo nghĩ nhiều, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "mild_restlessness",
      category: "Ngủ nghỉ / thần chí",
      categoryId: "sleep_mind",
      title: "Bồn chồn nhẹ",
      situation: "Khó ngồi yên, cảm giác không yên trong người nhưng vẫn kiểm soát được.",
      commonSigns: [
        "bồn chồn",
        "khó ngồi yên",
        "căng trong người"
      ],
      classicalView: "Theo cổ học, giấc ngủ và thần chí thường được nhìn cùng khí huyết, tâm thần, can khí và nhịp sinh hoạt.",
      safeCare: [
        "Giảm ánh sáng mạnh và màn hình trước giờ ngủ.",
        "Thở chậm, thư giãn vai cổ, ghi lại điều đang lo để tạm gác.",
        "Giữ giờ ngủ - thức tương đối đều trong vài ngày."
      ],
      folkNotes: [
        "Một số gia đình dùng thói quen tắt màn hình sớm, ngâm chân ấm vừa phải hoặc nghe âm thanh nhẹ; không dùng rượu hay thảo dược an thần tùy tiện."
      ],
      foodLifestyleNotes: [
        "Tránh bữa tối quá no, cà phê hoặc chất kích thích về chiều tối.",
        "Dùng bữa nhẹ, ấm và dễ tiêu nếu bụng trống làm khó ngủ."
      ],
      avoid: [
        "Không tự dùng rượu để ngủ.",
        "Không lạm dụng thực phẩm/thảo dược an thần khi chưa hỏi chuyên gia.",
        "Không xem app như công cụ xử lý khủng hoảng tinh thần."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Ý nghĩ tự hại",
        "Hoảng loạn dữ dội",
        "Đau đầu dữ dội đột ngột",
        "Nói khó hoặc yếu liệt",
        "Ngất"
      ],
      whenToSeeDoctor: [
        "Mất ngủ kéo dài, ảnh hưởng mạnh đến sinh hoạt.",
        "Có ý nghĩ tự hại, hoảng loạn, lơ mơ hoặc dấu thần kinh bất thường.",
        "Đang dùng thuốc tâm thần hoặc có bệnh nền nên hỏi bác sĩ trước mọi mẹo."
      ],
      appWording: {
        short: "Bồn chồn nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống bồn chồn nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "screen_overload",
      category: "Ngủ nghỉ / thần chí",
      categoryId: "sleep_mind",
      title: "Quá tải màn hình buổi tối",
      situation: "Mắt mỏi, đầu căng, khó ngủ sau khi dùng điện thoại/máy tính lâu.",
      commonSigns: [
        "mỏi mắt",
        "khó ngủ",
        "đầu căng"
      ],
      classicalView: "Theo cổ học, giấc ngủ và thần chí thường được nhìn cùng khí huyết, tâm thần, can khí và nhịp sinh hoạt.",
      safeCare: [
        "Giảm ánh sáng mạnh và màn hình trước giờ ngủ.",
        "Thở chậm, thư giãn vai cổ, ghi lại điều đang lo để tạm gác.",
        "Giữ giờ ngủ - thức tương đối đều trong vài ngày."
      ],
      folkNotes: [
        "Một số gia đình dùng thói quen tắt màn hình sớm, ngâm chân ấm vừa phải hoặc nghe âm thanh nhẹ; không dùng rượu hay thảo dược an thần tùy tiện."
      ],
      foodLifestyleNotes: [
        "Tránh bữa tối quá no, cà phê hoặc chất kích thích về chiều tối.",
        "Dùng bữa nhẹ, ấm và dễ tiêu nếu bụng trống làm khó ngủ."
      ],
      avoid: [
        "Không tự dùng rượu để ngủ.",
        "Không lạm dụng thực phẩm/thảo dược an thần khi chưa hỏi chuyên gia.",
        "Không xem app như công cụ xử lý khủng hoảng tinh thần."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Ý nghĩ tự hại",
        "Hoảng loạn dữ dội",
        "Đau đầu dữ dội đột ngột",
        "Nói khó hoặc yếu liệt",
        "Ngất"
      ],
      whenToSeeDoctor: [
        "Mất ngủ kéo dài, ảnh hưởng mạnh đến sinh hoạt.",
        "Có ý nghĩ tự hại, hoảng loạn, lơ mơ hoặc dấu thần kinh bất thường.",
        "Đang dùng thuốc tâm thần hoặc có bệnh nền nên hỏi bác sĩ trước mọi mẹo."
      ],
      appWording: {
        short: "Quá tải màn hình buổi tối: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống quá tải màn hình, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "morning_tired_after_sleep",
      category: "Ngủ nghỉ / thần chí",
      categoryId: "sleep_mind",
      title: "Ngủ dậy vẫn mệt",
      situation: "Ngủ đủ giờ nhưng dậy còn mệt, cần quan sát chất lượng ngủ và sinh hoạt ban ngày.",
      commonSigns: [
        "mệt sáng",
        "ngủ không sâu",
        "thiếu sức"
      ],
      classicalView: "Theo cổ học, giấc ngủ và thần chí thường được nhìn cùng khí huyết, tâm thần, can khí và nhịp sinh hoạt.",
      safeCare: [
        "Giảm ánh sáng mạnh và màn hình trước giờ ngủ.",
        "Thở chậm, thư giãn vai cổ, ghi lại điều đang lo để tạm gác.",
        "Giữ giờ ngủ - thức tương đối đều trong vài ngày."
      ],
      folkNotes: [
        "Một số gia đình dùng thói quen tắt màn hình sớm, ngâm chân ấm vừa phải hoặc nghe âm thanh nhẹ; không dùng rượu hay thảo dược an thần tùy tiện."
      ],
      foodLifestyleNotes: [
        "Tránh bữa tối quá no, cà phê hoặc chất kích thích về chiều tối.",
        "Dùng bữa nhẹ, ấm và dễ tiêu nếu bụng trống làm khó ngủ."
      ],
      avoid: [
        "Không tự dùng rượu để ngủ.",
        "Không lạm dụng thực phẩm/thảo dược an thần khi chưa hỏi chuyên gia.",
        "Không xem app như công cụ xử lý khủng hoảng tinh thần."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Ý nghĩ tự hại",
        "Hoảng loạn dữ dội",
        "Đau đầu dữ dội đột ngột",
        "Nói khó hoặc yếu liệt",
        "Ngất"
      ],
      whenToSeeDoctor: [
        "Mất ngủ kéo dài, ảnh hưởng mạnh đến sinh hoạt.",
        "Có ý nghĩ tự hại, hoảng loạn, lơ mơ hoặc dấu thần kinh bất thường.",
        "Đang dùng thuốc tâm thần hoặc có bệnh nền nên hỏi bác sĩ trước mọi mẹo."
      ],
      appWording: {
        short: "Ngủ dậy vẫn mệt: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống ngủ dậy mệt, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "neck_shoulder_sitting",
      category: "Cơ xương / sinh hoạt",
      categoryId: "body_movement",
      title: "Mỏi cổ vai gáy do ngồi lâu",
      situation: "Cổ vai gáy căng mỏi sau ngồi máy tính hoặc cúi điện thoại lâu.",
      commonSigns: [
        "căng vai",
        "mỏi cổ",
        "ngồi lâu"
      ],
      classicalView: "Theo cổ học, đau mỏi nhẹ do sinh hoạt có thể liên hệ đến khí huyết lưu thông kém, tư thế và lao lực.",
      safeCare: [
        "Nghỉ ngắn, thay đổi tư thế, vận động nhẹ trong biên độ không đau.",
        "Chườm ấm nhẹ hoặc tắm ấm nếu cơ thể không sốt và không có chấn thương cấp.",
        "Giãn cơ nhẹ, chậm, không bẻ vặn mạnh."
      ],
      folkNotes: [
        "Một số gia đình dùng chườm ấm nhẹ hoặc xoa bóp rất nhẹ quanh vùng mỏi; không bấm nắn mạnh, không tác động lên vùng sưng đau/chấn thương."
      ],
      foodLifestyleNotes: [
        "Uống đủ nước, ngủ đủ, không làm việc liên tục một tư thế quá lâu.",
        "Xen kẽ đứng dậy, đi lại nhẹ và thả lỏng vai gáy."
      ],
      avoid: [
        "Không bấm nắn mạnh vùng đau, không tự nắn chỉnh cột sống.",
        "Không chườm nóng lên vùng sưng đỏ do chấn thương mới.",
        "Không cố tập khi đau tăng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau dữ dội sau chấn thương",
        "Tê yếu lan xuống tay chân",
        "Mất kiểm soát đại tiểu tiện",
        "Đau ngực",
        "Nói khó hoặc méo miệng"
      ],
      whenToSeeDoctor: [
        "Đau sau té ngã/chấn thương hoặc đau tăng nhanh.",
        "Có tê yếu, lan đau, mất cảm giác hoặc rối loạn đại tiểu tiện.",
        "Đau kéo dài nhiều ngày không giảm."
      ],
      appWording: {
        short: "Mỏi cổ vai gáy do ngồi lâu: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống mỏi cổ vai gáy, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "mild_low_back_sitting",
      category: "Cơ xương / sinh hoạt",
      categoryId: "body_movement",
      title: "Mỏi lưng nhẹ do tư thế",
      situation: "Lưng mỏi âm ỉ sau đứng/ngồi lâu, không tê yếu chân.",
      commonSigns: [
        "mỏi lưng",
        "cứng lưng",
        "ngồi lâu"
      ],
      classicalView: "Theo cổ học, đau mỏi nhẹ do sinh hoạt có thể liên hệ đến khí huyết lưu thông kém, tư thế và lao lực.",
      safeCare: [
        "Nghỉ ngắn, thay đổi tư thế, vận động nhẹ trong biên độ không đau.",
        "Chườm ấm nhẹ hoặc tắm ấm nếu cơ thể không sốt và không có chấn thương cấp.",
        "Giãn cơ nhẹ, chậm, không bẻ vặn mạnh."
      ],
      folkNotes: [
        "Một số gia đình dùng chườm ấm nhẹ hoặc xoa bóp rất nhẹ quanh vùng mỏi; không bấm nắn mạnh, không tác động lên vùng sưng đau/chấn thương."
      ],
      foodLifestyleNotes: [
        "Uống đủ nước, ngủ đủ, không làm việc liên tục một tư thế quá lâu.",
        "Xen kẽ đứng dậy, đi lại nhẹ và thả lỏng vai gáy."
      ],
      avoid: [
        "Không bấm nắn mạnh vùng đau, không tự nắn chỉnh cột sống.",
        "Không chườm nóng lên vùng sưng đỏ do chấn thương mới.",
        "Không cố tập khi đau tăng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau dữ dội sau chấn thương",
        "Tê yếu lan xuống tay chân",
        "Mất kiểm soát đại tiểu tiện",
        "Đau ngực",
        "Nói khó hoặc méo miệng"
      ],
      whenToSeeDoctor: [
        "Đau sau té ngã/chấn thương hoặc đau tăng nhanh.",
        "Có tê yếu, lan đau, mất cảm giác hoặc rối loạn đại tiểu tiện.",
        "Đau kéo dài nhiều ngày không giảm."
      ],
      appWording: {
        short: "Mỏi lưng nhẹ do tư thế: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống mỏi lưng nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "eye_strain_screen",
      category: "Cơ xương / sinh hoạt",
      categoryId: "body_movement",
      title: "Mỏi mắt do màn hình",
      situation: "Mắt khô, mỏi, nhức nhẹ sau nhìn màn hình lâu.",
      commonSigns: [
        "mỏi mắt",
        "khô mắt",
        "nhức quanh mắt"
      ],
      classicalView: "Theo cổ học, đau mỏi nhẹ do sinh hoạt có thể liên hệ đến khí huyết lưu thông kém, tư thế và lao lực.",
      safeCare: [
        "Nghỉ ngắn, thay đổi tư thế, vận động nhẹ trong biên độ không đau.",
        "Chườm ấm nhẹ hoặc tắm ấm nếu cơ thể không sốt và không có chấn thương cấp.",
        "Giãn cơ nhẹ, chậm, không bẻ vặn mạnh."
      ],
      folkNotes: [
        "Một số gia đình dùng chườm ấm nhẹ hoặc xoa bóp rất nhẹ quanh vùng mỏi; không bấm nắn mạnh, không tác động lên vùng sưng đau/chấn thương."
      ],
      foodLifestyleNotes: [
        "Uống đủ nước, ngủ đủ, không làm việc liên tục một tư thế quá lâu.",
        "Xen kẽ đứng dậy, đi lại nhẹ và thả lỏng vai gáy."
      ],
      avoid: [
        "Không bấm nắn mạnh vùng đau, không tự nắn chỉnh cột sống.",
        "Không chườm nóng lên vùng sưng đỏ do chấn thương mới.",
        "Không cố tập khi đau tăng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau dữ dội sau chấn thương",
        "Tê yếu lan xuống tay chân",
        "Mất kiểm soát đại tiểu tiện",
        "Đau ngực",
        "Nói khó hoặc méo miệng"
      ],
      whenToSeeDoctor: [
        "Đau sau té ngã/chấn thương hoặc đau tăng nhanh.",
        "Có tê yếu, lan đau, mất cảm giác hoặc rối loạn đại tiểu tiện.",
        "Đau kéo dài nhiều ngày không giảm."
      ],
      appWording: {
        short: "Mỏi mắt do màn hình: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống mỏi mắt, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "heavy_head_lack_sleep",
      category: "Cơ xương / sinh hoạt",
      categoryId: "body_movement",
      title: "Nặng đầu do thiếu ngủ",
      situation: "Đầu nặng, uể oải, giảm tập trung sau thiếu ngủ.",
      commonSigns: [
        "nặng đầu",
        "thiếu tỉnh táo",
        "mệt"
      ],
      classicalView: "Theo cổ học, đau mỏi nhẹ do sinh hoạt có thể liên hệ đến khí huyết lưu thông kém, tư thế và lao lực.",
      safeCare: [
        "Nghỉ ngắn, thay đổi tư thế, vận động nhẹ trong biên độ không đau.",
        "Chườm ấm nhẹ hoặc tắm ấm nếu cơ thể không sốt và không có chấn thương cấp.",
        "Giãn cơ nhẹ, chậm, không bẻ vặn mạnh."
      ],
      folkNotes: [
        "Một số gia đình dùng chườm ấm nhẹ hoặc xoa bóp rất nhẹ quanh vùng mỏi; không bấm nắn mạnh, không tác động lên vùng sưng đau/chấn thương."
      ],
      foodLifestyleNotes: [
        "Uống đủ nước, ngủ đủ, không làm việc liên tục một tư thế quá lâu.",
        "Xen kẽ đứng dậy, đi lại nhẹ và thả lỏng vai gáy."
      ],
      avoid: [
        "Không bấm nắn mạnh vùng đau, không tự nắn chỉnh cột sống.",
        "Không chườm nóng lên vùng sưng đỏ do chấn thương mới.",
        "Không cố tập khi đau tăng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau dữ dội sau chấn thương",
        "Tê yếu lan xuống tay chân",
        "Mất kiểm soát đại tiểu tiện",
        "Đau ngực",
        "Nói khó hoặc méo miệng"
      ],
      whenToSeeDoctor: [
        "Đau sau té ngã/chấn thương hoặc đau tăng nhanh.",
        "Có tê yếu, lan đau, mất cảm giác hoặc rối loạn đại tiểu tiện.",
        "Đau kéo dài nhiều ngày không giảm."
      ],
      appWording: {
        short: "Nặng đầu do thiếu ngủ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống nặng đầu do thiếu ngủ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "mild_numb_posture",
      category: "Cơ xương / sinh hoạt",
      categoryId: "body_movement",
      title: "Tê mỏi tay chân do tư thế",
      situation: "Tê mỏi nhẹ sau ngồi đè chân, gác tay hoặc giữ một tư thế quá lâu.",
      commonSigns: [
        "tê nhẹ",
        "mỏi chi",
        "ngồi sai tư thế"
      ],
      classicalView: "Theo cổ học, đau mỏi nhẹ do sinh hoạt có thể liên hệ đến khí huyết lưu thông kém, tư thế và lao lực.",
      safeCare: [
        "Nghỉ ngắn, thay đổi tư thế, vận động nhẹ trong biên độ không đau.",
        "Chườm ấm nhẹ hoặc tắm ấm nếu cơ thể không sốt và không có chấn thương cấp.",
        "Giãn cơ nhẹ, chậm, không bẻ vặn mạnh."
      ],
      folkNotes: [
        "Một số gia đình dùng chườm ấm nhẹ hoặc xoa bóp rất nhẹ quanh vùng mỏi; không bấm nắn mạnh, không tác động lên vùng sưng đau/chấn thương."
      ],
      foodLifestyleNotes: [
        "Uống đủ nước, ngủ đủ, không làm việc liên tục một tư thế quá lâu.",
        "Xen kẽ đứng dậy, đi lại nhẹ và thả lỏng vai gáy."
      ],
      avoid: [
        "Không bấm nắn mạnh vùng đau, không tự nắn chỉnh cột sống.",
        "Không chườm nóng lên vùng sưng đỏ do chấn thương mới.",
        "Không cố tập khi đau tăng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau dữ dội sau chấn thương",
        "Tê yếu lan xuống tay chân",
        "Mất kiểm soát đại tiểu tiện",
        "Đau ngực",
        "Nói khó hoặc méo miệng"
      ],
      whenToSeeDoctor: [
        "Đau sau té ngã/chấn thương hoặc đau tăng nhanh.",
        "Có tê yếu, lan đau, mất cảm giác hoặc rối loạn đại tiểu tiện.",
        "Đau kéo dài nhiều ngày không giảm."
      ],
      appWording: {
        short: "Tê mỏi tay chân do tư thế: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống tê mỏi do tư thế, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "fatigue_after_light_activity",
      category: "Cơ xương / sinh hoạt",
      categoryId: "body_movement",
      title: "Mệt sau vận động nhẹ",
      situation: "Mệt hơn bình thường sau đi bộ, dọn nhà hoặc mang vác nhẹ.",
      commonSigns: [
        "mệt",
        "hụt sức nhẹ",
        "đau mỏi cơ"
      ],
      classicalView: "Theo cổ học, đau mỏi nhẹ do sinh hoạt có thể liên hệ đến khí huyết lưu thông kém, tư thế và lao lực.",
      safeCare: [
        "Nghỉ ngắn, thay đổi tư thế, vận động nhẹ trong biên độ không đau.",
        "Chườm ấm nhẹ hoặc tắm ấm nếu cơ thể không sốt và không có chấn thương cấp.",
        "Giãn cơ nhẹ, chậm, không bẻ vặn mạnh."
      ],
      folkNotes: [
        "Một số gia đình dùng chườm ấm nhẹ hoặc xoa bóp rất nhẹ quanh vùng mỏi; không bấm nắn mạnh, không tác động lên vùng sưng đau/chấn thương."
      ],
      foodLifestyleNotes: [
        "Uống đủ nước, ngủ đủ, không làm việc liên tục một tư thế quá lâu.",
        "Xen kẽ đứng dậy, đi lại nhẹ và thả lỏng vai gáy."
      ],
      avoid: [
        "Không bấm nắn mạnh vùng đau, không tự nắn chỉnh cột sống.",
        "Không chườm nóng lên vùng sưng đỏ do chấn thương mới.",
        "Không cố tập khi đau tăng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau dữ dội sau chấn thương",
        "Tê yếu lan xuống tay chân",
        "Mất kiểm soát đại tiểu tiện",
        "Đau ngực",
        "Nói khó hoặc méo miệng"
      ],
      whenToSeeDoctor: [
        "Đau sau té ngã/chấn thương hoặc đau tăng nhanh.",
        "Có tê yếu, lan đau, mất cảm giác hoặc rối loạn đại tiểu tiện.",
        "Đau kéo dài nhiều ngày không giảm."
      ],
      appWording: {
        short: "Mệt sau vận động nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống mệt sau vận động, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "wrist_strain_typing",
      category: "Cơ xương / sinh hoạt",
      categoryId: "body_movement",
      title: "Mỏi cổ tay do gõ máy",
      situation: "Cổ tay mỏi sau gõ phím, dùng chuột hoặc cầm điện thoại lâu.",
      commonSigns: [
        "mỏi cổ tay",
        "căng bàn tay",
        "dùng máy lâu"
      ],
      classicalView: "Theo cổ học, đau mỏi nhẹ do sinh hoạt có thể liên hệ đến khí huyết lưu thông kém, tư thế và lao lực.",
      safeCare: [
        "Nghỉ ngắn, thay đổi tư thế, vận động nhẹ trong biên độ không đau.",
        "Chườm ấm nhẹ hoặc tắm ấm nếu cơ thể không sốt và không có chấn thương cấp.",
        "Giãn cơ nhẹ, chậm, không bẻ vặn mạnh."
      ],
      folkNotes: [
        "Một số gia đình dùng chườm ấm nhẹ hoặc xoa bóp rất nhẹ quanh vùng mỏi; không bấm nắn mạnh, không tác động lên vùng sưng đau/chấn thương."
      ],
      foodLifestyleNotes: [
        "Uống đủ nước, ngủ đủ, không làm việc liên tục một tư thế quá lâu.",
        "Xen kẽ đứng dậy, đi lại nhẹ và thả lỏng vai gáy."
      ],
      avoid: [
        "Không bấm nắn mạnh vùng đau, không tự nắn chỉnh cột sống.",
        "Không chườm nóng lên vùng sưng đỏ do chấn thương mới.",
        "Không cố tập khi đau tăng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau dữ dội sau chấn thương",
        "Tê yếu lan xuống tay chân",
        "Mất kiểm soát đại tiểu tiện",
        "Đau ngực",
        "Nói khó hoặc méo miệng"
      ],
      whenToSeeDoctor: [
        "Đau sau té ngã/chấn thương hoặc đau tăng nhanh.",
        "Có tê yếu, lan đau, mất cảm giác hoặc rối loạn đại tiểu tiện.",
        "Đau kéo dài nhiều ngày không giảm."
      ],
      appWording: {
        short: "Mỏi cổ tay do gõ máy: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống mỏi cổ tay, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "leg_heavy_standing",
      category: "Cơ xương / sinh hoạt",
      categoryId: "body_movement",
      title: "Nặng chân sau đứng lâu",
      situation: "Chân nặng, mỏi nhẹ sau đứng lâu, chưa sưng đau bất thường.",
      commonSigns: [
        "mỏi chân",
        "nặng chân",
        "đứng lâu"
      ],
      classicalView: "Theo cổ học, đau mỏi nhẹ do sinh hoạt có thể liên hệ đến khí huyết lưu thông kém, tư thế và lao lực.",
      safeCare: [
        "Nghỉ ngắn, thay đổi tư thế, vận động nhẹ trong biên độ không đau.",
        "Chườm ấm nhẹ hoặc tắm ấm nếu cơ thể không sốt và không có chấn thương cấp.",
        "Giãn cơ nhẹ, chậm, không bẻ vặn mạnh."
      ],
      folkNotes: [
        "Một số gia đình dùng chườm ấm nhẹ hoặc xoa bóp rất nhẹ quanh vùng mỏi; không bấm nắn mạnh, không tác động lên vùng sưng đau/chấn thương."
      ],
      foodLifestyleNotes: [
        "Uống đủ nước, ngủ đủ, không làm việc liên tục một tư thế quá lâu.",
        "Xen kẽ đứng dậy, đi lại nhẹ và thả lỏng vai gáy."
      ],
      avoid: [
        "Không bấm nắn mạnh vùng đau, không tự nắn chỉnh cột sống.",
        "Không chườm nóng lên vùng sưng đỏ do chấn thương mới.",
        "Không cố tập khi đau tăng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Đau dữ dội sau chấn thương",
        "Tê yếu lan xuống tay chân",
        "Mất kiểm soát đại tiểu tiện",
        "Đau ngực",
        "Nói khó hoặc méo miệng"
      ],
      whenToSeeDoctor: [
        "Đau sau té ngã/chấn thương hoặc đau tăng nhanh.",
        "Có tê yếu, lan đau, mất cảm giác hoặc rối loạn đại tiểu tiện.",
        "Đau kéo dài nhiều ngày không giảm."
      ],
      appWording: {
        short: "Nặng chân sau đứng lâu: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống nặng chân, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "mild_inner_heat",
      category: "Nóng / khô / ẩm",
      categoryId: "hot_dry_damp",
      title: "Nóng trong nhẹ",
      situation: "Cảm giác bứt rứt, miệng khát, dễ cáu sau ngủ kém hoặc ăn cay dầu.",
      commonSigns: [
        "bứt rứt",
        "khát",
        "miệng khô"
      ],
      classicalView: "Theo cổ học, nhóm này thường mô tả thiên nhiệt, táo, thấp hoặc ảnh hưởng thời tiết làm cơ thể bứt rứt, nặng nề.",
      safeCare: [
        "Bổ sung nước phù hợp, nghỉ nơi thoáng mát hoặc khô ráo tùy tình huống.",
        "Giảm đồ quá cay, quá dầu, quá ngọt trong vài ngày.",
        "Theo dõi thân nhiệt, nước tiểu, cảm giác khát và mức độ mệt."
      ],
      folkNotes: [
        "Một số gia đình ưu tiên nước ấm, phòng thoáng và món thanh nhẹ; không tự dùng đồ thanh nhiệt mạnh hoặc xông hơi khi cơ thể đang nóng/sốt."
      ],
      foodLifestyleNotes: [
        "Ăn bữa nhẹ, nhiều rau mềm và món dễ tiêu.",
        "Giữ môi trường ngủ thông thoáng, tránh ẩm mốc."
      ],
      avoid: [
        "Không tự dùng đồ thanh nhiệt mạnh hoặc lợi tiểu khi đang mất nước.",
        "Không xông hơi khi đang nóng bức, lơ mơ, tim mạch yếu hoặc sốt cao.",
        "Không bỏ qua dấu mất nước."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao",
        "Lơ mơ",
        "Tiểu rất ít",
        "Khó thở",
        "Co giật",
        "Đau đầu dữ dội đột ngột"
      ],
      whenToSeeDoctor: [
        "Có dấu mất nước, lơ mơ, sốt cao hoặc co giật.",
        "Khô/nóng/nặng người kéo dài hoặc đi kèm đau đầu dữ dội.",
        "Người bệnh nền, người già, thai kỳ hoặc trẻ nhỏ cần thận trọng."
      ],
      appWording: {
        short: "Nóng trong nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống nóng trong nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "dry_mouth_lips",
      category: "Nóng / khô / ẩm",
      categoryId: "hot_dry_damp",
      title: "Miệng khô, môi nứt nhẹ",
      situation: "Khô miệng hoặc môi nứt nhẹ do thiếu nước, thời tiết khô hoặc điều hòa.",
      commonSigns: [
        "khô miệng",
        "môi nứt",
        "khát"
      ],
      classicalView: "Theo cổ học, nhóm này thường mô tả thiên nhiệt, táo, thấp hoặc ảnh hưởng thời tiết làm cơ thể bứt rứt, nặng nề.",
      safeCare: [
        "Bổ sung nước phù hợp, nghỉ nơi thoáng mát hoặc khô ráo tùy tình huống.",
        "Giảm đồ quá cay, quá dầu, quá ngọt trong vài ngày.",
        "Theo dõi thân nhiệt, nước tiểu, cảm giác khát và mức độ mệt."
      ],
      folkNotes: [
        "Một số gia đình ưu tiên nước ấm, phòng thoáng và món thanh nhẹ; không tự dùng đồ thanh nhiệt mạnh hoặc xông hơi khi cơ thể đang nóng/sốt."
      ],
      foodLifestyleNotes: [
        "Ăn bữa nhẹ, nhiều rau mềm và món dễ tiêu.",
        "Giữ môi trường ngủ thông thoáng, tránh ẩm mốc."
      ],
      avoid: [
        "Không tự dùng đồ thanh nhiệt mạnh hoặc lợi tiểu khi đang mất nước.",
        "Không xông hơi khi đang nóng bức, lơ mơ, tim mạch yếu hoặc sốt cao.",
        "Không bỏ qua dấu mất nước."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao",
        "Lơ mơ",
        "Tiểu rất ít",
        "Khó thở",
        "Co giật",
        "Đau đầu dữ dội đột ngột"
      ],
      whenToSeeDoctor: [
        "Có dấu mất nước, lơ mơ, sốt cao hoặc co giật.",
        "Khô/nóng/nặng người kéo dài hoặc đi kèm đau đầu dữ dội.",
        "Người bệnh nền, người già, thai kỳ hoặc trẻ nhỏ cần thận trọng."
      ],
      appWording: {
        short: "Miệng khô, môi nứt nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống khô miệng nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "dry_skin_light",
      category: "Nóng / khô / ẩm",
      categoryId: "hot_dry_damp",
      title: "Da khô nhẹ",
      situation: "Da khô, hơi ngứa hoặc bong nhẹ khi thời tiết khô.",
      commonSigns: [
        "da khô",
        "ngứa nhẹ",
        "bong da"
      ],
      classicalView: "Theo cổ học, nhóm này thường mô tả thiên nhiệt, táo, thấp hoặc ảnh hưởng thời tiết làm cơ thể bứt rứt, nặng nề.",
      safeCare: [
        "Bổ sung nước phù hợp, nghỉ nơi thoáng mát hoặc khô ráo tùy tình huống.",
        "Giảm đồ quá cay, quá dầu, quá ngọt trong vài ngày.",
        "Theo dõi thân nhiệt, nước tiểu, cảm giác khát và mức độ mệt."
      ],
      folkNotes: [
        "Một số gia đình ưu tiên nước ấm, phòng thoáng và món thanh nhẹ; không tự dùng đồ thanh nhiệt mạnh hoặc xông hơi khi cơ thể đang nóng/sốt."
      ],
      foodLifestyleNotes: [
        "Ăn bữa nhẹ, nhiều rau mềm và món dễ tiêu.",
        "Giữ môi trường ngủ thông thoáng, tránh ẩm mốc."
      ],
      avoid: [
        "Không tự dùng đồ thanh nhiệt mạnh hoặc lợi tiểu khi đang mất nước.",
        "Không xông hơi khi đang nóng bức, lơ mơ, tim mạch yếu hoặc sốt cao.",
        "Không bỏ qua dấu mất nước."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao",
        "Lơ mơ",
        "Tiểu rất ít",
        "Khó thở",
        "Co giật",
        "Đau đầu dữ dội đột ngột"
      ],
      whenToSeeDoctor: [
        "Có dấu mất nước, lơ mơ, sốt cao hoặc co giật.",
        "Khô/nóng/nặng người kéo dài hoặc đi kèm đau đầu dữ dội.",
        "Người bệnh nền, người già, thai kỳ hoặc trẻ nhỏ cần thận trọng."
      ],
      appWording: {
        short: "Da khô nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống da khô nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "damp_weather_heaviness",
      category: "Nóng / khô / ẩm",
      categoryId: "hot_dry_damp",
      title: "Nặng người khi trời ẩm",
      situation: "Cảm giác nặng nề, lười vận động khi trời ẩm hoặc phòng bí.",
      commonSigns: [
        "nặng người",
        "uể oải",
        "ẩm thấp"
      ],
      classicalView: "Theo cổ học, nhóm này thường mô tả thiên nhiệt, táo, thấp hoặc ảnh hưởng thời tiết làm cơ thể bứt rứt, nặng nề.",
      safeCare: [
        "Bổ sung nước phù hợp, nghỉ nơi thoáng mát hoặc khô ráo tùy tình huống.",
        "Giảm đồ quá cay, quá dầu, quá ngọt trong vài ngày.",
        "Theo dõi thân nhiệt, nước tiểu, cảm giác khát và mức độ mệt."
      ],
      folkNotes: [
        "Một số gia đình ưu tiên nước ấm, phòng thoáng và món thanh nhẹ; không tự dùng đồ thanh nhiệt mạnh hoặc xông hơi khi cơ thể đang nóng/sốt."
      ],
      foodLifestyleNotes: [
        "Ăn bữa nhẹ, nhiều rau mềm và món dễ tiêu.",
        "Giữ môi trường ngủ thông thoáng, tránh ẩm mốc."
      ],
      avoid: [
        "Không tự dùng đồ thanh nhiệt mạnh hoặc lợi tiểu khi đang mất nước.",
        "Không xông hơi khi đang nóng bức, lơ mơ, tim mạch yếu hoặc sốt cao.",
        "Không bỏ qua dấu mất nước."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao",
        "Lơ mơ",
        "Tiểu rất ít",
        "Khó thở",
        "Co giật",
        "Đau đầu dữ dội đột ngột"
      ],
      whenToSeeDoctor: [
        "Có dấu mất nước, lơ mơ, sốt cao hoặc co giật.",
        "Khô/nóng/nặng người kéo dài hoặc đi kèm đau đầu dữ dội.",
        "Người bệnh nền, người già, thai kỳ hoặc trẻ nhỏ cần thận trọng."
      ],
      appWording: {
        short: "Nặng người khi trời ẩm: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống nặng người trời ẩm, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "monsoon_fatigue",
      category: "Nóng / khô / ẩm",
      categoryId: "hot_dry_damp",
      title: "Uể oải mùa nồm",
      situation: "Đầu óc lơ mơ, người nặng khi thời tiết nồm ẩm.",
      commonSigns: [
        "uể oải",
        "đầu nặng",
        "ẩm mốc"
      ],
      classicalView: "Theo cổ học, nhóm này thường mô tả thiên nhiệt, táo, thấp hoặc ảnh hưởng thời tiết làm cơ thể bứt rứt, nặng nề.",
      safeCare: [
        "Bổ sung nước phù hợp, nghỉ nơi thoáng mát hoặc khô ráo tùy tình huống.",
        "Giảm đồ quá cay, quá dầu, quá ngọt trong vài ngày.",
        "Theo dõi thân nhiệt, nước tiểu, cảm giác khát và mức độ mệt."
      ],
      folkNotes: [
        "Một số gia đình ưu tiên nước ấm, phòng thoáng và món thanh nhẹ; không tự dùng đồ thanh nhiệt mạnh hoặc xông hơi khi cơ thể đang nóng/sốt."
      ],
      foodLifestyleNotes: [
        "Ăn bữa nhẹ, nhiều rau mềm và món dễ tiêu.",
        "Giữ môi trường ngủ thông thoáng, tránh ẩm mốc."
      ],
      avoid: [
        "Không tự dùng đồ thanh nhiệt mạnh hoặc lợi tiểu khi đang mất nước.",
        "Không xông hơi khi đang nóng bức, lơ mơ, tim mạch yếu hoặc sốt cao.",
        "Không bỏ qua dấu mất nước."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao",
        "Lơ mơ",
        "Tiểu rất ít",
        "Khó thở",
        "Co giật",
        "Đau đầu dữ dội đột ngột"
      ],
      whenToSeeDoctor: [
        "Có dấu mất nước, lơ mơ, sốt cao hoặc co giật.",
        "Khô/nóng/nặng người kéo dài hoặc đi kèm đau đầu dữ dội.",
        "Người bệnh nền, người già, thai kỳ hoặc trẻ nhỏ cần thận trọng."
      ],
      appWording: {
        short: "Uể oải mùa nồm: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống uể oải mùa nồm, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "mild_heat_after_spicy_food",
      category: "Nóng / khô / ẩm",
      categoryId: "hot_dry_damp",
      title: "Bứt rứt sau ăn cay nóng",
      situation: "Cảm giác nóng, khát, khó chịu nhẹ sau bữa cay nóng.",
      commonSigns: [
        "khát",
        "nóng người",
        "bứt rứt"
      ],
      classicalView: "Theo cổ học, nhóm này thường mô tả thiên nhiệt, táo, thấp hoặc ảnh hưởng thời tiết làm cơ thể bứt rứt, nặng nề.",
      safeCare: [
        "Bổ sung nước phù hợp, nghỉ nơi thoáng mát hoặc khô ráo tùy tình huống.",
        "Giảm đồ quá cay, quá dầu, quá ngọt trong vài ngày.",
        "Theo dõi thân nhiệt, nước tiểu, cảm giác khát và mức độ mệt."
      ],
      folkNotes: [
        "Một số gia đình ưu tiên nước ấm, phòng thoáng và món thanh nhẹ; không tự dùng đồ thanh nhiệt mạnh hoặc xông hơi khi cơ thể đang nóng/sốt."
      ],
      foodLifestyleNotes: [
        "Ăn bữa nhẹ, nhiều rau mềm và món dễ tiêu.",
        "Giữ môi trường ngủ thông thoáng, tránh ẩm mốc."
      ],
      avoid: [
        "Không tự dùng đồ thanh nhiệt mạnh hoặc lợi tiểu khi đang mất nước.",
        "Không xông hơi khi đang nóng bức, lơ mơ, tim mạch yếu hoặc sốt cao.",
        "Không bỏ qua dấu mất nước."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao",
        "Lơ mơ",
        "Tiểu rất ít",
        "Khó thở",
        "Co giật",
        "Đau đầu dữ dội đột ngột"
      ],
      whenToSeeDoctor: [
        "Có dấu mất nước, lơ mơ, sốt cao hoặc co giật.",
        "Khô/nóng/nặng người kéo dài hoặc đi kèm đau đầu dữ dội.",
        "Người bệnh nền, người già, thai kỳ hoặc trẻ nhỏ cần thận trọng."
      ],
      appWording: {
        short: "Bứt rứt sau ăn cay nóng: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống bứt rứt sau ăn cay, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "mild_dehydration_feeling",
      category: "Nóng / khô / ẩm",
      categoryId: "hot_dry_damp",
      title: "Khát và tiểu sẫm nhẹ",
      situation: "Cảm giác thiếu nước nhẹ sau ra mồ hôi hoặc uống ít nước.",
      commonSigns: [
        "khát",
        "tiểu sẫm",
        "mệt nhẹ"
      ],
      classicalView: "Theo cổ học, nhóm này thường mô tả thiên nhiệt, táo, thấp hoặc ảnh hưởng thời tiết làm cơ thể bứt rứt, nặng nề.",
      safeCare: [
        "Bổ sung nước phù hợp, nghỉ nơi thoáng mát hoặc khô ráo tùy tình huống.",
        "Giảm đồ quá cay, quá dầu, quá ngọt trong vài ngày.",
        "Theo dõi thân nhiệt, nước tiểu, cảm giác khát và mức độ mệt."
      ],
      folkNotes: [
        "Một số gia đình ưu tiên nước ấm, phòng thoáng và món thanh nhẹ; không tự dùng đồ thanh nhiệt mạnh hoặc xông hơi khi cơ thể đang nóng/sốt."
      ],
      foodLifestyleNotes: [
        "Ăn bữa nhẹ, nhiều rau mềm và món dễ tiêu.",
        "Giữ môi trường ngủ thông thoáng, tránh ẩm mốc."
      ],
      avoid: [
        "Không tự dùng đồ thanh nhiệt mạnh hoặc lợi tiểu khi đang mất nước.",
        "Không xông hơi khi đang nóng bức, lơ mơ, tim mạch yếu hoặc sốt cao.",
        "Không bỏ qua dấu mất nước."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao",
        "Lơ mơ",
        "Tiểu rất ít",
        "Khó thở",
        "Co giật",
        "Đau đầu dữ dội đột ngột"
      ],
      whenToSeeDoctor: [
        "Có dấu mất nước, lơ mơ, sốt cao hoặc co giật.",
        "Khô/nóng/nặng người kéo dài hoặc đi kèm đau đầu dữ dội.",
        "Người bệnh nền, người già, thai kỳ hoặc trẻ nhỏ cần thận trọng."
      ],
      appWording: {
        short: "Khát và tiểu sẫm nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống thiếu nước nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "room_air_dry",
      category: "Nóng / khô / ẩm",
      categoryId: "hot_dry_damp",
      title: "Khô do phòng điều hòa",
      situation: "Khô họng, khô da, khô mắt nhẹ khi ở phòng điều hòa lâu.",
      commonSigns: [
        "khô họng",
        "khô mắt",
        "khô da"
      ],
      classicalView: "Theo cổ học, nhóm này thường mô tả thiên nhiệt, táo, thấp hoặc ảnh hưởng thời tiết làm cơ thể bứt rứt, nặng nề.",
      safeCare: [
        "Bổ sung nước phù hợp, nghỉ nơi thoáng mát hoặc khô ráo tùy tình huống.",
        "Giảm đồ quá cay, quá dầu, quá ngọt trong vài ngày.",
        "Theo dõi thân nhiệt, nước tiểu, cảm giác khát và mức độ mệt."
      ],
      folkNotes: [
        "Một số gia đình ưu tiên nước ấm, phòng thoáng và món thanh nhẹ; không tự dùng đồ thanh nhiệt mạnh hoặc xông hơi khi cơ thể đang nóng/sốt."
      ],
      foodLifestyleNotes: [
        "Ăn bữa nhẹ, nhiều rau mềm và món dễ tiêu.",
        "Giữ môi trường ngủ thông thoáng, tránh ẩm mốc."
      ],
      avoid: [
        "Không tự dùng đồ thanh nhiệt mạnh hoặc lợi tiểu khi đang mất nước.",
        "Không xông hơi khi đang nóng bức, lơ mơ, tim mạch yếu hoặc sốt cao.",
        "Không bỏ qua dấu mất nước."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao",
        "Lơ mơ",
        "Tiểu rất ít",
        "Khó thở",
        "Co giật",
        "Đau đầu dữ dội đột ngột"
      ],
      whenToSeeDoctor: [
        "Có dấu mất nước, lơ mơ, sốt cao hoặc co giật.",
        "Khô/nóng/nặng người kéo dài hoặc đi kèm đau đầu dữ dội.",
        "Người bệnh nền, người già, thai kỳ hoặc trẻ nhỏ cần thận trọng."
      ],
      appWording: {
        short: "Khô do phòng điều hòa: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống khô do điều hòa, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "pre_period_fatigue",
      category: "Phụ nữ / gia đình",
      categoryId: "family_women",
      title: "Mệt nhẹ trước kỳ kinh",
      situation: "Mệt, hơi căng người hoặc dễ nhạy cảm trước kỳ kinh, không đau dữ dội.",
      commonSigns: [
        "mệt",
        "nhạy cảm",
        "căng nhẹ"
      ],
      classicalView: "Theo cổ học, nhóm này cần nhìn cùng khí huyết, tạng phủ và chu kỳ sinh hoạt, nhưng app chỉ dùng để tham khảo rất nhẹ.",
      safeCare: [
        "Nghỉ ngơi, giữ ấm vừa phải và theo dõi mức độ khó chịu.",
        "Ăn nhẹ, ngủ đủ, giảm lao lực và ghi lại chu kỳ/symptom.",
        "Ưu tiên hỏi bác sĩ khi đang mang thai, sau sinh, cho con bú hoặc triệu chứng khác thường."
      ],
      folkNotes: [],
      foodLifestyleNotes: [
        "Không tự dùng thảo dược, rượu thuốc hoặc mẹo truyền miệng trong thai kỳ/sau sinh.",
        "Chọn ăn uống cân bằng, dễ tiêu và tránh kiêng khem cực đoan."
      ],
      avoid: [
        "Không tự xử lý ra huyết bất thường, đau dữ dội hoặc sốt.",
        "Không dùng mẹo dân gian cho trẻ nhỏ khi chưa hỏi bác sĩ.",
        "Không xem đau bất thường là chuyện bình thường phải chịu."
      ],
      notFor: [
        "Đang mang thai",
        "Sau sinh/cho con bú",
        "Trẻ nhỏ",
        "Ra huyết bất thường",
        "Đau dữ dội hoặc sốt",
        "Bệnh nền hoặc đang dùng thuốc dài ngày"
      ],
      redFlags: [
        "Ra huyết bất thường",
        "Đau bụng dữ dội",
        "Sốt cao",
        "Ngất",
        "Thai kỳ có bất thường",
        "Trẻ nhỏ có dấu hiệu nặng"
      ],
      whenToSeeDoctor: [
        "Đang mang thai/sau sinh/cho con bú và có bất kỳ bất thường nào.",
        "Đau dữ dội, ra huyết bất thường, sốt hoặc ngất.",
        "Trẻ nhỏ có triệu chứng nặng hoặc kéo dài."
      ],
      appWording: {
        short: "Mệt nhẹ trước kỳ kinh: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống mệt trước kỳ kinh, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "medium",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "period_discomfort_light",
      category: "Phụ nữ / gia đình",
      categoryId: "family_women",
      title: "Khó chịu nhẹ ngày hành kinh",
      situation: "Căng bụng hoặc mệt nhẹ trong ngày hành kinh, không ra huyết bất thường.",
      commonSigns: [
        "mệt",
        "căng bụng nhẹ",
        "khó chịu"
      ],
      classicalView: "Theo cổ học, nhóm này cần nhìn cùng khí huyết, tạng phủ và chu kỳ sinh hoạt, nhưng app chỉ dùng để tham khảo rất nhẹ.",
      safeCare: [
        "Nghỉ ngơi, giữ ấm vừa phải và theo dõi mức độ khó chịu.",
        "Ăn nhẹ, ngủ đủ, giảm lao lực và ghi lại chu kỳ/symptom.",
        "Ưu tiên hỏi bác sĩ khi đang mang thai, sau sinh, cho con bú hoặc triệu chứng khác thường."
      ],
      folkNotes: [],
      foodLifestyleNotes: [
        "Không tự dùng thảo dược, rượu thuốc hoặc mẹo truyền miệng trong thai kỳ/sau sinh.",
        "Chọn ăn uống cân bằng, dễ tiêu và tránh kiêng khem cực đoan."
      ],
      avoid: [
        "Không tự xử lý ra huyết bất thường, đau dữ dội hoặc sốt.",
        "Không dùng mẹo dân gian cho trẻ nhỏ khi chưa hỏi bác sĩ.",
        "Không xem đau bất thường là chuyện bình thường phải chịu."
      ],
      notFor: [
        "Đang mang thai",
        "Sau sinh/cho con bú",
        "Trẻ nhỏ",
        "Ra huyết bất thường",
        "Đau dữ dội hoặc sốt",
        "Bệnh nền hoặc đang dùng thuốc dài ngày"
      ],
      redFlags: [
        "Ra huyết bất thường",
        "Đau bụng dữ dội",
        "Sốt cao",
        "Ngất",
        "Thai kỳ có bất thường",
        "Trẻ nhỏ có dấu hiệu nặng"
      ],
      whenToSeeDoctor: [
        "Đang mang thai/sau sinh/cho con bú và có bất kỳ bất thường nào.",
        "Đau dữ dội, ra huyết bất thường, sốt hoặc ngất.",
        "Trẻ nhỏ có triệu chứng nặng hoặc kéo dài."
      ],
      appWording: {
        short: "Khó chịu nhẹ ngày hành kinh: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống khó chịu nhẹ kỳ kinh, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "medium",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "postpartum_safety_only",
      category: "Phụ nữ / gia đình",
      categoryId: "family_women",
      title: "Sau sinh: chỉ hỏi bác sĩ",
      situation: "Sau sinh là giai đoạn nhạy cảm, app chỉ nhắc theo dõi và hỏi bác sĩ khi bất thường.",
      commonSigns: [
        "mệt",
        "thay đổi cơ thể",
        "nhạy cảm"
      ],
      classicalView: "Theo cổ học, nhóm này cần nhìn cùng khí huyết, tạng phủ và chu kỳ sinh hoạt, nhưng app chỉ dùng để tham khảo rất nhẹ.",
      safeCare: [
        "Không tự áp dụng mẹo dân gian hoặc thảo dược khi chưa hỏi bác sĩ.",
        "Theo dõi dấu hiệu bất thường và liên hệ cơ sở y tế khi cần.",
        "Ưu tiên nghỉ ngơi, ăn uống cân bằng và ghi lại triệu chứng để trao đổi với bác sĩ."
      ],
      folkNotes: [],
      foodLifestyleNotes: [
        "Không kiêng khem cực đoan, không dùng rượu thuốc hoặc nguyên liệu truyền miệng.",
        "Nếu có bất thường, hỏi bác sĩ thay vì tự xử lý."
      ],
      avoid: [
        "Không tự xử lý ra huyết bất thường, đau dữ dội hoặc sốt.",
        "Không dùng mẹo dân gian cho trẻ nhỏ khi chưa hỏi bác sĩ.",
        "Không xem đau bất thường là chuyện bình thường phải chịu."
      ],
      notFor: [
        "Đang mang thai",
        "Sau sinh/cho con bú",
        "Trẻ nhỏ",
        "Ra huyết bất thường",
        "Đau dữ dội hoặc sốt",
        "Bệnh nền hoặc đang dùng thuốc dài ngày"
      ],
      redFlags: [
        "Ra huyết bất thường",
        "Đau bụng dữ dội",
        "Sốt cao",
        "Ngất",
        "Thai kỳ có bất thường",
        "Trẻ nhỏ có dấu hiệu nặng"
      ],
      whenToSeeDoctor: [
        "Đang mang thai/sau sinh/cho con bú và có bất kỳ bất thường nào.",
        "Đau dữ dội, ra huyết bất thường, sốt hoặc ngất.",
        "Trẻ nhỏ có triệu chứng nặng hoặc kéo dài."
      ],
      appWording: {
        short: "Sau sinh: chỉ hỏi bác sĩ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống sau sinh, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "needs_expert_review",
      safetyLevel: "high",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "pregnancy_safety_only",
      category: "Phụ nữ / gia đình",
      categoryId: "family_women",
      title: "Thai kỳ: không tự áp dụng mẹo",
      situation: "Trong thai kỳ, không tự dùng thảo dược hoặc mẹo truyền miệng nếu chưa hỏi bác sĩ.",
      commonSigns: [
        "mệt",
        "buồn nôn nhẹ",
        "lo lắng"
      ],
      classicalView: "Theo cổ học, nhóm này cần nhìn cùng khí huyết, tạng phủ và chu kỳ sinh hoạt, nhưng app chỉ dùng để tham khảo rất nhẹ.",
      safeCare: [
        "Không tự áp dụng mẹo dân gian hoặc thảo dược khi chưa hỏi bác sĩ.",
        "Theo dõi dấu hiệu bất thường và liên hệ cơ sở y tế khi cần.",
        "Ưu tiên nghỉ ngơi, ăn uống cân bằng và ghi lại triệu chứng để trao đổi với bác sĩ."
      ],
      folkNotes: [],
      foodLifestyleNotes: [
        "Không kiêng khem cực đoan, không dùng rượu thuốc hoặc nguyên liệu truyền miệng.",
        "Nếu có bất thường, hỏi bác sĩ thay vì tự xử lý."
      ],
      avoid: [
        "Không tự xử lý ra huyết bất thường, đau dữ dội hoặc sốt.",
        "Không dùng mẹo dân gian cho trẻ nhỏ khi chưa hỏi bác sĩ.",
        "Không xem đau bất thường là chuyện bình thường phải chịu."
      ],
      notFor: [
        "Đang mang thai",
        "Sau sinh/cho con bú",
        "Trẻ nhỏ",
        "Ra huyết bất thường",
        "Đau dữ dội hoặc sốt",
        "Bệnh nền hoặc đang dùng thuốc dài ngày"
      ],
      redFlags: [
        "Ra huyết bất thường",
        "Đau bụng dữ dội",
        "Sốt cao",
        "Ngất",
        "Thai kỳ có bất thường",
        "Trẻ nhỏ có dấu hiệu nặng"
      ],
      whenToSeeDoctor: [
        "Đang mang thai/sau sinh/cho con bú và có bất kỳ bất thường nào.",
        "Đau dữ dội, ra huyết bất thường, sốt hoặc ngất.",
        "Trẻ nhỏ có triệu chứng nặng hoặc kéo dài."
      ],
      appWording: {
        short: "Thai kỳ: không tự áp dụng mẹo: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống thai kỳ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "needs_expert_review",
      safetyLevel: "high",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "small_child_safety_only",
      category: "Phụ nữ / gia đình",
      categoryId: "family_women",
      title: "Trẻ nhỏ: hỏi bác sĩ trước",
      situation: "Với trẻ nhỏ, app không khuyến khích tự áp dụng mẹo dân gian.",
      commonSigns: [
        "sốt nhẹ",
        "quấy khóc",
        "ăn kém"
      ],
      classicalView: "Theo cổ học, nhóm này cần nhìn cùng khí huyết, tạng phủ và chu kỳ sinh hoạt, nhưng app chỉ dùng để tham khảo rất nhẹ.",
      safeCare: [
        "Không tự áp dụng mẹo dân gian hoặc thảo dược khi chưa hỏi bác sĩ.",
        "Theo dõi dấu hiệu bất thường và liên hệ cơ sở y tế khi cần.",
        "Ưu tiên nghỉ ngơi, ăn uống cân bằng và ghi lại triệu chứng để trao đổi với bác sĩ."
      ],
      folkNotes: [],
      foodLifestyleNotes: [
        "Không kiêng khem cực đoan, không dùng rượu thuốc hoặc nguyên liệu truyền miệng.",
        "Nếu có bất thường, hỏi bác sĩ thay vì tự xử lý."
      ],
      avoid: [
        "Không tự xử lý ra huyết bất thường, đau dữ dội hoặc sốt.",
        "Không dùng mẹo dân gian cho trẻ nhỏ khi chưa hỏi bác sĩ.",
        "Không xem đau bất thường là chuyện bình thường phải chịu."
      ],
      notFor: [
        "Đang mang thai",
        "Sau sinh/cho con bú",
        "Trẻ nhỏ",
        "Ra huyết bất thường",
        "Đau dữ dội hoặc sốt",
        "Bệnh nền hoặc đang dùng thuốc dài ngày"
      ],
      redFlags: [
        "Ra huyết bất thường",
        "Đau bụng dữ dội",
        "Sốt cao",
        "Ngất",
        "Thai kỳ có bất thường",
        "Trẻ nhỏ có dấu hiệu nặng"
      ],
      whenToSeeDoctor: [
        "Đang mang thai/sau sinh/cho con bú và có bất kỳ bất thường nào.",
        "Đau dữ dội, ra huyết bất thường, sốt hoặc ngất.",
        "Trẻ nhỏ có triệu chứng nặng hoặc kéo dài."
      ],
      appWording: {
        short: "Trẻ nhỏ: hỏi bác sĩ trước: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống trẻ nhỏ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "needs_expert_review",
      safetyLevel: "high",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "breastfeeding_safety_only",
      category: "Phụ nữ / gia đình",
      categoryId: "family_women",
      title: "Cho con bú: thận trọng nguyên liệu dân gian",
      situation: "Khi cho con bú, mọi nguyên liệu dân gian cần thận trọng vì có thể ảnh hưởng mẹ và bé.",
      commonSigns: [
        "mệt",
        "lo lắng",
        "khó ngủ"
      ],
      classicalView: "Theo cổ học, nhóm này cần nhìn cùng khí huyết, tạng phủ và chu kỳ sinh hoạt, nhưng app chỉ dùng để tham khảo rất nhẹ.",
      safeCare: [
        "Không tự áp dụng mẹo dân gian hoặc thảo dược khi chưa hỏi bác sĩ.",
        "Theo dõi dấu hiệu bất thường và liên hệ cơ sở y tế khi cần.",
        "Ưu tiên nghỉ ngơi, ăn uống cân bằng và ghi lại triệu chứng để trao đổi với bác sĩ."
      ],
      folkNotes: [],
      foodLifestyleNotes: [
        "Không kiêng khem cực đoan, không dùng rượu thuốc hoặc nguyên liệu truyền miệng.",
        "Nếu có bất thường, hỏi bác sĩ thay vì tự xử lý."
      ],
      avoid: [
        "Không tự xử lý ra huyết bất thường, đau dữ dội hoặc sốt.",
        "Không dùng mẹo dân gian cho trẻ nhỏ khi chưa hỏi bác sĩ.",
        "Không xem đau bất thường là chuyện bình thường phải chịu."
      ],
      notFor: [
        "Đang mang thai",
        "Sau sinh/cho con bú",
        "Trẻ nhỏ",
        "Ra huyết bất thường",
        "Đau dữ dội hoặc sốt",
        "Bệnh nền hoặc đang dùng thuốc dài ngày"
      ],
      redFlags: [
        "Ra huyết bất thường",
        "Đau bụng dữ dội",
        "Sốt cao",
        "Ngất",
        "Thai kỳ có bất thường",
        "Trẻ nhỏ có dấu hiệu nặng"
      ],
      whenToSeeDoctor: [
        "Đang mang thai/sau sinh/cho con bú và có bất kỳ bất thường nào.",
        "Đau dữ dội, ra huyết bất thường, sốt hoặc ngất.",
        "Trẻ nhỏ có triệu chứng nặng hoặc kéo dài."
      ],
      appWording: {
        short: "Cho con bú: thận trọng nguyên liệu dân gian: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống cho con bú, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "needs_expert_review",
      safetyLevel: "high",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "cycle_tracking_mild",
      category: "Phụ nữ / gia đình",
      categoryId: "family_women",
      title: "Theo dõi chu kỳ khi khó chịu nhẹ",
      situation: "Ghi lại ngày, mức khó chịu, ngủ nghỉ và ăn uống để nhận diện nhịp cơ thể.",
      commonSigns: [
        "khó chịu nhẹ",
        "mệt",
        "chu kỳ thay đổi"
      ],
      classicalView: "Theo cổ học, nhóm này cần nhìn cùng khí huyết, tạng phủ và chu kỳ sinh hoạt, nhưng app chỉ dùng để tham khảo rất nhẹ.",
      safeCare: [
        "Nghỉ ngơi, giữ ấm vừa phải và theo dõi mức độ khó chịu.",
        "Ăn nhẹ, ngủ đủ, giảm lao lực và ghi lại chu kỳ/symptom.",
        "Ưu tiên hỏi bác sĩ khi đang mang thai, sau sinh, cho con bú hoặc triệu chứng khác thường."
      ],
      folkNotes: [],
      foodLifestyleNotes: [
        "Không tự dùng thảo dược, rượu thuốc hoặc mẹo truyền miệng trong thai kỳ/sau sinh.",
        "Chọn ăn uống cân bằng, dễ tiêu và tránh kiêng khem cực đoan."
      ],
      avoid: [
        "Không tự xử lý ra huyết bất thường, đau dữ dội hoặc sốt.",
        "Không dùng mẹo dân gian cho trẻ nhỏ khi chưa hỏi bác sĩ.",
        "Không xem đau bất thường là chuyện bình thường phải chịu."
      ],
      notFor: [
        "Đang mang thai",
        "Sau sinh/cho con bú",
        "Trẻ nhỏ",
        "Ra huyết bất thường",
        "Đau dữ dội hoặc sốt",
        "Bệnh nền hoặc đang dùng thuốc dài ngày"
      ],
      redFlags: [
        "Ra huyết bất thường",
        "Đau bụng dữ dội",
        "Sốt cao",
        "Ngất",
        "Thai kỳ có bất thường",
        "Trẻ nhỏ có dấu hiệu nặng"
      ],
      whenToSeeDoctor: [
        "Đang mang thai/sau sinh/cho con bú và có bất kỳ bất thường nào.",
        "Đau dữ dội, ra huyết bất thường, sốt hoặc ngất.",
        "Trẻ nhỏ có triệu chứng nặng hoặc kéo dài."
      ],
      appWording: {
        short: "Theo dõi chu kỳ khi khó chịu nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống theo dõi chu kỳ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "general_self_care",
      safetyLevel: "medium",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "family_elderly_caution",
      category: "Phụ nữ / gia đình",
      categoryId: "family_women",
      title: "Người cao tuổi: thận trọng mẹo dân gian",
      situation: "Người cao tuổi có thể nhạy với nhiệt, thảo dược và thay đổi ăn uống.",
      commonSigns: [
        "mệt",
        "ăn kém",
        "dễ lạnh"
      ],
      classicalView: "Theo cổ học, nhóm này cần nhìn cùng khí huyết, tạng phủ và chu kỳ sinh hoạt, nhưng app chỉ dùng để tham khảo rất nhẹ.",
      safeCare: [
        "Không tự áp dụng mẹo dân gian hoặc thảo dược khi chưa hỏi bác sĩ.",
        "Theo dõi dấu hiệu bất thường và liên hệ cơ sở y tế khi cần.",
        "Ưu tiên nghỉ ngơi, ăn uống cân bằng và ghi lại triệu chứng để trao đổi với bác sĩ."
      ],
      folkNotes: [],
      foodLifestyleNotes: [
        "Không kiêng khem cực đoan, không dùng rượu thuốc hoặc nguyên liệu truyền miệng.",
        "Nếu có bất thường, hỏi bác sĩ thay vì tự xử lý."
      ],
      avoid: [
        "Không tự xử lý ra huyết bất thường, đau dữ dội hoặc sốt.",
        "Không dùng mẹo dân gian cho trẻ nhỏ khi chưa hỏi bác sĩ.",
        "Không xem đau bất thường là chuyện bình thường phải chịu."
      ],
      notFor: [
        "Đang mang thai",
        "Sau sinh/cho con bú",
        "Trẻ nhỏ",
        "Ra huyết bất thường",
        "Đau dữ dội hoặc sốt",
        "Bệnh nền hoặc đang dùng thuốc dài ngày"
      ],
      redFlags: [
        "Ra huyết bất thường",
        "Đau bụng dữ dội",
        "Sốt cao",
        "Ngất",
        "Thai kỳ có bất thường",
        "Trẻ nhỏ có dấu hiệu nặng"
      ],
      whenToSeeDoctor: [
        "Đang mang thai/sau sinh/cho con bú và có bất kỳ bất thường nào.",
        "Đau dữ dội, ra huyết bất thường, sốt hoặc ngất.",
        "Trẻ nhỏ có triệu chứng nặng hoặc kéo dài."
      ],
      appWording: {
        short: "Người cao tuổi: thận trọng mẹo dân gian: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống người cao tuổi, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "needs_expert_review",
      safetyLevel: "high",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
  {
      id: "mild_sore_throat",
      category: "Cảm lạnh / thời tiết",
      categoryId: "cold_weather",
      title: "Rát họng nhẹ",
      situation: "Họng hơi rát, không sốt cao, không khó thở, không nuốt nghẹn nặng.",
      commonSigns: [
        "rát họng",
        "khô họng",
        "nuốt hơi khó chịu"
      ],
      classicalView: "Theo cách nói cổ học, nhóm này thường được mô tả quanh yếu tố phong, hàn, táo hoặc sự thay đổi thời tiết làm cơ thể khó chịu.",
      safeCare: [
        "Nghỉ ngơi ở nơi ấm, thoáng và tránh gió lùa trực tiếp.",
        "Uống nước ấm từng ngụm, không dùng đồ quá lạnh.",
        "Giữ ấm cổ, ngực, bàn chân; theo dõi thân nhiệt và nhịp thở."
      ],
      folkNotes: [
        "Một số gia đình thường dùng nước ấm, giữ ấm cổ/ngực/bàn chân; nếu có nhắc gừng hoặc mật ong thì chỉ xem là kinh nghiệm tham khảo và cần tránh ở nhóm nguy cơ."
      ],
      foodLifestyleNotes: [
        "Ưu tiên món ấm, mềm, dễ tiêu như cháo loãng hoặc súp nhẹ.",
        "Tránh rượu bia, đồ lạnh, đồ quá cay nóng khi người đang mệt."
      ],
      avoid: [
        "Không tự xông hơi khi sốt cao, khó thở, người già yếu hoặc trẻ nhỏ.",
        "Không cạo gió mạnh, không dùng rượu thuốc, không trì hoãn đi khám nếu có dấu hiệu nặng."
      ],
      notFor: [
        "Trẻ nhỏ",
        "Phụ nữ mang thai/cho con bú",
        "Người bệnh nền nặng",
        "Người đang dùng thuốc dài ngày",
        "Người có dị ứng với nguyên liệu được nhắc đến"
      ],
      redFlags: [
        "Sốt cao hoặc sốt kéo dài",
        "Khó thở",
        "Đau ngực",
        "Co giật",
        "Lơ mơ hoặc yếu liệt tay chân"
      ],
      whenToSeeDoctor: [
        "Triệu chứng nặng lên hoặc không giảm sau vài ngày.",
        "Có sốt cao, khó thở, đau ngực, lơ mơ hoặc co giật.",
        "Người bệnh nền, thai kỳ, trẻ nhỏ hoặc người cao tuổi nên hỏi bác sĩ sớm."
      ],
      appWording: {
        short: "Rát họng nhẹ: gợi ý chăm sóc nhẹ, chỉ để tham khảo.",
        detailed: "Với tình huống rát họng nhẹ, bạn có thể ưu tiên nghỉ ngơi, điều chỉnh sinh hoạt và theo dõi thêm. Nếu triệu chứng nặng lên, kéo dài hoặc có dấu hiệu cảnh báo, nên liên hệ bác sĩ/cơ sở y tế.",
      },
      forbiddenClaims: [
        "khỏi bệnh",
        "dứt điểm",
        "bảo đảm hiệu quả",
        "thay thế bác sĩ",
        "tự dùng để xử lý tình trạng nặng"
      ],
      evidenceLevel: "folk_experience",
      safetyLevel: "low",
      sources: [
        "WHO self-care/traditional medicine safety",
        "NCCIH herbs and supplements safety",
        "MedlinePlus emergency warning signs",
        "Mayo/Cleveland general self-care references",
        "Bệnh viện 108 cảnh báo sản phẩm Đông y không rõ nguồn gốc"
      ],
    },
];

export const FOLK_CARE_ITEM_COUNT = FOLK_CARE_ITEMS.length;

export function findFolkCareItem(id: string) {
  return FOLK_CARE_ITEMS.find((item) => item.id === id);
}

export function searchFolkCareItems(keyword: string) {
  const normalized = keyword.trim().toLowerCase();
  if (!normalized) return FOLK_CARE_ITEMS;
  return FOLK_CARE_ITEMS.filter((item) => {
    const haystack = [
      item.title,
      item.situation,
      item.category,
      ...item.commonSigns,
      ...item.safeCare,
      ...(item.folkNotes ?? []),
      ...(item.foodLifestyleNotes ?? []),
    ]
      .join(' ')
      .toLowerCase();
    return haystack.includes(normalized);
  });
}
