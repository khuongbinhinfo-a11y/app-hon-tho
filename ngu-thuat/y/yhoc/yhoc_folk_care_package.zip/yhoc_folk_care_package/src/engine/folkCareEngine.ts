// src/engine/folkCareEngine.ts
// Engine hiển thị an toàn cho module Cẩm nang chăm sóc đời sống.

import { FOLK_CARE_ITEMS } from '../data/yhoc/folkCare';
import {
  FOLK_CARE_GLOBAL_DISCLAIMER,
  FOLK_CARE_RED_FLAGS,
} from '../data/yhoc/folkCareSafety';
import type { FolkCareInput, FolkCareItem, FolkCareResult, FolkCareUserProfile } from '../data/yhoc/folkCareTypes';

function normalize(value: string) {
  return value.trim().toLowerCase();
}

function includesAny(inputValues: string[] = [], targets: string[] = []) {
  const bag = inputValues.map(normalize);
  return targets.some((target) => bag.includes(normalize(target)));
}

function isSensitiveProfile(profile?: FolkCareUserProfile) {
  if (!profile) return false;
  return Boolean(
    profile.isPregnant ||
      profile.isBreastfeeding ||
      profile.isChild ||
      profile.isElderly ||
      profile.hasChronicCondition ||
      profile.usesLongTermMedication ||
      profile.hasKnownAllergy
  );
}

function hasHerbalOrIngredientNote(item: FolkCareItem) {
  const text = [...(item.folkNotes ?? []), ...item.safeCare, ...(item.foodLifestyleNotes ?? [])]
    .join(' ')
    .toLowerCase();
  return ['gừng', 'mật ong', 'chanh', 'muối', 'xông', 'thảo dược', 'trà'].some((word) => text.includes(word));
}

function matchItem(input: FolkCareInput) {
  if (input.selectedItemId) {
    return FOLK_CARE_ITEMS.find((item) => item.id === input.selectedItemId);
  }

  if (input.signs?.length) {
    const signs = input.signs.map(normalize);
    return FOLK_CARE_ITEMS.find((item) =>
      item.commonSigns.some((sign) => signs.some((s) => normalize(sign).includes(s) || s.includes(normalize(sign))))
    );
  }

  if (input.selectedCategoryId) {
    return FOLK_CARE_ITEMS.find((item) => item.categoryId === input.selectedCategoryId);
  }

  return undefined;
}

export function interpretFolkCare(input: FolkCareInput): FolkCareResult {
  const profile = input.profile ?? {};
  const selectedRedFlags = input.redFlags ?? [];
  const globalRedFlagHit = includesAny(selectedRedFlags, FOLK_CARE_RED_FLAGS);
  const item = matchItem(input);

  const warnings: string[] = [FOLK_CARE_GLOBAL_DISCLAIMER];
  const nextActions: string[] = [];

  if (!item) {
    return {
      emergencyFirst: globalRedFlagHit,
      hiddenForSafety: false,
      visibleSafeCare: [],
      visibleFolkNotes: [],
      visibleFoodLifestyleNotes: [],
      warnings: globalRedFlagHit
        ? ['Có dấu hiệu cảnh báo. Không dùng app để tự xử lý; hãy liên hệ bác sĩ/cơ sở y tế.']
        : ['Chưa đủ dữ liệu để gợi ý tình huống chăm sóc phù hợp.'],
      nextActions: globalRedFlagHit
        ? ['Dừng tự xử lý.', 'Liên hệ cơ sở y tế hoặc cấp cứu tùy mức độ.']
        : ['Chọn một tình huống hoặc mô tả thêm dấu hiệu nhẹ đang gặp.'],
      confidence: 'low',
    };
  }

  const itemRedFlagHit = includesAny(selectedRedFlags, item.redFlags);
  const emergencyFirst = globalRedFlagHit || itemRedFlagHit;

  if (emergencyFirst) {
    return {
      emergencyFirst: true,
      hiddenForSafety: true,
      item,
      visibleSafeCare: [],
      visibleFolkNotes: [],
      visibleFoodLifestyleNotes: [],
      warnings: [
        'Có dấu hiệu cảnh báo liên quan tình huống này.',
        'Không hiển thị mẹo dân gian hoặc tự chăm sóc khi có dấu hiệu nguy hiểm.',
      ],
      nextActions: ['Dừng tự xử lý.', 'Liên hệ bác sĩ/cơ sở y tế; nếu nặng hãy gọi cấp cứu.', ...item.whenToSeeDoctor],
      confidence: 'medium',
    };
  }

  const sensitive = isSensitiveProfile(profile);
  const highRiskItem = item.safetyLevel === 'high';
  const longDuration = typeof input.durationDays === 'number' && input.durationDays >= 3;

  if (highRiskItem) {
    return {
      emergencyFirst: false,
      hiddenForSafety: true,
      item,
      visibleSafeCare: item.safeCare.filter((text) => !text.toLowerCase().includes('thảo dược')),
      visibleFolkNotes: [],
      visibleFoodLifestyleNotes: item.foodLifestyleNotes ?? [],
      warnings: [
        'Tình huống này thuộc nhóm cần thận trọng cao.',
        'App chỉ hiển thị nhắc nhở an toàn, không hiển thị mẹo dân gian.',
      ],
      nextActions: item.whenToSeeDoctor,
      confidence: 'medium',
    };
  }

  const hideFolkNotes = sensitive || hasHerbalOrIngredientNote(item);
  const visibleFolkNotes = sensitive ? [] : item.folkNotes ?? [];

  if (sensitive) {
    warnings.push('Bạn thuộc nhóm cần thận trọng; app đã ẩn các mẹo có nguyên liệu dân gian.');
    nextActions.push('Hỏi bác sĩ/chuyên gia trước khi áp dụng bất kỳ mẹo dân gian nào.');
  }

  if (longDuration) {
    warnings.push('Tình trạng đã kéo dài vài ngày; nên ưu tiên hỏi bác sĩ nếu không giảm hoặc tái diễn.');
    nextActions.push('Theo dõi thêm và cân nhắc đi khám nếu không cải thiện.');
  }

  return {
    emergencyFirst: false,
    hiddenForSafety: false,
    item,
    visibleSafeCare: item.safeCare,
    visibleFolkNotes: hideFolkNotes ? visibleFolkNotes : item.folkNotes ?? [],
    visibleFoodLifestyleNotes: item.foodLifestyleNotes ?? [],
    warnings,
    nextActions: nextActions.length ? nextActions : ['Theo dõi triệu chứng.', 'Ngưng tự áp dụng nếu khó chịu tăng.', ...item.whenToSeeDoctor.slice(0, 1)],
    confidence: input.selectedItemId ? 'medium' : 'low',
  };
}
